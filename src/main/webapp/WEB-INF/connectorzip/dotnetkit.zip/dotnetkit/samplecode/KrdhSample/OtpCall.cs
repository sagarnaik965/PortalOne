﻿using krdh.connector;
using krdh.parameters;
using KRDHConnector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KrdhSample
{
    class OtpCall
    {
        static void Main1(string[] args)
        {
            RequestObject request = new RequestObject();
            request.setAadhaarNumber("AADHAAR NUMBER");
            request.setTransaction(Util.generateTransactionId(TypeOfRequest.Others));
            request.setOtpRequestType(OTPRequestType.AADHAAR);


            KRDHConnectorImpl krdhConnector = new KRDHConnectorImpl();
            ResponseObject response = krdhConnector.RequestOTP(request);
            Console.WriteLine("Got Response");
            Console.WriteLine(response.getError());
            Console.WriteLine(response.getErrorMessage());
            if (response.getStatus().Equals("N"))
            {
                Console.WriteLine("Failed to generate the request.");
                Console.WriteLine(response.getError());
                Console.WriteLine(response.getErrorMessage());
            }
            else
            {
                Console.WriteLine(response.getTimeStamp());
                Console.WriteLine(response.getTransaction());
                if (response.getResponseStatus().ToLower().Equals("y"))
                {
                    Console.WriteLine("SUCCESS");
                }
                else
                {
                    Console.WriteLine(response.getError());
                    Console.WriteLine(response.getErrorMessage());
                }
            }
        }
    }
}
