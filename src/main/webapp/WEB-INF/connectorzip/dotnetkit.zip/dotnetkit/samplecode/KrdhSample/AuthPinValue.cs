﻿using krdh.connector;
using krdh.parameters;
using KRDHConnector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KrdhSample
{
    class AuthPinValue
    {
        static void Main5(string[] args)
        {
            RequestObject request = new RequestObject();
            request.setAadhaarNumber("AADHAAR NUMBER");
            
            
            request.setTransaction(Util.generateTransactionId(TypeOfRequest.Others));
            
            request.setVersion("2.0");
           
            request.setUdc("UDC CODE");
            request.setTimeStamp(Util.getTimeStamp());
            request.setResidentConsent(true);

            PinValue pv = new PinValue();
            pv.setOtp("660704");
            request.setTransaction("Set Transaction ID");
            request.setPinValue(pv);

            KRDHConnectorImpl krdhConnector = new KRDHConnectorImpl();

            ResponseObject response = krdhConnector.requestAuth(request);
            Console.WriteLine("Got Response");
            Console.WriteLine(response.getError());
            Console.WriteLine(response.getErrorMessage());
            if (response.getStatus().Equals("N"))
            {
                Console.WriteLine("Failed to generate the request.");
                Console.WriteLine(response.getError());
                Console.WriteLine(response.getErrorMessage());
            }
            else
            {
                Console.WriteLine(response.getTimeStamp());
                Console.WriteLine(response.getTransaction());
                if (response.getResponseStatus().ToLower().Equals("y"))
                {
                    Console.WriteLine("SUCCESS");
                }
                else
                {
                    Console.WriteLine(response.getError());
                    Console.WriteLine(response.getErrorMessage());
                }
            }
        }
    }
}
