package in.cdac.webclient.model;

public class StorePreviousOTPTransDetails {

	private String preAadhaarNumber;
	private String preVirtualID;
	private String otptranid;

	
	
	public String getPreAadhaarNumber() {
		return preAadhaarNumber;
	}

	public void setPreAadhaarNumber(String preAadhaarNumber) {
		this.preAadhaarNumber = preAadhaarNumber;
	}

	public String getPreVirtualID() {
		return preVirtualID;
	}

	public void setPreVirtualID(String preVirtualID) {
		this.preVirtualID = preVirtualID;
	}

	public String getOtptranid() {
		return otptranid;
	}

	public void setOtptranid(String otptranid) {
		this.otptranid = otptranid;
	}

	
}
