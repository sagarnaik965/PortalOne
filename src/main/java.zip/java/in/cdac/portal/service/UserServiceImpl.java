package in.cdac.portal.service;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.temporal.IsoFields;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpSession;

import java.util.UUID;

import org.apache.commons.lang3.SerializationUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ResourceUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import in.cdac.portal.billing.BillingServices;
import in.cdac.portal.dao.ReadDao;
import in.cdac.portal.dao.UserDao;
import in.cdac.portal.modal.AboutToExpireCertificate;
import in.cdac.portal.modal.AboutToExpireLK;
import in.cdac.portal.modal.AcCode;
import in.cdac.portal.modal.Activities;
import in.cdac.portal.modal.AddUser;
import in.cdac.portal.modal.AdminDeptCount;
import in.cdac.portal.modal.Algo_Info;
import in.cdac.portal.modal.AllowedOpr;
import in.cdac.portal.modal.AppDetail;
import in.cdac.portal.modal.AppList;
import in.cdac.portal.modal.AppLk;
import in.cdac.portal.modal.AuthCount;
import in.cdac.portal.modal.Billing;
import in.cdac.portal.modal.BillingDetails;
import in.cdac.portal.modal.CertificateDetails;
import in.cdac.portal.modal.ConnectorParam;
import in.cdac.portal.modal.Constant;
import in.cdac.portal.modal.Count;
import in.cdac.portal.modal.Count1;
import in.cdac.portal.modal.DeptDetails;
import in.cdac.portal.modal.DeptList;
import in.cdac.portal.modal.DetailedTransaction;
import in.cdac.portal.modal.ErrorCodeCount;
import in.cdac.portal.modal.ForgetPassword;
import in.cdac.portal.modal.FraudDetectionObject;
import in.cdac.portal.modal.GenerateAppLK;
import in.cdac.portal.modal.GenerateUdcCode;
import in.cdac.portal.modal.KeyInfo;
import in.cdac.portal.modal.KeyMapping;
import in.cdac.portal.modal.KuaLk;
import in.cdac.portal.modal.LicensekeyDetails;
import in.cdac.portal.modal.OprList;
import in.cdac.portal.modal.ProfileDetail;
import in.cdac.portal.modal.ResendActivationList;
import in.cdac.portal.modal.RoleActivity;
import in.cdac.portal.modal.SigningDetails;
import in.cdac.portal.modal.Slot;
import in.cdac.portal.modal.StateList;
import in.cdac.portal.modal.SuccessCount;
import in.cdac.portal.modal.Summary;
import in.cdac.portal.modal.TransactionCountDetails;
import in.cdac.portal.modal.TransactionCountTotal;
import in.cdac.portal.modal.TransactionDetailReport;
import in.cdac.portal.modal.UpdateAuaLk;
import in.cdac.portal.modal.UserRolesforUserManagement;
import in.cdac.portal.modal.UserStatus;
import in.cdac.portal.util.EmailService;
import in.cdac.portal.util.Util;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

@Service
public class UserServiceImpl implements UserService {

	
	private final static Logger logger = Logger.getLogger(UserServiceImpl.class);

	@Autowired
	UserDao userDao;

	@Autowired
	ReadDao rdao;
	
	@Autowired
	EmailService emailService;

	@Autowired
	PasswordEncoder encoder;

	@Autowired
	Util util;
	
	@Autowired(required = true)
	BillingServices billSer;
	
	@Autowired
	Environment env;
	
	static HttpSession sess;
	
	

	public void updatePassword(String userName, String password) {
		userDao.updatePassword(userName, password);
	}

	public ProfileDetail getProfileDetails(String userName) {
		return userDao.getProfileDetails(userName).get(0);
	}

	public void updateProfileDetails(String userName, ProfileDetail profileDetail) {
		userDao.updateProfileDetails(userName, profileDetail);
	}

	public List<AcCode> getAcCode(String userName) {
		return userDao.getAcCode(userName);
	}

	public void updateAc(String userName, AcCode ac) {
		userDao.updateAc(userName, ac.getAcCode());

	}

	public List<UpdateAuaLk> getlk(String userName) {
		return userDao.getlk(userName);
	}

	@Transactional
	public boolean updateAuaLk(String userName, UpdateAuaLk updateAuaLk) {
		return userDao.updateAuaLk(userName, updateAuaLk);
	}

	public int getRoleIdFromUsername(String username) {
		return userDao.getRoleIdFromUsername(username);
	}

	public String adduser(String userName, AddUser user) {
		// int deptId = userDao.addUser(userName, user);
		String appCode = userDao.addUser(userName, user);
		String generatedUserName = userDao.getUserNameFromEmailId(user.getEmail());
		// String userNameHash = util.generateHashForLink(deptId +
		// Constant.USER_CREATION_EMAIL_HASH_STRING);
		String userNameHash = util.generateHashForLink(appCode + Constant.USER_CREATION_EMAIL_HASH_STRING);
		String urlStart = userDao.getPortalUrl() + "/accountactivation?";
		// String emailLink = urlStart + "user=" + deptId + "&hash=" + userNameHash;
		String emailLink = urlStart + "user=" + appCode + "&hash=" + userNameHash;

		String body = Constant.USER_CREATION_EMAIL_BODY_BEGIN + generatedUserName
				+ Constant.USER_CREATION_EMAIL_BODY_MIDDLE + "<a href=" + emailLink + ">click here</a>"
				+ Constant.USER_CREATION_EMAIL_BODY_END;
		try {
			emailService.sendMail(Constant.EMAILFROM, user.getEmail(), Constant.USER_CREATION_EMAIL_SUBJECT, body,
					false);
		} catch (Exception e) {
			logger.info("something went wrong while sending email" + e);
		}
		return generatedUserName;
	}

	public List<TransactionDetailReport> getTransactionDetailsReport(String username, int roleid, String txnType,
			String fDate, String lDate) {
		return userDao.getTransactionDetailsReport(username, roleid, txnType, fDate, lDate);
	}

	public List<TransactionDetailReport> getTransactionDetailsCsvReport(String username, String txnType, String fDate,
			String lDate) {
		return userDao.getTransactionDetailsCsvReport(username, txnType, fDate, lDate);
	}

	public boolean checkOldPassword(String userName, String oldPassword) {
		return userDao.checkOldPassword(userName, oldPassword);
	}

	public List<UserStatus> getUserStatus() {
		List<UserStatus> us = userDao.getUserStatus();
		return us;
	}

	public List<UserStatus> getLkStatus() {
		List<UserStatus> us = userDao.getLkStatus();
		return us;
	}

	public List<UserStatus> getSAStatus() {
		List<UserStatus> us = userDao.getSAStatus();
		return us;
	}

	public List<UserStatus> getAppcode() {
		List<UserStatus> us = userDao.getAppcode();
		return us;
	}

	public List<UserStatus> getEmailAppnameByAppcode(String appcode) {
		List<UserStatus> us = userDao.getEmailAppnameByAppcode(appcode);
		return us;
	}

	public List<AddUser> getAPPCodes() {
		List<AddUser> us = userDao.getAPPCodes();
		return us;
	}

	public List<UserStatus> getsaLkStatus() {
		List<UserStatus> us = userDao.getsaLkStatus();
		return us;
	}

	public List<String> checkSaLKPersistance(List saCode) {
		List<String> list = userDao.checkSaLKPersistance(saCode);
		return list;
	}

	public List<UserStatus> getSuspendUserStatus() {
		List<UserStatus> us = userDao.getSuspendUserStatus();
		return us;
	}

	@Transactional
	public void emailVerificationAccountPasswordUpdate(int dept, String password) {
		userDao.emailVerificationAccountPasswordUpdate(dept, password);
	}

	@Transactional
	public void updateLoginStatus(List<String> usernames, List<String> auacodes, List<Boolean> loginStatusList,
			List<Boolean> authStatusList, List<Boolean> otpStatusList, List<Boolean> ekycStatusList) {
		userDao.updateLoginStatus(usernames, auacodes, loginStatusList, authStatusList, otpStatusList, ekycStatusList);
	}

	@Transactional
	public void generateSaLk(List<String> saCode, List<String> dateValueList) {
		userDao.generateSaLk(saCode, dateValueList);
	}

	@Transactional
	public void generateSchemeCode(List<String> saCode, List<String> schemeDesc) {
		userDao.generateSchemeCode(saCode, schemeDesc);
	}

	@Transactional
	public boolean updateSaLk(List<String> saCode, List<String> salk, List<String> dateValueList) {
		return userDao.updateSaLk(saCode, salk, dateValueList);
	}

	@Transactional
	public void suspendUser(List<String> usernames, boolean status) {
		userDao.suspendUser(usernames, status);
	}

	@Transactional
	public boolean checkEmailVerificationStatus(int deptId) {
		return userDao.checkEmailVerificationStatus(deptId);
	}

	@Transactional
	public List<UserStatus> getTransactionStatus() {
		return userDao.getTransactionStatus();
	}

	public void updateTransactionStatus(List<String> deptId, List<String> type, boolean transactionStatus) {
		userDao.updateTransactionStatus(deptId, type, transactionStatus);
	}

	public String generateUdcCode(String userName, GenerateUdcCode udc) {
		return userDao.generateUdcCode(userName, udc);
	}

	public List<KuaLk> getKualk(String userName) {
		return userDao.getKualk(userName);
	}

	@Transactional
	public boolean updatekuaLk(String userName, KuaLk updateKuaLK) {
		return userDao.updatekuaLk(userName, updateKuaLK);
	}

	@Transactional
	public List<GenerateUdcCode> getUdc(String userName) {
		return userDao.getUdc(userName);
	}

	public List<AuthCount> getAuthTransStats(String userName) {
		return userDao.getAuthTransStats(userName);
	}

	public List<AuthCount> getOtpTransStats(String userName) {
		return userDao.getOtpTransStats(userName);
	}

	public List<AuthCount> getKycTransStats(String userName) {
		return userDao.getKycTransStats(userName);
	}

	@Transactional
	public Map<String, List<TransactionCountDetails>> getMonthlyCountAdmin(String userName, Integer role) {
		return userDao.getMonthlyCountAdmin(userName, role);
	}

	/*
	 * public Map<String, Map<String, Integer>> getHomeBar(String userName, Integer
	 * role) { return userDao.getHomeBar(userName, role); }
	 */
	public Map<String, Map<String, Integer>> getHomeBar(String userName) {
		return userDao.getHomeBar(userName);
	}

	public Map<String, Integer> getHomePageCount(String userName) {
		return userDao.getHomePageCount(userName);
	}

	public List<LicensekeyDetails> getAsalk(String userName) {
		return userDao.getAsalk(userName);
	}

	@Transactional
	public boolean updateasaLk(String userName, LicensekeyDetails updateAsaLK) {
		return userDao.updateAsaLk(userName, updateAsaLK);
	}

	public List<LicensekeyDetails> getKsalk(String userName) {
		return userDao.getKsalk(userName);
	}

	@Transactional
	public boolean updateKsaLk(String userName, LicensekeyDetails updateKsaLK)
			throws DataAccessException, ParseException {
		return userDao.updateKsaLk(userName, updateKsaLK);
	}

	public ConnectorParam getconnectorParam(String userName) {
		return userDao.getconnectorParam(userName);
	}

	public List<String> getUdcList(String userName) {
		return userDao.getUdcList(userName);
	}

	public Object getparamdetails(String userName) {
		return userDao.getparamdetails(userName);
	}

	/*
	 * public Map<String, Integer> getMonthlyTotalTrans(String userName, Integer
	 * role) { return userDao.getMonthlyTotalTrans(userName, role); }
	 */
	public Map<String, Integer> getMonthlyTotalTrans(String userName) {
		return userDao.getMonthlyTotalTrans(userName);
	}

	public boolean checkUserFromEmailId(String emailId) {
		return userDao.checkUserFromEmailId(emailId);
	}

	public boolean checkAuaCode(String auaCode) {
		return userDao.checkAuaCode(auaCode);
	}

	public String getCurrentDeptId(String userName) {
		return userDao.getCurrentDeptId(userName);
	}

	public String getAppCode(String dept) {
		return userDao.getAppCode(dept);
	}

	public List<AdminDeptCount> getAdminDeptCount() {
		return userDao.getAdminDeptCount();
	}

	public int getDeptCount(String userName) {
		return userDao.getDeptCount(userName);
	}

	public String getCurrentEmailId(String userName) {
		return userDao.getCurrentEmailId(userName);
	}

	public String getCurrentDeptName(String emailId) {
		return userDao.getCurrentDeptName(emailId);
	}

	public boolean checkUserFromDeptName(String deptName) {
		return userDao.checkUserFromDeptName(deptName);
	}

	public boolean checkForDuplicateKey(LicensekeyDetails lk, String type, int currentDeptId) {
		return userDao.checkForDuplicateKey(lk, type, currentDeptId);
	}

	public boolean checkForgetPasswordDetail(ForgetPassword forgetpassword) {
		return userDao.checkForgetPasswordDetail(forgetpassword);
	}

	public boolean sendPasswordRecoveryEmail(ForgetPassword forgetpassword, String auaCode) {
		UUID randomUUID = UUID.randomUUID();
		String randomUuid = randomUUID.toString();
		boolean successUpdate = false;
		try {
			userDao.updateResetPasswordDetail(forgetpassword.getUserName(), randomUuid);
			successUpdate = true;
		} catch (Exception e) {
			successUpdate = false;
			logger.info(e);
		}
		String urlStart = userDao.getParaValueByParaName("portal_url").trim();
		urlStart = urlStart + "/recoverpassword?";
		logger.info("urlStart :" + urlStart);
		String emailLink = urlStart + "user=" + forgetpassword.getUserName() + "&hash=" + randomUuid;
		String body = Constant.PASSWORD_RECOVERY_EMAIL_BODY_BEGIN + forgetpassword.getUserName()
				+ Constant.PASSWORD_RECOVERY_EMAIL_BODY_BEGIN_AUA_CODE + auaCode
				+ Constant.USER_CREATION_EMAIL_BODY_MIDDLE + "<a href='" + emailLink + "'>click here</a>"
				+ Constant.USER_CREATION_EMAIL_BODY_END;

		if (!successUpdate) {
			return false;
		}
		try {
			String mailTo = forgetpassword.getEmail();
			emailService.sendMail(Constant.EMAILFROM, mailTo, Constant.PASSWORD_RECOVERY_EMAIL_SUBJECT, body, false);
		} catch (Exception e) {
			logger.info(e);
		}
		return true;
	}

	public boolean UpdateRecoverPassword(String userName, String encode) {
		return userDao.UpdateRecoverPassword(userName, encode);
	}

	public List<ResendActivationList> getActivationReSendList() {
		return userDao.getActivationReSendList();
	}

	public void resendActivationLink(List<String> users) {

		List<String> templist = new ArrayList<String>();

		String username_prefix = userDao.getParaValueByParaName("portal_type");
		if (username_prefix.equals("asa"))
			username_prefix = "aua";
		else
			username_prefix = "saua";

		for (String deptId : users) {
			String generatedUserName = util.generateUserName(Integer.parseInt(deptId), username_prefix);
			String userNameHash = util.generateHashForLink(deptId + Constant.USER_CREATION_EMAIL_HASH_STRING);
			String urlStart = userDao.getPortalUrl() + "/accountactivation?";
			String emailLink = urlStart + "user=" + deptId + "&hash=" + userNameHash;
			String body = Constant.USER_CREATION_EMAIL_BODY_BEGIN + generatedUserName
					+ Constant.USER_CREATION_EMAIL_BODY_MIDDLE + "<a href=" + emailLink + ">click here</a>"
					+ Constant.USER_CREATION_EMAIL_BODY_END;
			templist.add(deptId);
			String emailId = userDao.getEmailIdFromDeptId(templist).get(0);
			try {
				emailService.sendMail(Constant.EMAILFROM, emailId, Constant.USER_CREATION_EMAIL_SUBJECT, body, false);
				templist.clear();
			} catch (Exception e) {
				logger.info(e);
			}
		}
	}

	public List<AboutToExpireLK> getAboutToExpireLK() {
		return userDao.getAboutToExpireLK();
	}

	public List<AboutToExpireCertificate> getAboutToExpireCertificates() {
		return userDao.getAboutToExpireCertificates();
	}

	public boolean UpdateSignDetails(SigningDetails signdetails, String userName) {
		return userDao.UpdateSignDetails(signdetails, userName);
	}

	public List<DetailedTransaction> getDetailedTransaction(Integer role, String type, String userName) {
		return userDao.getDetailedTransaction(role, type, userName);
	}

	public List<SigningDetails> getSignPrefrence(String userName, String ac) {
		return userDao.getSignPrefrence(userName, ac);
	}

	public List<ErrorCodeCount> getTotalErrorTrans(Integer role, String userName) {
		return userDao.getTotalErrorTrans(role, userName);
	}

	public List<DetailedTransaction> getDetailedErrorTransaction(String errorCode, String userName, Integer role) {
		return userDao.getDetailedErrorTransaction(errorCode, userName, role);

	}

	/*
	 * public Map<String, Integer> getTotalTransactionHomePage(Integer role, String
	 * userName) { return userDao.getTotalTransactionHomePage(role, userName); }
	 */
	public Map<String, Integer> getTotalTransactionHomePage(String userName) {
		return userDao.getTotalTransactionHomePage(userName);
	}

	public Map<String, Integer> acwiseTotaltrans(String acCode) {
		return userDao.acwiseTotaltrans(acCode);
	}

	public Map<String, Integer> acWiseYesTrans(String acCode) {
		return userDao.acWiseYesTrans(acCode);
	}

	/*
	 * public int getTotalErrorCount(List<Integer> roles, String userName) { return
	 * userDao.getTotalErrorCount(roles, userName); }
	 */
	public int getTotalErrorCount(String userName) {
		return userDao.getTotalErrorCount(userName);
	}

	public String getConnectorDowloadFilePath() {
		// TODO Auto-generated method stub
		return userDao.getConnectorDowloadFilePath();
	}

	/*
	 * public int getHomePageSuccessCount(int role, String userName) { return
	 * userDao.getHomePageSuccessCount(role, userName); }
	 */

	public int getHomePageSuccessCount(String userName) {
		return userDao.getHomePageSuccessCount(userName);
	}

	public int getTotalAcCountDeptWise(String userName) {
		return userDao.getTotalAcCountDeptWise(userName);
	}

	public Map<String, Integer> getTotaldeshDeptCouont(String userName) {
		return userDao.getTotaldeshDeptCouont(userName);
	}

	public List<TransactionDetailReport> getTransactionDetailReportCount(String userName, String transactiontype,
			String responsetype, int records, String fromDate, String toDate) {
		return userDao.getTransactionDetailReportCount(userName, transactiontype, responsetype, records, fromDate,
				toDate);
	}

	public List<TransactionDetailReport> getTransactionDetail(String userName, String txn, String type) {
		return userDao.getTransactionDetail(userName, txn, type);
	}

	public boolean checkForPassworResetValidToken(String token, String userName) {
		return userDao.checkForPassworResetValidToken(token, userName);
	}

	public boolean sendPasswordRecoveryEmail(ForgetPassword forgetpassword) {
		return userDao.sendPasswordRecoveryEmail(forgetpassword);
	}

	public Map<String, TransactionCountTotal> getHomePageTabelData(String userName) {
		return userDao.getHomePageTabelData(userName);
	}

	/*
	 * public List<AdminDeptCount> getSuccessCount(String userName, Integer role) {
	 * return userDao.getSuccessCount(userName, role); }
	 */

	public Map<String, Integer> getSuccessCount(String userName) {
		return userDao.getSuccessCount(userName);
	}

	public Map<String, Integer> getFailureCount(String userName) {
		return userDao.getFailureCount(userName);
	}

	public Map<String, Integer> acwiseNotrans(String acCode) {
		return userDao.acwiseNotrans(acCode);
	}

	public List<AdminDeptCount> getTimeExecutionRecords(String fromDate, String toDate, Integer role, String deptId) {
		return userDao.getTimeExecutionRecords(fromDate, toDate, role, deptId);
	}

	public List<AdminDeptCount> getFailureTimeExecutionRecords(String fromDate, String toDate, Integer role,
			String deptId) {
		return userDao.getFailureTimeExecutionRecords(fromDate, toDate, role, deptId);
	}

	public List<AdminDeptCount> getFailureReportCount(String deptId, String fromDate, String toDate) {
		return userDao.getFailureReportCount(deptId, fromDate, toDate);
	}

	public String getDeptNameFromId(String deptId) {
		return userDao.getDeptNameFromId(deptId);
	}

	public String getAcFromId(String deptId) {
		return userDao.getAcFromId(deptId);
	}

	public String getFraudDetectionTimeSchedule() {
		return userDao.getFraudDetectionTimeSchedule();
	}

	public List<FraudDetectionObject> getDetectedFraudTransaction() {
		return userDao.getDetectedFraudTransaction();
	}

	public void updateFraudDetectionEmailSent(FraudDetectionObject obj) {
		userDao.updateFraudDetectionEmailSent(obj);

	}

	public String getDeploymentEnviroment() {
		return userDao.getParaValueByParaName("deployment_environment");
	}

	public void uploadCertificate(String userName, MultipartFile[] cert, String certIdentifier, String certpath,
			String certalias, String certpass, String type, String validTill) throws DataAccessException, IOException {
		userDao.uploadCertificate(userName, cert, certIdentifier, certpath, certalias, certpass, type, validTill);

	}

	public List<CertificateDetails> getCerticateDetails(String userName) {

		return userDao.getCerticateDetails(userName);
	}

	public List<AcCode> getAcList() {

		return userDao.getAcList();
	}

	public String getDeptNameFromAc(String ac) {
		return userDao.getDeptNameFromAc(ac);
	}

	public String getBccEmailId() {
		return userDao.getParaValueByParaName("portal_support_email").trim();
	}

	public String getCcEmailId(String cdMail) {
		return userDao.getCcEmailId(cdMail);
	}

	public List<SuccessCount> getSuccessCount1(String userName) {
		return userDao.getSuccessCount1(userName);
	}

	public List<SuccessCount> getFailureCountNew(String userName, Integer role) {
		return userDao.getFailureCountNew(userName, role);
	}

//	-----------------------Methods for react application---------------------------------------

	@Override
	public List<StateList> getStateList() {

		return this.userDao.getStateList();
	}

	@Override
	public int getHomePageSuccessCountR(String username) {
		// TODO Auto-generated method stub
		return userDao.getHomePageSuccessCountR(username);
	}

	@Override
	public int getTotalErrorCountR(String username) {
		// TODO Auto-generated method stub
		return userDao.getTotalErrorCountR(username);
	}

	public Map<String, Integer> getMonthlyTotalTransR(String userName) {
		return userDao.getMonthlyTotalTransR(userName);
	}

	@Override
	public int getTotalAcCountDeptWiseR(String userName) {
		// TODO Auto-generated method stub
		return userDao.getTotalAcCountDeptWiseR(userName);
	}

	@Override
	public List<Count1> getTotalTransactionHomePageR(String userName) {
		// TODO Auto-generated method stub
		Map<String, Integer> map = null;
		List<Count1> l1 = new ArrayList<>();
		try {			
		map = userDao.getTotalTransactionHomePageR(userName);
		for (Map.Entry<String, Integer> entry : map.entrySet()) {
			Count1 c1 = new Count1();
			c1.setY(entry.getValue());
			c1.setName(entry.getKey());
			l1.add(c1);
		}
		return l1 ;
		} catch (Exception e) {
			// TODO: handle exception
			logger.info(e.getMessage());
			return l1 ;
		}
	}

	public List<UserStatus> getAppcodeR(String username) {
		List<UserStatus> us = userDao.getAppcodeR(username);
		return us;
	}

	public List<Count> acwiseNotransR(String acCode) {
		List<Count> l1 = new ArrayList<>();
		try {			
		Map<String, Integer> datalist =  userDao.acwiseNotransR(acCode);
		for (Map.Entry<String, Integer> entry : datalist.entrySet()) {
			Count c1 = new Count();
			c1.setY(entry.getValue());
			c1.setLabel(entry.getKey());
			l1.add(c1);
		}
		return l1;
		} catch (Exception e) {			
			logger.info("Exception Data for opr wise chart for NO not found "+e.getMessage());
			return l1;
		}
		
	}

	public List<Count> acWiseYesTransR(String acCode) {
		List<Count> l1 = new ArrayList<>();
		try {			
		Map<String, Integer> map1 = userDao.acWiseYesTransR(acCode);
		for (Map.Entry<String, Integer> entry : map1.entrySet()) {
			Count c1 = new Count();
			c1.setY(entry.getValue());
			c1.setLabel(entry.getKey());
			l1.add(c1);
		}
		return l1;
		} catch (Exception e) {			
			logger.info("Exception Data for opr wise chart for YES not found "+e.getMessage());
			return l1;
		}		
	}
		 
	
	

	public List<Count> acwiseTotaltransR(String[] acCode) {
		List<Count> l1 = new ArrayList<>();
		Map<String, Integer> map = new HashMap<>();		
		map = userDao.acwiseTotaltransR(acCode);
		for (Map.Entry<String, Integer> entry : map.entrySet()) {
			Count c1 = new Count();
			c1.setY(entry.getValue());
			c1.setLabel(entry.getKey());
			l1.add(c1);
		}
		return l1;
	}

	@Override
	public Map<String, DeptDetails> getDeptServiceDetailsR(String deptcode) {
		// TODO Auto-generated method stub
		return userDao.getrecordR(deptcode);
	}

	@Override
	public String getRole(String principal) {
		// TODO Auto-generated method stub
		return userDao.getRole(principal);
	}

	@Override
	public List<String[]> Reports(String first, String last ,String username) {
		// TODO Auto-generated method stub
		return userDao.Reports(first, last ,username);
	}
	
	@Override
	public  ResponseEntity<byte[]> Reportspdf(String first, String last,String username ) {
		// TODO Auto-generated method stub
	
		String nameandcode=userDao.getDeptcodeFromUsernameforreport(username);
		String[] deptnamenadcode = nameandcode.split(",");
		 Map<String, Summary> summarydata = new HashMap<>();
		 Summary summary = new Summary();
		
			 summarydata =  userDao.Reportspdf(first, last ,username);

	
		List<Summary> summaryReport = new ArrayList<>();
		for (Map.Entry<String, Summary> entry : summarydata.entrySet()) {
			summary = entry.getValue();
			summary.setTotalCount(Integer.toString(Integer.parseInt(summary.getActivate_Incorrectattempt())
					+ Integer.parseInt(summary.getActivate_Retrievereferencenumber())
					+ Integer.parseInt(summary.getDeActivate_Incorrectattempt())
					+ Integer.parseInt(summary.getDeActivate_Retrievereferencenumber())
					+ Integer.parseInt(summary.getGetRef_Incorrectattempt())
					+ Integer.parseInt(summary.getGetRef_Retrievereferencenumber())
					+ Integer.parseInt(summary.getGetUid_Incorrectattempt())
					+ Integer.parseInt(summary.getGetUid_Retrievereferencenumber())
					+ Integer.parseInt(summary.getStrUid_Aadhaarduplicatecheck())
					+ Integer.parseInt(summary.getStrUid_Getexistingreferencenumber())
					+ Integer.parseInt(summary.getStrUid_StoreAadhaarNumber())
					
					));
			summaryReport.add(summary);
			
		}
		Map<String, Object> empParams = new HashMap<String, Object>();	
		try {
			
		//CollectionBeanParam
		//BillingParam
//		empParams.put("CollectionBeanParam", new JRBeanCollectionDataSource(billSer.getOprSummary()));;
		empParams.put("CollectionParamBean", new JRBeanCollectionDataSource(summaryReport));
//		empParams.put("ADDRESS", new JRBeanCollectionDataSource(CategoryData));
		empParams.put("DeptName",deptnamenadcode[1] );
//		empParams.put("Quarter", Quarter);
//		empParams.put("SlabRate", js.getSlab());
//		empParams.put("TotalCount", Integer.toString(totalcounts));
//		empParams.put("TotalAmount", js.getAmount());
	
		JasperPrint empReport = JasperFillManager.fillReport(JasperCompileManager
//				.compileReport(ResourceUtils.getFile("classpath:CategoryWiseBill.jrxml").getAbsolutePath()) // path
				.compileReport(ResourceUtils.getFile("classpath:Summary3.jrxml").getAbsolutePath()) // path
																												// of
																												// the
																												// jasper
																												// report
				, empParams // dynamic parameters
				, new JREmptyDataSource());

		HttpHeaders headers = new HttpHeaders();
		// set the PDF format
		headers.setContentType(MediaType.APPLICATION_PDF);
		headers.setContentDispositionFormData("filename", "Summary.pdf");
		// create the report in PDF format
		return new ResponseEntity<byte[]>(JasperExportManager.exportReportToPdf(empReport), headers, HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<byte[]>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	 
//		return userDao.Reportspdf(first, last ,username);
	}
	
	

//	******************************************************************************************************************

	@Override
	public List<AppList> getAppListR(String deptcode) {
		// TODO Auto-generated method stub
		return userDao.getAppListR(deptcode);
	}

	@Override
	public AppDetail getAppDetailR(String appcode) {
		// TODO Auto-generated method stub
		return userDao.getAppDetailR(appcode);
	}

	@Override
	public AppLk getAppLkR(String appcode) {
		// TODO Auto-generated method stub
		return userDao.getAppLkR(appcode);
	}

	@Override
	public AllowedOpr getOprR(String appcode) {
		// TODO Auto-generated method stub
		return userDao.getOprR(appcode);
	}

//	@Override
//	public String getAppUpdate(String email, String desc, String appname, String appcode) {
//		// TODO Auto-generated method stub
//		return dao.getAppUpdate(email,desc,appname,appcode);
//	}

	@Override
	public String getOprUpdateR(AllowedOpr opr, String appcode) {
		// TODO Auto-generated method stub
		return userDao.getOprUpdateR(opr, appcode);
	}

	@Override
	public String getAppUpdateR(AppDetail appdetail, String appcode) {
		// TODO Auto-generated method stub
		return userDao.getAppUpdateR(appdetail, appcode);
	}

	@Override
	public String getstruidR(AllowedOpr opr, String appcode) {
		// TODO Auto-generated method stub
		return userDao.getstruidR(opr, appcode);
	}

	@Override
	public String getrefnumR(AllowedOpr opr, String appcode) {
		// TODO Auto-generated method stub
		return userDao.getrefnumR(opr, appcode);
	}

	@Override
	public String getuidR(AllowedOpr opr, String appcode) {
		// TODO Auto-generated method stub
		return userDao.getuidR(opr, appcode);
	}

	@Override
	public String getactivateR(AllowedOpr opr, String appcode) {
		// TODO Auto-generated method stub
		return userDao.getactivateR(opr, appcode);
	}

	@Override
	public String getdeactivateR(AllowedOpr opr, String appcode) {
		// TODO Auto-generated method stub
		return userDao.getdeactivateR(opr, appcode);
	}

	@Override
	public String getEmailUpdateR(AppDetail appdetail, String appcode) {
		// TODO Auto-generated method stub
		return userDao.getEmailUpdateR(appdetail, appcode);
	}

	@Override
	public String getAppnameUpdateR(AppDetail appdetail, String appcode) {
		// TODO Auto-generated method stub
		return userDao.getAppnameUpdateR(appdetail, appcode);
	}

	@Override
	public String getlkexpiryupdateR(AppLk applkex, String appcode) {
		// TODO Auto-generated method stub
		return userDao.getlkexpiryupdateR(applkex, appcode);
	}

	@Override
	public String generatelkR(GenerateAppLK genlk, String appcode) {
		// TODO Auto-generated method stub
		return userDao.generatelkR(genlk, appcode);
	}

	@Override
	public String getdupcheckR(AllowedOpr opr, String appcode) {
		// TODO Auto-generated method stub
		return userDao.getdupcheckR(opr, appcode);
	}

	@Override
	public List<DeptList> getDeptListR() {
		// TODO Auto-generated method stub
		return userDao.getDeptListR();
	}

	@Override
	public DeptList getDeptcodeFromUsername(String username) {
		// TODO Auto-generated method stub
		return userDao.getDeptcodeFromUsername(username);
	}

	// 28-09-2022
	@Override
	public AppLk getAdminAppLkR(String appcode) {
		// TODO Auto-generated method stub
		return userDao.getAdminAppLkR(appcode);
	}

	@Override
	public String appCreateR(AppDetail appcreate, String deptcode) {
		// TODO Auto-generated method stub
		return userDao.appCreateR(appcreate, deptcode);
	}

	@Override
	public String deptRegistrationR(DeptDetails deptdetails) {
		// TODO Auto-generated method stub
		return userDao.deptRegistrationR(deptdetails);
	}

	@Override
	public List<OprList> getOprList() {
		// TODO Auto-generated method stub
		return userDao.getOprList();
	}

	@Override
	public List<Algo_Info> getAlgoIdList() {
		// TODO Auto-generated method stub
		return userDao.getAlgoIdList();
	}

	@Override
	public List<Slot> getSlotList() {
		// TODO Auto-generated method stub
		return userDao.getSlotList();
	}

	@Override
	public List<KeyInfo> getKeyId() {
		// TODO Auto-generated method stub
		return userDao.getKeyId();
	}

	@Override
	public KeyInfo getKeyinfo(int key_info_id) {
		// TODO Auto-generated method stub
		return userDao.getKeyinfo(key_info_id);
	}

	@Override
	public DeptList getDeptnamewithDeptcode(String deptcode) {
		// TODO Auto-generated method stub
		return userDao.getDeptnamewithDeptcode(deptcode);
	}

	@Override
	public String keyMappingInsert(KeyMapping keymap) {
		// TODO Auto-generated method stub
		return userDao.keyMappingInsert(keymap);
	}

	@Override
	public String keyInfoInsert(KeyInfo keyinfo, String deptcode) {
		// TODO Auto-generated method stub
		return userDao.keyInfoInsert(keyinfo, deptcode);
	}

	@Override
	public long getDataForChart(String date ,String Username) {
		// TODO Auto-generated method stub
		return userDao.getDataForChart(date,Username);
	}

	@Override
	public List<String> getActivityListByUsername(String username, String tenant) {
		// TODO Auto-generated method stub
		return userDao.getActivityListByUsername(username, tenant);
	}

	@Override
	public List<String> getactivityofuser(String user) {
		// TODO Auto-generated method stub
		return userDao.getactivityofuser(user);
	}

	public ArrayList<String> test(String username) {

		//HashMap<String, ArrayList<String>> ret = new HashMap<String, ArrayList<String>>();
		String key = null;
		//ArrayList<String> schemaname = new ArrayList<>();
		ArrayList<String> l = new ArrayList<>();
		ArrayList<String> finaleRoles = new ArrayList<>();

		PreparedStatement p;
		ResultSet r;

		Map<String, ArrayList<String>> roleActivity = rdao.getroleActivity();
		Map<String, String> userRole = rdao.getuserRole();

		Map<String, String> activityIdActivity = rdao.getactivityIdActivity();
		Map<String, String> userActivity = rdao.getuserActivity();
		List<String> userName = rdao.getuserName();

		rdao.fillroleActivity(roleActivity);

		for (Map.Entry<String, String> entry : userRole.entrySet()) {

			String val = entry.getValue();
			ArrayList<String> list = null;
			for (Entry<String, ArrayList<String>> entry2 : roleActivity.entrySet())

			{
				String temp = entry2.getKey();

				if (val.charAt(0) == temp.charAt(0)) {
					list = roleActivity.get(temp);
				}
			}
			for (String nameOfRoles : list) {
				if (entry.getKey().contentEquals(username)) {
				//	System.out.println("this is FINAL key===========" + entry.getValue());
					key = entry.getValue();
				//	System.out.println(activityIdActivity.get(nameOfRoles));
					finaleRoles.add(activityIdActivity.get(nameOfRoles));
				}
			}
		//		System.out.println(" ");
		}
	//	System.out.println(" ");

		//ret.put(key, finaleRoles);
		return finaleRoles;
	}

	@Override
	public List<Activities> getActivity() {
		// TODO Auto-generated method stub
		return userDao.getActivity();
	}

	@Override
	public String getuserroleinsertR(UserRolesforUserManagement userrole) {
		// TODO Auto-generated method stub
		return userDao.getuserroleinsertR(userrole);
	}

	@Override
	public String getroleactivityinsertR(RoleActivity roleact) {
		// TODO Auto-generated method stub
		return userDao.getroleactivityinsertR(roleact);
	}

	@Override
	public String keyinfoinsertforsoft(KeyInfo keyinfo, String deptcode) {
		// TODO Auto-generated method stub
		return userDao.keyinfoinsertforsoft(keyinfo,deptcode);
				}

	@Override
	public String getDeptcodeFromUsernameforreport(String username) {
		// TODO Auto-generated method stub
		return userDao.getDeptcodeFromUsernameforreport(username);
	}

	@Override
	public ResponseEntity<byte[]> getSummaryForJasperIgnite(String[] datedata, String username) {
		logger.info("getSummaryForJasperIgnite  "+datedata[0]+"="+datedata[1]+"="+datedata[2]);
		String[] dates = getStartandLastDate(datedata);
		String startDate= dates[0];
		String lastDate = dates[1];		
		logger.info("StartDate: "+startDate +" lastDate: "+lastDate+" User: "+username);
		try {
			String nameandcode = userDao.getDeptcodeFromUsernameforreport(username);
			String[] deptnamenadcode = nameandcode.split(",");
			logger.info("getSummaryForJasperIgnite Deptcode: " + "username==" + username + "-" + deptnamenadcode[0]
					+ "-" + deptnamenadcode[1]);
			String url = env.getProperty("igniteapiforreports");
			RestTemplate rt = new RestTemplate();
			String[] arr = { deptnamenadcode[0], startDate, lastDate };
			byte[] bdata = rt.postForObject(url, arr, byte[].class);
			ArrayList<String> resAl = new ArrayList<String>();
			resAl = (ArrayList<String>) SerializationUtils.deserialize(bdata);
			BillingServices.resAl = resAl;
			logger.info("getSummaryForJasperIgnite Deptcode: " + deptnamenadcode[0]);
			List<Summary> summaryReport = new ArrayList<>();
			summaryReport = billSer.getOprSummaryForJasper(deptnamenadcode[0]);
			 if(summaryReport==null)
			 {
				 throw new Exception("Data not found for request");
			 }
			Map<String, Object> empParams = new HashMap<String, Object>();
			empParams.put("CollectionParamBean", new JRBeanCollectionDataSource(summaryReport));
			empParams.put("DeptName", deptnamenadcode[1]);
			JasperPrint Report = JasperFillManager.fillReport(JasperCompileManager
					.compileReport(ResourceUtils.getFile("classpath:SummaryDept.jrxml").getAbsolutePath()), empParams // dynamic
																													// parameters
					, new JREmptyDataSource());

			HttpHeaders headers = new HttpHeaders();
			// set the PDF format
			headers.setContentType(MediaType.APPLICATION_PDF);
			headers.setContentDispositionFormData("filename", "Summary.pdf");
			logger.info("File Generated");
			// create the report in PDF format
			return new ResponseEntity<byte[]>(JasperExportManager.exportReportToPdf(Report), headers, HttpStatus.OK);
		} catch (Exception e) {
			logger.info("Exception "+e.getMessage());
			return new ResponseEntity<byte[]>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	

	@Override
	public ResponseEntity<byte[]> getSummaryForJasperIgniteapp(String[] datedata, String username) {	
		logger.info("getSummaryForJasperIgnite  "+datedata[0]+"="+datedata[1]+"="+datedata[2]);
		String[] dates = getStartandLastDate(datedata);
		String first= dates[0];
		String last = dates[1];	
		logger.info("StartDate: "+first +" lastDate: "+last);
		try {	
		String url=env.getProperty("igniteapiforappwisereport");
		RestTemplate rt = new RestTemplate();
		String [] arr= {"A100006",first,last};
		byte [] bdata=rt.postForObject(url, arr,byte[].class);
		ArrayList<String> resAl = new ArrayList<String>();
		resAl = (ArrayList<String>) SerializationUtils.deserialize(bdata);		
		BillingServices.resAl = resAl;	
		 List<Summary> summaryReport = new ArrayList<>();
		 summaryReport =  billSer.getOprSummaryForJasperApkWise("A100006");
		 if(summaryReport==null)
		 {
			 throw new Exception("Data not found for request");
		 }
		Map<String, Object> empParams = new HashMap<String, Object>();	
		empParams.put("CollectionParamBean", new JRBeanCollectionDataSource(summaryReport));
		System.out.println("File Generated");
		JasperPrint empReport = JasperFillManager.fillReport(JasperCompileManager
				.compileReport(ResourceUtils.getFile("classpath:SummaryApp.jrxml").getAbsolutePath()) 
				, empParams // dynamic parameters
				, new JREmptyDataSource());

		HttpHeaders headers = new HttpHeaders();
		// set the PDF format
		headers.setContentType(MediaType.APPLICATION_PDF);
		headers.setContentDispositionFormData("filename", "Summary.pdf");
		// create the report in PDF format
		return new ResponseEntity<byte[]>(JasperExportManager.exportReportToPdf(empReport), headers, HttpStatus.OK);
		} catch (Exception e) {
			logger.info("getSummaryForJasperIgniteapp exception "+e.getMessage());
			return new ResponseEntity<byte[]>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	
	

	@Override
	public ResponseEntity<byte[]> getBillingDataForPdf(String[] datedata, String username) {
		logger.info("getBillingDataForPdf  "+datedata[0]+"="+datedata[1]+"="+datedata[2]);
		String[] dates = getStartandLastDate(datedata);
		String first = dates[0];

		int totalcounts = 0;
		double value = 0;
		double totalamt=0;
		String Quarter = "";
		int quarterNo;
        LocalDate localDate = LocalDate.parse(first);
        quarterNo = localDate.get(IsoFields.QUARTER_OF_YEAR);     
		try {
			in.cdac.portal.billing.JasperBill js = BillingServices.jasp;
			if(js.getTotalApkCount()==0) {
				throw new Exception("TotalCount is Zero ");
			}
			Integer count = js.getTotalApkCount();
			String deptcode = js.getDc();
			  logger.info("totalcount: "+ count+ " deptcode: "+deptcode + " Username: "+username);
			String url= env.getProperty("igniteapiforbiling");
			RestTemplate rt = new RestTemplate();
			
			String[] arr = { String.valueOf(count), deptcode };
			String[] billingDetails = rt.postForObject(url, arr, String[].class);

			js.setSlab(billingDetails[0]);
			js.setQuarter(Integer.toString(quarterNo));
			totalamt= Double.parseDouble(new DecimalFormat("##.##")
					.format(Double.parseDouble(Integer.toString(js.getTotalApkCount())) * Double.parseDouble(js.getSlab())));
						
			List<Billing> billData = new ArrayList<Billing>();			
			for (Map.Entry<String, String> entry : js.getBreakup().entrySet()) {
				totalcounts = totalcounts + Integer.parseInt(entry.getValue());
				value = Double.parseDouble(new DecimalFormat("##.##")
						.format(Double.parseDouble(entry.getValue()) * Double.parseDouble(js.getSlab())));
				billData.add(new Billing(entry.getKey(), Integer.parseInt(entry.getValue()), value));
			}

			if (js.getQuarter().trim().equalsIgnoreCase("1")) {

				Quarter = "January - March (IVth Quarter)";
			} else if (js.getQuarter().trim().equalsIgnoreCase("2")) {

				Quarter = "April - June (Ist Quarter)";
			} else if (js.getQuarter().trim().equalsIgnoreCase("3")) {

				Quarter = "July - September (IInd Quarter)";

			} else if (js.getQuarter().trim().equalsIgnoreCase("4")) {

				Quarter = "October - December (IIIrd Quarter)";
			}		
			
			List<BillingDetails> summaryReport = new ArrayList<>();
			summaryReport.add(new BillingDetails("Department Name ",js.getDeptName()));			
			summaryReport.add(new BillingDetails("Bill To",billingDetails[2]));
			summaryReport.add(new BillingDetails("Address",billingDetails[3]));
			summaryReport.add(new BillingDetails("GST",billingDetails[1]));			
			summaryReport.add(new BillingDetails("Total Transaction",Integer.toString(js.getTotalApkCount())));
			summaryReport.add(new BillingDetails("Slab Rate",billingDetails[0]));
			summaryReport.add(new BillingDetails("Total Amount",Double.toString(totalamt)));			

			List<BillingDetails> Billdataforbelow2500 = new ArrayList<>();			
			Billdataforbelow2500.add(new BillingDetails("Department Name ",js.getDeptName()));			
			Billdataforbelow2500.add(new BillingDetails("Total Counts",Integer.toString(totalcounts)));		
			Billdataforbelow2500.add(new BillingDetails("Total Amount","2500.00"));
			Map<String, Object> BillParamBelow2500 = new HashMap<String, Object>();
			BillParamBelow2500.put("CollectionForDetails", new JRBeanCollectionDataSource(Billdataforbelow2500));
			BillParamBelow2500.put("Quarter", Quarter);
			
			Map<String, Object> BillParam = new HashMap<String, Object>();
			BillParam.put("CollectionBeanParam", new JRBeanCollectionDataSource(billData));
			BillParam.put("CollectionForDetails", new JRBeanCollectionDataSource(summaryReport));
			BillParam.put("Quarter", Quarter);
			BillParam.put("TotalCount", Integer.toString(totalcounts));
			BillParam.put("TotalAmount", Double.toString(totalamt));
			JasperPrint NormalReport = JasperFillManager.fillReport(
					JasperCompileManager.compileReport(ResourceUtils.getFile("classpath:BillWithSum.jrxml").getAbsolutePath())																													
					, BillParam // dynamic parameters
					, new JREmptyDataSource());
			
			JasperPrint ReportBelow2500 = JasperFillManager.fillReport(
					JasperCompileManager.compileReport(ResourceUtils.getFile("classpath:BillWithSumBelow2500.jrxml").getAbsolutePath())																													
					, BillParamBelow2500 // dynamic parameters
					, new JREmptyDataSource());


			HttpHeaders headers = new HttpHeaders();
			// set the PDF format
			headers.setContentType(MediaType.APPLICATION_PDF);
			headers.setContentDispositionFormData("filename", "Billing.pdf");
			// create the report in PDF format		
			if(totalamt<=2500)
			{
				return new ResponseEntity<byte[]>(JasperExportManager.exportReportToPdf(ReportBelow2500), headers, HttpStatus.OK);
				
			}else {
				return new ResponseEntity<byte[]>(JasperExportManager.exportReportToPdf(NormalReport), headers, HttpStatus.OK);
			}
			
		} catch (Exception e) {
			logger.info("getBillingDataForPdf data not found  total count zero "+e.getMessage());
			return new ResponseEntity<byte[]>(HttpStatus.INTERNAL_SERVER_ERROR);
		}		
	}

	
	

	@Override
	public ResponseEntity<byte[]> getBillingDataForPdfapp(String[] datedata, String username) {
		// TODO Auto-generated method stub
		String[] dates = getStartandLastDate(datedata);
		String first = dates[0];
		String last = dates[0];
		int totalcounts = 0;
		double value = 0;
		double totalamt=0;
		String Quarter = "";
		int quarterNo;
        LocalDate localDate = LocalDate.parse(first);
        quarterNo = localDate.get(IsoFields.QUARTER_OF_YEAR);
        logger.info("Quarter: "+quarterNo);
        logger.info("StartDate: "+first +" lastDate: "+last);
		try {
			in.cdac.portal.billing.JasperBill js = BillingServices.jasp;
			if(js.getTotalApkCount()==0) {
				throw new Exception("TotalCount is Zero");
			}
			String url= env.getProperty("igniteapiforappwisebill");
			RestTemplate rt = new RestTemplate();
//			String[] arr = {String.valueOf(js.getTotalApkCount()), "A100006" };
			String [] arr= {"A100006",first,last};
			String[] billingDetails = rt.postForObject(url, arr, String[].class);

			js.setSlab(billingDetails[0]);
			js.setQuarter(Integer.toString(quarterNo));
			totalamt= Double.parseDouble(new DecimalFormat("##.##")
					.format(Double.parseDouble(Integer.toString(js.getTotalApkCount())) * Double.parseDouble(js.getSlab())));
						
			List<Billing> billData = new ArrayList<Billing>();			
			for (Map.Entry<String, String> entry : js.getBreakup().entrySet()) {
				System.out.println(entry.getKey() + " " + entry.getValue());
				String key = entry.getKey();
				String val = entry.getValue();
				totalcounts = totalcounts + Integer.parseInt(entry.getValue());
				value = Double.parseDouble(new DecimalFormat("##.##")
						.format(Double.parseDouble(entry.getValue()) * Double.parseDouble(js.getSlab())));
				billData.add(new Billing(entry.getKey(), Integer.parseInt(entry.getValue()), value));
			}

			if (js.getQuarter().trim().equalsIgnoreCase("1")) {

				Quarter = "January - March (IVth Quarter)";
			} else if (js.getQuarter().trim().equalsIgnoreCase("2")) {

				Quarter = "April - June (Ist Quarter)";
			} else if (js.getQuarter().trim().equalsIgnoreCase("3")) {

				Quarter = "July - September (IInd Quarter)";

			} else if (js.getQuarter().trim().equalsIgnoreCase("4")) {

				Quarter = "October - December (IIIrd Quarter)";
			}		
			
			List<BillingDetails> summaryReport = new ArrayList<>();
//			summaryReport.add(new BillingDetails("Department Name ",js.getDeptName()));			
			summaryReport.add(new BillingDetails("Bill To",billingDetails[2]));
			summaryReport.add(new BillingDetails("Address",billingDetails[3]));
			summaryReport.add(new BillingDetails("GST",billingDetails[1]));			
			summaryReport.add(new BillingDetails("Total Transaction",Integer.toString(js.getTotalApkCount())));
			summaryReport.add(new BillingDetails("Slab Rate",billingDetails[0]));
			summaryReport.add(new BillingDetails("Total Amount",Double.toString(totalamt)));			

			Map<String, Object> empParams = new HashMap<String, Object>();
			empParams.put("CollectionBeanParam", new JRBeanCollectionDataSource(billData));
			empParams.put("CollectionForDetails", new JRBeanCollectionDataSource(summaryReport));
			empParams.put("Quarter", Quarter);
			empParams.put("TotalCount", Integer.toString(totalcounts));
			empParams.put("TotalAmount", Double.toString(totalamt));
			System.out.println("File Generated");
			JasperPrint empReport = JasperFillManager.fillReport(
					JasperCompileManager.compileReport(ResourceUtils.getFile("classpath:BillWithSumAppwise.jrxml").getAbsolutePath())																													
					, empParams // dynamic parameters
					, new JREmptyDataSource());

			HttpHeaders headers = new HttpHeaders();
			// set the PDF format
			headers.setContentType(MediaType.APPLICATION_PDF);
			headers.setContentDispositionFormData("filename", "Billing.pdf");
			// create the report in PDF format
			return new ResponseEntity<byte[]>(JasperExportManager.exportReportToPdf(empReport), headers, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<byte[]>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	public Date firstDateOfMonth(int monthIndex, int year) {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.MONTH, monthIndex);
		calendar.set(Calendar.DAY_OF_MONTH, 1);
		calendar.set(Calendar.YEAR, year);
		Date date = calendar.getTime();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String fDate = dateFormat.format(date);
		Date d = null;
		try {
			d = new SimpleDateFormat("yyyy-MM-dd").parse(fDate);
		} catch (ParseException e) {
			logger.info("Exception for parsing month and year " + e.getMessage());
		}
		return d;
	}

	public Date lastDateOfMonth(int monthIndex, int year) {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.MONTH, monthIndex);
		boolean leapYear = false;
		if (year % 4 == 0) {
			leapYear = true;
		}
		calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
		if (monthIndex == 1 && leapYear == false) {
			calendar.set(Calendar.DAY_OF_MONTH, 28);
		}
		calendar.set(Calendar.YEAR, year);
		Date date = calendar.getTime();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String fDate = dateFormat.format(date);
		Date d = null;
		try {
			d = new SimpleDateFormat("yyyy-MM-dd").parse(fDate);
		} catch (ParseException e) {
			logger.info("Exception for parsing month and year " + e.getMessage());
		}
		return d;
	}

	public static String getproperDate(String Date) {
		SimpleDateFormat inSDF = new SimpleDateFormat("yyyy-mm-dd");
		SimpleDateFormat outSDF = new SimpleDateFormat("mm-dd-yyyy");
		String outDate = "";
		Date date = null;
		try {
			date = outSDF.parse(Date);
		} catch (ParseException e) {

			logger.info("Exception for parsing proper date " + e.getMessage());
		}
		outDate = inSDF.format(date);
		return outDate;
	}
	
	
	private String[] getStartandLastDate(String[] datedata) {
		String[] StartandLastDates = {"",""};
		logger.info("getStartandLastDate  "+datedata[0]+"="+datedata[1]+"="+datedata[2]);
		try {				
		if(datedata[0].contentEquals("month"))
		{
			YearMonth yearMonth = YearMonth.of(Integer.parseInt(datedata[2]), Integer.parseInt(datedata[1]));
			LocalDate firstOfMonth = yearMonth.atDay(1);
			LocalDate lastOfMonth = yearMonth.atEndOfMonth();
			String first = firstOfMonth.toString();
			String last = lastOfMonth.toString();
			StartandLastDates[0]=first;
			StartandLastDates[1]=last;
			return StartandLastDates;
		}else if(datedata[0].contentEquals("qaurter"))
		{
			YearMonth quaterfirstyearMonth = YearMonth.of(Integer.parseInt(datedata[2]), Integer.parseInt(datedata[1]));
			LocalDate firstOfMonth = quaterfirstyearMonth.atDay(1);
			YearMonth quaterlastyearMonth = YearMonth.of(Integer.parseInt(datedata[2]),
					Integer.parseInt(datedata[1]) + 2);
			LocalDate lastOfMonth = quaterlastyearMonth.atEndOfMonth();
			String first = firstOfMonth.toString();
			String last = lastOfMonth.toString();
			StartandLastDates[0]=first;
			StartandLastDates[1]=last;
			logger.info(StartandLastDates[0]+"=="+StartandLastDates[1]);
			return StartandLastDates;
		}if(datedata[0].contentEquals("year"))
		{
			String first = datedata[1] + "-" + "01" + "-" + "01";
			String last = datedata[1] + "-" + "12" + "-" + "31";
			StartandLastDates[0]=first;
			StartandLastDates[1]=last;
			return StartandLastDates;
			
		}if(datedata[0].contentEquals("custom"))
		{
			StartandLastDates[0]=datedata[1];
			StartandLastDates[1]=datedata[2];
			return StartandLastDates;
		}else 
		if(datedata[0].contentEquals("bill"))
		{
			YearMonth quaterfirstyearMonth = YearMonth.of(Integer.parseInt(datedata[2]), Integer.parseInt(datedata[1]));
			LocalDate firstOfMonth = quaterfirstyearMonth.atDay(1);
			YearMonth quaterlastyearMonth = YearMonth.of(Integer.parseInt(datedata[2]),
					Integer.parseInt(datedata[1]) + 2);
			LocalDate lastOfMonth = quaterlastyearMonth.atEndOfMonth();
			String first = firstOfMonth.toString();
			String last = lastOfMonth.toString();
			StartandLastDates[0]=first;
			StartandLastDates[1]=last;
			return StartandLastDates;
		}
		
		
		
		} catch (Exception e) {
			// TODO: handle exception
			logger.info(e.getMessage());
		}		
		return null;
	}
	
}