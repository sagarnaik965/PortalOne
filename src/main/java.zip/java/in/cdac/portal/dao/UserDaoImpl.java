package in.cdac.portal.dao;

import java.io.IOException;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.temporal.IsoFields;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.UUID;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import in.cdac.dbswitch.CustomeUserDetails;
import in.cdac.portal.billing.GetFileData;
import in.cdac.portal.billing.Report;
import in.cdac.portal.entities.User;
import in.cdac.portal.modal.AboutToExpireCertificate;
import in.cdac.portal.modal.AboutToExpireLK;
import in.cdac.portal.modal.AcCode;
import in.cdac.portal.modal.Activities;
import in.cdac.portal.modal.AddUser;
import in.cdac.portal.modal.AdminDeptCount;
import in.cdac.portal.modal.Algo_Info;
import in.cdac.portal.modal.AllowedOpr;
import in.cdac.portal.modal.AppDetail;
import in.cdac.portal.modal.AppList;
import in.cdac.portal.modal.AppLk;
import in.cdac.portal.modal.AuthCount;
import in.cdac.portal.modal.Cert_types;
import in.cdac.portal.modal.CertificateDetails;
import in.cdac.portal.modal.ConnectorParam;
import in.cdac.portal.modal.DeptDetails;
import in.cdac.portal.modal.DeptList;
import in.cdac.portal.modal.DetailedTransaction;
import in.cdac.portal.modal.ErrorCodeCount;
import in.cdac.portal.modal.ForgetPassword;
import in.cdac.portal.modal.FraudDetectionObject;
import in.cdac.portal.modal.GenerateAppLK;
import in.cdac.portal.modal.GenerateUdcCode;
import in.cdac.portal.modal.KeyInfo;
import in.cdac.portal.modal.KeyMapping;
import in.cdac.portal.modal.KuaLk;
import in.cdac.portal.modal.LicenceType;
import in.cdac.portal.modal.LicensekeyDetails;
import in.cdac.portal.modal.OprList;
import in.cdac.portal.modal.ProfileDetail;
import in.cdac.portal.modal.ResendActivationList;
import in.cdac.portal.modal.RoleActivity;
import in.cdac.portal.modal.SignBy;
import in.cdac.portal.modal.SigningDetails;
import in.cdac.portal.modal.SigningType;
import in.cdac.portal.modal.Slot;
import in.cdac.portal.modal.StateList;
import in.cdac.portal.modal.SuccessCount;
import in.cdac.portal.modal.Summary;
import in.cdac.portal.modal.TransactionCountDetails;
import in.cdac.portal.modal.TransactionCountTotal;
import in.cdac.portal.modal.TransactionDetailReport;
import in.cdac.portal.modal.UpdateAuaLk;
import in.cdac.portal.modal.UserRolesforUserManagement;
import in.cdac.portal.modal.UserStatus;
import in.cdac.portal.util.Util;

@Service
public class UserDaoImpl implements UserDao {

	private final static Logger logger = Logger.getLogger(UserDaoImpl.class);



	@Autowired
	@Qualifier("test_ds")
	DataSource ds1;

	@Autowired
	@Qualifier("preproduction_ds")
	DataSource ds2;

	@Autowired
	@Qualifier("production_ds")
	DataSource ds3;

	@Autowired
	PasswordEncoder encoder;
	
	private JdbcTemplate jdbcTemplate(String tenantName) {
		logger.info("tenant name in getJDBCTemp::" + tenantName);
		if (tenantName.equalsIgnoreCase("test")) {
			JdbcTemplate temp = new JdbcTemplate(ds1);
			logger.info("return DS " + ds1.toString());
			return temp;
		} else if (tenantName.equalsIgnoreCase("preproduction")) {
			JdbcTemplate temp = new JdbcTemplate(ds2);
			logger.info("return DS " + ds2.toString());
			return temp;
		} else if (tenantName.equals("production")) {
			JdbcTemplate temp = new JdbcTemplate(ds3);
			logger.info("return DS " + ds3.toString());
			return temp;
		}
		logger.info("return DS NULL");
		return null;
	}

	
	
//	------------------------------------------Methods for react-----------------------------------------------------------------------------------------

	@Override
	public String getRole(String principal) {
		// TODO Auto-generated method stub
		try {
			
		
		JdbcTemplate select = jdbcTemplate("test");

		String url = "select role_id from user_roles where username = " + "'" + principal + "'" + ";";
		return select.query(url, new ResultSetExtractor<String>() {
			public String extractData(ResultSet rs) throws SQLException, DataAccessException {
				Map<String, String> map = new HashMap<String, String>();
				List<StateList> states = new ArrayList<>();
				String r = "";
				while (rs.next()) {
					r = rs.getString("role_id");

				}
				return r;
			}
		});
		
		} catch (Exception e) {
			// TODO: handle exception
			return null;
		}
	}
	
	

	@Override
	public List<String> getactivityofuser(String username)  {
	
		try {
			
		
		JdbcTemplate select = jdbcTemplate("test");
		String url = "select a.activity as activity from activities a join role_activities ra on a.activity_id = ra.activity_id join  user_roles ur on ra.role_id = ur.role_id  where ur.username = '"
				+ username + "'; ";
		return select.query(url, new ResultSetExtractor<List<String>>() {
			public List<String> extractData(ResultSet rs) throws SQLException, DataAccessException {
				List<String> activity = new ArrayList<>();
				while (rs.next()) {
					activity.add(rs.getString("activity"));
				}
				return activity;
			}
		});
		} catch (Exception e) {
			logger.info("Problem in fetching username "+e.getMessage());
			return null;
		}
		
		
	}
	
	

	@Override
	public List<String[]> Reports(String firstOfMonth, String lastOfMonth, String username) {
		// TODO Auto-generated method stub

		System.out.println(
				"select sum(txn_count) filter(where status ilike'y') as success, sum(txn_count) filter(where status ilike 'n') as unsuccess, sum(txn_count) filter (where status ilike 'y' or status ilike 'n') as Total from trans_stats where ac in(select app_code  from application_details where dept_code in (select schema_name from dept_details where username='"
						+ username + "')) and date BETWEEN " + "'" + firstOfMonth + "'" + " and " + "'" + lastOfMonth
						+ "'" + ";");
		String Url = "select sum(txn_count) filter(where status ilike'y') as success, sum(txn_count) filter(where status ilike 'n') as unsuccess, sum(txn_count) filter (where status ilike 'y' or status ilike 'n') as Total from trans_stats where ac in(select app_code  from application_details where dept_code in (select schema_name from dept_details where username='"
				+ username + "')) and date BETWEEN " + "'" + firstOfMonth + "'" + " and " + "'" + lastOfMonth + "'"
				+ ";";
//		System.out.println("url in dao  "+Url);
		List<String[]> myList = new ArrayList<String[]>();
		String[] s1 = { "Succesful", "UnSuccessfull", "Total" };
		myList.add(s1);

		JdbcTemplate select = jdbcTemplate("test");
		int count = 0;
		return select.query(Url, new ResultSetExtractor<List<String[]>>() {

			public List<String[]> extractData(ResultSet rs) throws SQLException, DataAccessException {
				while (rs.next()) {
//							System.out.println(rs.getString("success") +" "+ rs.getString("unsuccess") +" "+ rs.getString("Total"));
					String[] s2 = { rs.getString("success"), rs.getString("unsuccess"), rs.getString("Total") };
					myList.add(s2);
					System.out.println(rs.getString("success")+" "+rs.getString("unsuccess")+" "+rs.getString("Total"));
				}
				return myList;
			}
		});
	}
	
	
	public Map<String, Summary>  Reportspdf(String firstOfMonth, String lastOfMonth, String username) {
		// TODO Auto-generated method stub

		System.out.println(
				 "SELECT a.app_name as appname, sum( t.txn_count) as cnt ,t.is_exist_ref_num as getref ,t.opr as op , t.status as status  from dept_details  as d inner join application_details as a on d.dept_code=a.dept_code left join trans_stats as t  on a.app_code=t.ac\r\n"
							+ " where d.username='"+username+"' and  date BETWEEN '"+firstOfMonth+"' and '"+lastOfMonth+"' group by getref ,op , appname ,status ;");
		String Url = "SELECT a.app_name as appname, sum( t.txn_count) as cnt ,t.is_exist_ref_num as getref ,t.opr as op , t.status as status  from dept_details  as d inner join application_details as a on d.dept_code=a.dept_code left join trans_stats as t  on a.app_code=t.ac\r\n"
				+ " where d.username='"+username+"' and  date BETWEEN '"+firstOfMonth+"' and '"+lastOfMonth+"' group by getref ,op , appname ,status ;";

		
		//		System.out.println("url in dao  "+Url);
		List<String[]> myList = new ArrayList<String[]>();
		String[] s1 = { "Succesful", "UnSuccessfull", "Total" };
		myList.add(s1);

		JdbcTemplate select = jdbcTemplate("test");
		
		 Map<String, Summary> summarydata = new HashMap<>();
		Summary summaryobj = new Summary();
		summaryobj.setActivate_Incorrectattempt("0");
		summaryobj.setActivate_Retrievereferencenumber("0");
		summaryobj.setDeActivate_Incorrectattempt("0");
		summaryobj.setDeActivate_Retrievereferencenumber("0");
		summaryobj.setGetRef_Incorrectattempt("0");
		summaryobj.setGetRef_Retrievereferencenumber("0");
		summaryobj.setGetUid_Incorrectattempt("0");
		summaryobj.setGetUid_Retrievereferencenumber("0");
		summaryobj.setStrUid_Aadhaarduplicatecheck("0");
		summaryobj.setStrUid_Getexistingreferencenumber("0");
		summaryobj.setStrUid_StoreAadhaarNumber("0");
		summaryobj.setTotalCount("0");
		return select.query(Url, new ResultSetExtractor<Map<String, Summary> >() {

			public Map<String, Summary> extractData(ResultSet rs) throws SQLException, DataAccessException {
				while (rs.next()) {		
//					System.out.println("======================"+rs.getString("appname")+" "+rs.getString("cnt")+" "+rs.getString("getref")+" "+rs.getString("op") +" "+rs.getString("status"));
					if (summarydata.containsKey(rs.getString("appname"))) {					
						if (rs.getString("op").trim().equalsIgnoreCase("struid")) {
							if (rs.getString("getref")!=null && rs.getString("getref").trim().equalsIgnoreCase("f")) {
								int counts = 0;
//								if(summarydata.get(rs.getString("appname")) != null)
//								{
//									counts = Integer.parseInt(rs.getString("cnt")) +0;
//									
//								}else {							
//									
//									counts = Integer.parseInt(rs.getString("cnt")) + Integer.parseInt(
//											summarydata.get(rs.getString("appname")).getStrUid_Aadhaarduplicatecheck());
//								}
								counts = Integer.parseInt(rs.getString("cnt")) + Integer.parseInt(
										summarydata.get(rs.getString("appname")).getStrUid_Aadhaarduplicatecheck());
								
								summarydata.get(rs.getString("appname"))
										.setStrUid_Aadhaarduplicatecheck(Integer.toString(counts));

							} else if (rs.getString("getref")!=null && rs.getString("getref").trim().equalsIgnoreCase("t")) {
								int counts = 0;

								
								counts = Integer.parseInt(rs.getString("cnt")) + Integer.parseInt(summarydata
										.get(rs.getString("appname")).getStrUid_Getexistingreferencenumber());
								
								
								summarydata.get(rs.getString("appname"))
										.setStrUid_Getexistingreferencenumber(Integer.toString(counts));
							} else {
								int counts = 0;

								
								counts = Integer.parseInt(rs.getString("cnt")) + Integer.parseInt(
										summarydata.get(rs.getString("appname")).getStrUid_StoreAadhaarNumber());
								
								
								summarydata.get(rs.getString("appname"))
										.setStrUid_StoreAadhaarNumber(Integer.toString(counts));
							}

						} else if (rs.getString("op").trim().equalsIgnoreCase("getuid")) {
							if (rs.getString("status").trim().equalsIgnoreCase("y")) {
								int counts = 0;

								
								counts = Integer.parseInt(rs.getString("cnt")) + Integer.parseInt(
										summarydata.get(rs.getString("appname")).getGetUid_Retrievereferencenumber());
								
								summarydata.get(rs.getString("appname"))
										.setGetUid_Retrievereferencenumber(Integer.toString(counts));
							} else {
								int counts = 0;
								
								counts = Integer.parseInt(rs.getString("cnt")) + Integer.parseInt(
										summarydata.get(rs.getString("appname")).getGetUid_Incorrectattempt());
							
								summarydata.get(rs.getString("appname"))
										.setGetUid_Incorrectattempt(Integer.toString(counts));
							}

						} else if (rs.getString("op").trim().equalsIgnoreCase("getrefnum")) {
							if (rs.getString("status").trim().equalsIgnoreCase("y")) {
								int counts = 0;

								
								counts = Integer.parseInt(rs.getString("cnt")) + Integer.parseInt(
										summarydata.get(rs.getString("appname")).getGetRef_Retrievereferencenumber());								
								
								summarydata.get(rs.getString("appname"))
										.setGetRef_Retrievereferencenumber(Integer.toString(counts));
							} else {
								int counts = 0;								
								counts = Integer.parseInt(rs.getString("cnt")) + Integer.parseInt(
										summarydata.get(rs.getString("appname")).getGetRef_Incorrectattempt());
								
								summarydata.get(rs.getString("appname"))
										.setGetRef_Incorrectattempt(Integer.toString(counts));
							}

						} else if (rs.getString("op").trim().equalsIgnoreCase("activate")) {
							if (rs.getString("status").trim().equalsIgnoreCase("y")) {
								int counts = 0;

								
								counts = Integer.parseInt(rs.getString("cnt")) + Integer.parseInt(
										summarydata.get(rs.getString("appname")).getActivate_Retrievereferencenumber());
							
								summarydata.get(rs.getString("appname"))
										.setActivate_Retrievereferencenumber(Integer.toString(counts));

							} else {
								int counts = 0;

								
								counts = Integer.parseInt(rs.getString("cnt")) + Integer.parseInt(
										summarydata.get(rs.getString("appname")).getActivate_Incorrectattempt());
								
								summarydata.get(rs.getString("appname"))
										.setActivate_Incorrectattempt(Integer.toString(counts));
							}

						} else if (rs.getString("op").trim().equalsIgnoreCase("deactivate")) {
							if (rs.getString("status").trim().equalsIgnoreCase("y")) {
								int counts = 0;

								
								counts = Integer.parseInt(rs.getString("cnt")) + Integer.parseInt(summarydata
										.get(rs.getString("appname")).getDeActivate_Retrievereferencenumber());
								
								summarydata.get(rs.getString("appname"))
										.setDeActivate_Retrievereferencenumber(Integer.toString(counts));
							} else {
								int counts = 0;								
								counts = Integer.parseInt(rs.getString("cnt")) + Integer.parseInt(
										summarydata.get(rs.getString("appname")).getDeActivate_Incorrectattempt());
								
								summarydata.get(rs.getString("appname"))
										.setDeActivate_Incorrectattempt(Integer.toString(counts));
							}

						}

					} else {

						summarydata.put(rs.getString("appname"), summaryobj);
						summarydata.get(rs.getString("appname")).setApplicationName(rs.getString("appname"));					

						if (rs.getString("op").trim().equalsIgnoreCase("struid")) {
							if (rs.getString("getref").trim().equalsIgnoreCase("f")) {
								if(rs.getString("cnt").equals("null"))
								{
									summaryobj.setStrUid_Aadhaarduplicatecheck("0");
								}else {
									summaryobj.setStrUid_Aadhaarduplicatecheck(rs.getString("cnt"));
								}
								

							} else if (rs.getString("getref").trim().equalsIgnoreCase("t")) {
								if(rs.getString("cnt").equals("null"))
								{
									summaryobj.setStrUid_Getexistingreferencenumber("0");
								}else {
									summaryobj.setStrUid_Getexistingreferencenumber(rs.getString("cnt"));
								}
								
							} else {
								if(rs.getString("cnt").equals("null"))
								{
									summaryobj.setStrUid_StoreAadhaarNumber("0");
								}else {
									summaryobj.setStrUid_StoreAadhaarNumber(rs.getString("cnt"));
								}								
								
							}

						} else if (rs.getString("op").trim().equalsIgnoreCase("getuid")) {
							if (rs.getString("status").trim().equalsIgnoreCase("y")) {
								if(rs.getString("cnt").equals("null"))
								{
									summaryobj.setGetUid_Retrievereferencenumber("0");
								}else {
									summaryobj.setGetUid_Retrievereferencenumber(rs.getString("cnt"));
								}
								
							} else {
								if(rs.getString("cnt").equals("null"))
								{
									summaryobj.setGetUid_Incorrectattempt("0");
								}else {
									summaryobj.setGetUid_Incorrectattempt(rs.getString("cnt"));
								}
								
							}

						} else if (rs.getString("op").trim().equalsIgnoreCase("getrefnum")) {
							if (rs.getString("status").trim().equalsIgnoreCase("y")) {
								if(rs.getString("cnt").equals("null"))
								{
									summaryobj.setGetRef_Retrievereferencenumber("0");
								}else {
									summaryobj.setGetRef_Retrievereferencenumber(rs.getString("cnt"));
								}
								
							} else {
								if(rs.getString("cnt").equals("null"))
								{
									summaryobj.setGetRef_Incorrectattempt("0");
								}else {
									summaryobj.setGetRef_Incorrectattempt(rs.getString("cnt"));
								}
								
							}

						} else if (rs.getString("op").trim().equalsIgnoreCase("activate")) {
							if (rs.getString("status").trim().equalsIgnoreCase("y")) {
								if(rs.getString("cnt").equals("null"))
								{
									summaryobj.setActivate_Retrievereferencenumber("0");
								}else {
									summaryobj.setActivate_Retrievereferencenumber(rs.getString("cnt"));
								}
								

							} else {
								if(rs.getString("cnt").equals("null"))
								{
									summaryobj.setActivate_Incorrectattempt("0");
								}else {
									summaryobj.setActivate_Incorrectattempt(rs.getString("cnt"));
								}
								
							}

						} else if (rs.getString("op").trim().equalsIgnoreCase("deactivate")) {
							if (rs.getString("status").trim().equalsIgnoreCase("y")) {
								if(rs.getString("cnt").equals("null"))
								{
									summaryobj.setDeActivate_Retrievereferencenumber("0");
								}else {
									summaryobj.setDeActivate_Retrievereferencenumber(rs.getString("cnt"));
								}
								
							} else {
								if(rs.getString("cnt").equals("null"))
								{
									summaryobj.setDeActivate_Incorrectattempt("0");
								}else {
									summaryobj.setDeActivate_Incorrectattempt(rs.getString("cnt"));
								}								
							}
						}
					}					

				}
				
				
				return summarydata;
			}
		});
	}

	

	
	
	

	@Override
	public List<StateList> getStateList() {
		JdbcTemplate select = jdbcTemplate("test");
		return select.query(" select state_code as codes, state_name as statenames from m_state;",
				new ResultSetExtractor<List<StateList>>() {
					public List<StateList> extractData(ResultSet rs) throws SQLException, DataAccessException {
						Map<String, String> map = new HashMap<String, String>();
						List<StateList> states = new ArrayList<>();
						while (rs.next()) {
							StateList state = new StateList();
							state.setStateCode(rs.getString("codes"));
							state.setStateName(rs.getString("statenames"));
							states.add(state);
							map.put(rs.getString("codes"), rs.getString("statenames"));
						}
						return states;
					}
				});
	}

//	
//	private JdbcTemplate jdbcTemplate(String tenantName) {
//		//logger.info("tenant name in getJDBCTemp::" + tenantName);
//		if (tenantName.equalsIgnoreCase("test")) {
//			JdbcTemplate temp = new JdbcTemplate(ds1);
//			//logger.info("return DS " + ds1.toString());
//			return temp;
//		}
//		//logger.info("return DS NULL");
//		return null;
//	}

	@Override
	public int getHomePageSuccessCountR(String userName) {
		JdbcTemplate select = jdbcTemplate("test");
		int count = 0;
		try {
			count = select.queryForObject(
					"SELECT  sum(t.txn_count)  from dept_details  as d inner join application_details as a on d.dept_code=a.dept_code left join trans_stats as t  on a.app_code=t.ac where d.username='"+ userName +"' and t.status='y'  ;",
					Integer.class);
		} catch (DataAccessException ex) {
			 logger.info(ex.getMessage());
			count = 0;
		} catch (Exception e) {
			 logger.info(e.getMessage());
			count = 0;
		}
		return count;
	}

	@Override
	public int getTotalErrorCountR(String userName) {
		int count = 0;
		try {
			JdbcTemplate select = jdbcTemplate("test");
			count = select.queryForObject(			
					"SELECT  sum(t.txn_count)  from dept_details  as d inner join application_details as a on d.dept_code=a.dept_code left join trans_stats as t  on a.app_code=t.ac where d.username='"+userName+"' and t.status='n';",
					Integer.class);

		} catch (DataAccessException ex) {
			 logger.info(ex.getMessage());
			return 0;
		} catch (Exception e) {
			 logger.info(e.getMessage());
			count = 0;
		}
		return count;
	}

	public Map<String, Integer> getMonthlyTotalTransR(String userName) {
		 logger.info("getMonthlyTotalTrans userName::" + userName);
		JdbcTemplate select = jdbcTemplate("test");
		try {
			return select.query(
					"select to_char(date,'month') as month,sum(txn_count) as count from public.trans_stats   group by 1,1 order by month desc limit 12  ",
					new ResultSetExtractor<Map<String, Integer>>() {
						public Map<String, Integer> extractData(ResultSet rs) throws SQLException, DataAccessException {
							Map<String, Integer> map = new LinkedHashMap<String, Integer>();
							String month = null;
							int count = 0;
							while (rs.next()) {
								month = rs.getString("month");
								count = rs.getInt("count");
								map.put(month, count);
							}
							return map;
						}
					});
		} catch (DataAccessException ex) {
			 logger.info(ex.getMessage());
			return null;
		} catch (Exception e) {
			 logger.info(e.getMessage());
			return null;
		}
	}

	public int getTotalAcCountDeptWiseR(String userName) {
		JdbcTemplate select = jdbcTemplate("test");
		int count = 0;
		try {
			if (getRole(userName).equalsIgnoreCase("1")) {
				count = select.queryForObject("select count(app_code) as total_ac from application_details;",
						Integer.class);
			} else {
				count = select.queryForObject(
						"select count(app_code) as total_ac from application_details where  dept_code in (select dept_code from dept_details where  username ="
								+ "'" + userName + "'" + ");",
						Integer.class);
			}

		} catch (DataAccessException ex) {
			 logger.info(ex.getMessage());
			count = 0;
		} catch (Exception e) {
			 logger.info(e.getMessage());
			count = 0;
		}

		return count;
	}

	public Map<String, Integer> getTotalTransactionHomePageR(String userName) {
		JdbcTemplate select = jdbcTemplate("test");
		return select.query(
				"SELECT  sum(t.txn_count)  ,opr from dept_details  as d inner join application_details as a on d.dept_code=a.dept_code left join trans_stats as t  on a.app_code=t.ac where d.username='"+userName+"' group by t.opr;",
				new ResultSetExtractor<Map<String, Integer>>() {
					public Map<String, Integer> extractData(ResultSet rs) throws SQLException, DataAccessException {
						Map<String, Integer> map = new HashMap<String, Integer>();
						map.put("struid", 0);
						map.put("getuid", 0);
						map.put("getrefnum", 0);
						map.put("activate", 0);
						map.put("deactivate", 0);						
						while (rs.next()) {
							if (rs.getString("opr")!=null)
							{
								
							
							if (rs.getString("opr").equals("struid")) {
								map.put("struid", rs.getInt("sum"));
							}

							if (rs.getString("opr").equals("getuid")) {
								map.put("getuid", rs.getInt("sum"));
							}
							if (rs.getString("opr").equals("getrefnum")) {
								map.put("getrefnum", rs.getInt("sum"));
							}

							if (rs.getString("opr").equals("activate")) {
								map.put("activate", rs.getInt("sum"));
							}
							if (rs.getString("opr").equals("deactivate")) {
								map.put("deactivate", rs.getInt("sum"));
							}
							
							}
						}
						// logger.info("hometranspage::" + map.toString());
						return map;
					}
				});
	}

	public List<UserStatus> getAppcodeR(String Username) {
		JdbcTemplate select = jdbcTemplate("test");
		try {
			if (getRole(Username).equalsIgnoreCase("1")) {
				return select.query(" SELECT app_code , app_name FROm application_details ;",

						new RowMapper<UserStatus>() {
							public UserStatus mapRow(ResultSet rs, int arg1) throws SQLException {
								UserStatus us = new UserStatus();
								us.setAuaCode(rs.getString("app_code"));
								us.setAppName(rs.getString("app_name"));
								return us;
							}
						});

			} else {


				return select.query(
						" SELECT app_code , app_name FROm application_details where dept_code in (select dept_code from dept_details where username="
								+ "'" + Username + "'" + ") ;",
						new RowMapper<UserStatus>() {
							public UserStatus mapRow(ResultSet rs, int arg1) throws SQLException {
								UserStatus us = new UserStatus();
								us.setAuaCode(rs.getString("app_code"));
								us.setAppName(rs.getString("app_name"));
								return us;
							}
						});

			}

		} catch (DataAccessException ex) {
			 logger.info(ex.getMessage());
			return null;

		} catch (Exception e) {
			 logger.info(e.getMessage());
			return null;
		}
	}

	@Override
	public Map<String, Integer> acwiseNotransR(String acCode) {
		JdbcTemplate select = jdbcTemplate("test");
		try {
			return select.query(
					"SELECT  sum(txn_count) as count,opr FROM public.trans_stats where ac=? and status='n' group by opr order by  opr;",
					new Object[] { acCode }, new ResultSetExtractor<Map<String, Integer>>() {
						public Map<String, Integer> extractData(ResultSet rs) throws SQLException, DataAccessException {
							Map<String, Integer> map = new HashMap<String, Integer>();
							map.put("struid", 0);
							map.put("getuid", 0);
							map.put("getrefnum", 0);
							map.put("activate", 0);
							map.put("deactivate", 0);
							while (rs.next()) {

								if (rs.getString("opr").equals("struid")) {
									map.put("struid", rs.getInt("count"));
								}

								if (rs.getString("opr").equals("getuid")) {
									map.put("getuid", rs.getInt("count"));
								}
								if (rs.getString("opr").equals("getrefnum")) {
									map.put("getrefnum", rs.getInt("count"));
								}

								if (rs.getString("opr").equals("activate")) {
									map.put("activate", rs.getInt("count"));
								}
								if (rs.getString("opr").equals("deactivate")) {
									map.put("deactivate", rs.getInt("count"));
								}
							}
							// logger.info(" AC wise failure count::" + map.toString());
							return map;
						}
					});
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	@Override
	public Map<String, Integer> acWiseYesTransR(String acCode) {
		// TODO Auto-generated method stub
		JdbcTemplate select = jdbcTemplate("test");
		return select.query(
				"SELECT  sum(txn_count),opr FROM public.trans_stats where ac=? and status='y' group by opr order by  opr;",
				new Object[] { acCode }, new ResultSetExtractor<Map<String, Integer>>() {
					public Map<String, Integer> extractData(ResultSet rs) throws SQLException, DataAccessException {
						Map<String, Integer> map = new HashMap<String, Integer>();
						map.put("struid", 0);
						map.put("getuid", 0);
						map.put("getrefnum", 0);
						map.put("activate", 0);
						map.put("deactivate", 0);
						while (rs.next()) {

							if (rs.getString("opr").equals("struid")) {
								map.put("struid", rs.getInt("sum"));
							}

							if (rs.getString("opr").equals("getuid")) {
								map.put("getuid", rs.getInt("sum"));
							}
							if (rs.getString("opr").equals("getrefnum")) {
								map.put("getrefnum", rs.getInt("sum"));
							}

							if (rs.getString("opr").equals("activate")) {
								map.put("activate", rs.getInt("sum"));
							}
							if (rs.getString("opr").equals("deactivate")) {
								map.put("deactivate", rs.getInt("sum"));
							}
						}
						return map;
					}
				});

	}

	@Override
	public Map<String, Integer> acwiseTotaltransR(String[] acCode) {
		// TODO Auto-generated method stub
		JdbcTemplate select = jdbcTemplate("test");
		String url="";
		System.out.println(acCode[1]+" ==code");
		if(acCode[1].contentEquals("Total"))
		{
			 url="SELECT  sum(txn_count),opr FROM public.trans_stats where ac=? and status in ('y', 'n') group by opr order by  opr;";
			
		}else if(acCode[1].contentEquals("Yes"))
		{
			 url="SELECT  sum(txn_count),opr FROM public.trans_stats where ac=? and status='y' group by opr order by  opr;";
		}else if(acCode[1].contentEquals("No"))
		{
			 url="SELECT  sum(txn_count),opr FROM public.trans_stats where ac=? and status='n' group by opr order by  opr;";
		}
		return select.query(url,
				new Object[] { acCode[0] }, new ResultSetExtractor<Map<String, Integer>>() {
					public Map<String, Integer> extractData(ResultSet rs) throws SQLException, DataAccessException {
						Map<String, Integer> map = new HashMap<String, Integer>();
						map.put("struid", 0);
						map.put("getuid", 0);
						map.put("getrefnum", 0);
						map.put("activate", 0);
						map.put("deactivate", 0);
						while (rs.next()) {

							if (rs.getString("opr").equals("struid")) {
								map.put("struid", rs.getInt("sum"));
							}

							if (rs.getString("opr").equals("getuid")) {
								map.put("getuid", rs.getInt("sum"));
							}
							if (rs.getString("opr").equals("getrefnum")) {
								map.put("getrefnum", rs.getInt("sum"));
							}

							if (rs.getString("opr").equals("activate")) {
								map.put("activate", rs.getInt("sum"));
							}
							if (rs.getString("opr").equals("deactivate")) {
								map.put("deactivate", rs.getInt("sum"));
							}
						}

						return map;
					}
				});
	}

	public Map<String, DeptDetails> getrecordR(String deptcode) {
		JdbcTemplate select = jdbcTemplate("test");
		return select.query(
				"  select * from(select d.dept_name as name, d.dept_code as deptcode ,a.app_name as appname from dept_details as d, application_details as a where d.dept_code = a.dept_code) as new  where new.deptcode='"
						+ deptcode + "'" + ";",
				new ResultSetExtractor<Map<String, DeptDetails>>() {
					public Map<String, DeptDetails> extractData(ResultSet rs) throws SQLException, DataAccessException {
						Map<String, DeptDetails> map = new HashMap<String, DeptDetails>();
						while (rs.next()) {
							DeptDetails dept = new DeptDetails();
							dept.setDept_name(rs.getString("name"));
							dept.setApp_name(rs.getString("appname"));
							map.put(rs.getString("appname"), dept);
						}
						return map;
					}
				});
	}

	@Override
	public List<DeptList> getDeptListR() {
		JdbcTemplate select = jdbcTemplate("test");
//		int count = 0;
		return select.query(
//				" select state_code as codes, state_name as statenames from m_state;",
				"select dept_name,dept_code,username from dept_details", new ResultSetExtractor<List<DeptList>>() {
					public List<DeptList> extractData(ResultSet rs) throws SQLException, DataAccessException {
//						Map<String, String> map = new HashMap<String, String>();
						List<DeptList> deptlist = new ArrayList<>();
						while (rs.next()) {
							DeptList dept = new DeptList();
							dept.setDept_name(rs.getString("dept_name"));
							dept.setDept_code(rs.getString("dept_code"));
							dept.setUsername(rs.getString("username"));
							deptlist.add(dept);
//							StateList state = new StateList();
//							state.setStateCode(rs.getString("codes"));
//							state.setStateName(rs.getString("statenames"));
//							states.add(state);
//							map.put(rs.getString("codes"), rs.getString("statenames"));
						}
						return deptlist;
					}
				});
	}



	
	
	
	
	
	
	@Override
	public List<AppList> getAppListR(String deptcode) {
		// TODO Auto-generated method stub

		JdbcTemplate select = jdbcTemplate("test");

		return select.query(
//				" select state_code as codes, state_name as statenames from m_state;",
				"select app_name,app_code from application_details where dept_Code='" + deptcode + "'" + ";",
				new ResultSetExtractor<List<AppList>>() {

					public List<AppList> extractData(ResultSet rs) throws SQLException, DataAccessException {
//						Map<String, String> map = new HashMap<String, String>();
						List<AppList> applist = new ArrayList<>();
						while (rs.next()) {
							AppList appl = new AppList();
							appl.setAppname(rs.getString("app_name"));
							appl.setAppcode(rs.getString("app_code"));
							// appl.setDeptcode(rs.getString("dept_code"));

							applist.add(appl);
						}
						return applist;
					}
				});

	}

	@Override
	public AppDetail getAppDetailR(String appcode) {
		// TODO Auto-generated method stub

		JdbcTemplate select = jdbcTemplate("test");

		return select.query(
//				" select state_code as codes, state_name as statenames from m_state;",
				"select app_name,email,description from application_details where app_code='" + appcode + "'" + ";",
				new ResultSetExtractor<AppDetail>() {

					public AppDetail extractData(ResultSet rs) throws SQLException, DataAccessException {
//						Map<String, String> map = new HashMap<String, String>();
//						List<AppDetail> appdetail = new ArrayList<>();
						AppDetail appd = new AppDetail();
						while (rs.next()) {

							appd.setAppname(rs.getString("app_name"));
							appd.setEmail(rs.getString("email"));
							appd.setDesc(rs.getString("description"));
							// appl.setDeptcode(rs.getString("dept_code"));

//							appdetail.add(appd);
						}
						return appd;
					}
				});

	}

	// 28-09-2022
	@Override
	public AppLk getAppLkR(String appcode) {
		// TODO Auto-generated method stub

		JdbcTemplate select = jdbcTemplate("test");

		return select.query(
//				" select state_code as codes, state_name as statenames from m_state;",
				"select lk,lk_expiry_date::date,app_is_active from application_lk where app_code='" + appcode + "'"
						+ ";",
				new ResultSetExtractor<AppLk>() {

					public AppLk extractData(ResultSet rs) throws SQLException, DataAccessException {
//						Map<String, String> map = new HashMap<String, String>();
//						AppLk applk = new ArrayList<>();
						AppLk appl = new AppLk();
						StringBuilder sb = new StringBuilder();
						while (rs.next()) {
//							AppLk appl = new AppLk();
							String masklk = String.valueOf(rs.getString("lk"));
							char[] ch = new char[masklk.length()];
							for (int i = 0; i < 36; i++) {
								ch[i] = masklk.charAt(i);
							}

							for (int i = 0; i < 28; i++) {
								ch[i] = '*';
							}

							String finallk = String.valueOf(ch);

							appl.setLk(finallk);

//							appl.setLk(masklk);

//							appl.setLk(String.valueOf(rs.getString("lk")));

//							Date date = new Date(timestamp * 1000);
//						    return new SimpleDateFormat("yyyy-MM-dd").format(date);
//							appl.setLkexpiry((Date)(rs.getTimestamp("lk_expiry_date")));

							appl.setLkexpiry(rs.getDate("lk_expiry_date"));

							appl.setApp_is_active(rs.getBoolean("app_is_active"));
							// appl.setDeptcode(rs.getString("dept_code"));

//							applk.add(appl);
						}
						return appl;
					}
				});

	}

	// 28-09-2022
	@Override
	public AppLk getAdminAppLkR(String appcode) {
		// TODO Auto-generated method stub
		JdbcTemplate select = jdbcTemplate("test");

		return select.query(
//					" select state_code as codes, state_name as statenames from m_state;",
				"select lk,lk_expiry_date::date,app_is_active from application_lk where app_code='" + appcode + "'"
						+ ";",
				new ResultSetExtractor<AppLk>() {

					public AppLk extractData(ResultSet rs) throws SQLException, DataAccessException {
//							Map<String, String> map = new HashMap<String, String>();
//							AppLk applk = new ArrayList<>();
						AppLk appl = new AppLk();
						while (rs.next()) {
//							
//								appl.setLk(masklk);

							appl.setLk(String.valueOf(rs.getString("lk")));

//								Date date = new Date(timestamp * 1000);
//							    return new SimpleDateFormat("yyyy-MM-dd").format(date);
//								appl.setLkexpiry((Date)(rs.getTimestamp("lk_expiry_date")));

							appl.setLkexpiry(rs.getDate("lk_expiry_date"));

							appl.setApp_is_active(rs.getBoolean("app_is_active"));
							// appl.setDeptcode(rs.getString("dept_code"));

//								applk.add(appl);
						}
						return appl;
					}
				});

	}

	@Override
	public AllowedOpr getOprR(String appcode) {
		// TODO Auto-generated method stub
		JdbcTemplate select = jdbcTemplate("test");

		return select.query(
//				" select state_code as codes, state_name as statenames from m_state;",
				"select is_struid,is_getrefnum,is_getuid,is_activate,is_deactivate,is_dupcheck,app_code from application_lk where app_code='"
						+ appcode + "'" + ";",
				new ResultSetExtractor<AllowedOpr>() {

					public AllowedOpr extractData(ResultSet rs) throws SQLException, DataAccessException {
//						Map<String, String> map = new HashMap<String, String>();
//						List<AllowedOpr> opr = new ArrayList<>();
						AllowedOpr opra = new AllowedOpr();
						while (rs.next()) {

							opra.setis_Struid(rs.getBoolean("is_struid"));
							opra.setis_Getrefnum(rs.getBoolean("is_getrefnum"));
							opra.setis_Getuid(rs.getBoolean("is_getuid"));
							opra.setis_Activate(rs.getBoolean("is_activate"));
							opra.setis_Deactivate(rs.getBoolean("is_deactivate"));
							opra.setIs_dupcheck(rs.getBoolean("is_dupcheck"));
							opra.setApplicode(rs.getString("app_code"));
//							opr.add(opra);

						}
						return opra;
					}
				});

	}

	@Override
	public String appCreateR(AppDetail appcreate, String deptcode) {
		// TODO Auto-generated method stub
		JdbcTemplate update = jdbcTemplate("test");
		String email = appcreate.getEmail();
		String desc = appcreate.getDesc();
		String appname = appcreate.getAppname();

		String url = "insert into application_details (email,description,app_name,dept_code) values ('" + email + "','"
				+ desc + "','" + appname + "','" + deptcode + "');";

		System.out.println(url);
//		System.out.println(struid + " " + appcode);
		try {
			update.update(url);

		} catch (Exception e) {
			throw new RuntimeException();
		}
		return "successfully app created";
	}

//	@Override
//	public String getAppUpdate(String email, String desc, String appname, String appcode) {
//		// TODO Auto-generated method stub
//		JdbcTemplate update = jdbcTemplate("test");
////		try {
//		update.update("update application_details set email=? ,description=? ,app_name=? where app_code='"+appcode+"' ;",
//				new Object[] {email,desc,appname});
////		}
////		 catch (Exception e) {
////				
////				throw new RuntimeException();
////			}
//		
//		
//	return "successfully updated";
//
////		return select.query(
//////				" select state_code as codes, state_name as statenames from m_state;",
////				"update application_details set email='"+email +"' ,description='"+desc+"' ,appname='"+appname+"' "+"where app_code='" + appcode + "'" + ";",
////				new ResultSetExtractor<List<AppDetailUpdate>>() {
////
////					public List<AppDetailUpdate> extractData(ResultSet rs) throws SQLException, DataAccessException {
//////						Map<String, String> map = new HashMap<String, String>();
////						List<AppDetailUpdate> apdu = new ArrayList<>();
////						while (rs.next()) {
////							AppDetailUpdate adu = new AppDetailUpdate();
////							
////						
////						}
////						return adu;
////					}
////				});
//
//	}

	@Override
	public String getOprUpdateR(AllowedOpr opr, String appcode) {
		// TODO Auto-generated method stub
//		String url = "" + opr.getIs_struid().getClass().getField(name);

//		System.out.println(opr.toString());
		JdbcTemplate update = jdbcTemplate("test");
		try {
//			String deptCode = jt.queryForObject("SELECT dept_code FROM public.dept_details where username=?",
//					new Object[] { userName }, String.class);
			update.update(
					"Update application_lk set is_struid=?,is_getuid=?,is_activate=?,is_deactivate=? where  app_code=? ;",
					new Object[] { opr.getis_Struid(), opr.getis_Getuid(), opr.getis_Activate(), opr.getis_Deactivate(),
							appcode });

		} catch (Exception e) {
			// logger.info(e);
		}

		return "successfully opr updated";

	}

	@Override
	public String getAppUpdateR(AppDetail appdetail, String appcode) {
		// TODO Auto-generated method stub
		JdbcTemplate update = jdbcTemplate("test");
//		System.out.println("in dao"+appdetail.toString()+" "+appcode);
		try {
//			String deptCode = jt.queryForObject("SELECT dept_code FROM public.dept_details where username=?",
//					new Object[] { userName }, String.class);
			update.update("update application_details set email=? ,description=? ,app_name=? where app_code=? ;",
					new Object[] { appdetail.getEmail(), appdetail.getDesc(), appdetail.getAppname(), appcode });

//			update.update(
//" update application_details set email='ywz@gmail.com' where app_code='7';"
//				
//					);

			System.out.println(appdetail + " " + appcode);
		} catch (Exception e) {
			throw new RuntimeException();
		}
		return "successfully appdetail updated";

	}

	@Override
	public String getstruidR(AllowedOpr opr, String appcode) {
		// TODO Auto-generated method stub
		JdbcTemplate update = jdbcTemplate("test");
		Boolean struid = opr.getis_Struid();

		String url = "update application_lk set is_struid='" + struid + "' where app_code='" + appcode + "' ;";

		try {
			update.update(url);

		} catch (Exception e) {
			throw new RuntimeException();
		}
		return "successfully struid updated";
	}

	@Override
	public String getrefnumR(AllowedOpr opr, String appcode) {
		// TODO Auto-generated method stub
		JdbcTemplate update = jdbcTemplate("test");
//		System.out.println(opr);
		Boolean refnum = opr.getis_Getrefnum();

		String url = "update application_lk set is_getrefnum='" + refnum + "'  where app_code='" + appcode + "' ;";

		try {
			update.update(url);

		} catch (Exception e) {
			throw new RuntimeException();
		}
		return "successfully refnum updated";

	}

	@Override
	public String getuidR(AllowedOpr opr, String appcode) {
		// TODO Auto-generated method stub
		JdbcTemplate update = jdbcTemplate("test");
		Boolean uid = opr.getis_Getuid();
		String url = "update application_lk set is_getuid='" + uid + "'  where app_code='" + appcode + "' ;";
		try {
			update.update(url);

		} catch (Exception e) {
			throw new RuntimeException();
		}
		return "successfully uid updated";

	}

	@Override
	public String getactivateR(AllowedOpr opr, String appcode) {
		// TODO Auto-generated method stub
		JdbcTemplate update = jdbcTemplate("test");
		Boolean activate = opr.getis_Activate();
//		System.out.println(opr);
		String url = "update application_lk set is_activate='" + activate + "'  where app_code='" + appcode + "' ;";
		try {
			update.update(url);
		} catch (Exception e) {
			throw new RuntimeException();
		}
		return "successfully activate updated";

	}

	@Override
	public String getdeactivateR(AllowedOpr opr, String appcode) {
		// TODO Auto-generated method stub
		JdbcTemplate update = jdbcTemplate("test");
		Boolean deactivate = opr.getis_Deactivate();
		String url = "update application_lk set is_deactivate='" + deactivate + "'  where app_code='" + appcode + "' ;";
		System.out.println(url);
		try {
			update.update(url);
		} catch (Exception e) {
			throw new RuntimeException();
		}
		return "successfully deactivate updated";

	}

	@Override
	public String getEmailUpdateR(AppDetail appdetail, String appcode) {
		// TODO Auto-generated method stub
		JdbcTemplate update = jdbcTemplate("test");
//		System.out.println("in dao"+appdetail.toString()+" "+appcode);
		try {
//			String deptCode = jt.queryForObject("SELECT dept_code FROM public.dept_details where username=?",
//					new Object[] { userName }, String.class);
			update.update("update application_details set email=?  where app_code=? ;",
					new Object[] { appdetail.getEmail(), appcode });

//			update.update(
//" update application_details set email='ywz@gmail.com' where app_code='7';"
//				
//					);

		} catch (Exception e) {
			throw new RuntimeException();
		}
		return "successfully email updated";

	}

	@Override
	public String getAppnameUpdateR(AppDetail appdetail, String appcode) {
		// TODO Auto-generated method stub
		JdbcTemplate update = jdbcTemplate("test");
//		System.out.println("in dao"+appdetail.toString()+" "+appcode);
		try {
//			String deptCode = jt.queryForObject("SELECT dept_code FROM public.dept_details where username=?",
//					new Object[] { userName }, String.class);
			update.update("update application_details set app_name=?  where app_code=? ;",
					new Object[] { appdetail.getAppname(), appcode });

//			update.update(
//" update application_details set email='ywz@gmail.com' where app_code='7';"
//				
//					);

		} catch (Exception e) {
			throw new RuntimeException();
		}
		return "successfully appname updated";

	}

	@Override
	public String getlkexpiryupdateR(AppLk applkex, String appcode) {
		// TODO Auto-generated method stub

		JdbcTemplate update = jdbcTemplate("test");

		Date date = applkex.getLkexpiry();
		String url = "update application_lk set lk_expiry_date='" + date + "' where app_code='" + appcode + "' ;"
				+ " ;";

		try {
			update.update(url);
		} catch (Exception e) {
			throw new RuntimeException();
		}
		return "successfully LK expiry updated";

	}

	@Override
	public String generatelkR(GenerateAppLK genlk, String appcode) {
		// TODO Auto-generated method stub

		JdbcTemplate update = jdbcTemplate("test");
		String app_code = genlk.getApp_code();
		Date date = genlk.getLkexpiry();
		String dept_code = genlk.getDept_code();
		UUID lk = UUID.randomUUID();

		String url = "insert into application_lk (app_code,lk_expiry_date,dept_code,lk) values ('" + app_code + "','"
				+ date + "','" + dept_code + "','" + lk + "');";

		System.out.println(url);

		try {
			update.update(url);
		} catch (Exception e) {
			throw new RuntimeException();
		}
		return "successfully LK generated";

	}

	@Override
	public String getdupcheckR(AllowedOpr opr, String appcode) {
		// TODO Auto-generated method stub
		JdbcTemplate update = jdbcTemplate("test");
		Boolean dupcheck = opr.getIs_dupcheck();
//		System.out.println(opr);
		String url = "update application_lk set is_dupcheck='" + dupcheck + "'  where app_code='" + appcode + "' ;";
		try {
			update.update(url);
		} catch (Exception e) {
			throw new RuntimeException();
		}
		return "successfully dupcheck updated";

	}

	@Override
	public DeptList getDeptcodeFromUsername(String username) {
		// TODO Auto-generated method stub
		JdbcTemplate select = jdbcTemplate("test");

		String url = "select dept_code , dept_name from dept_details where username =" + "'" + username + "' ;";

		return select.query(url, new ResultSetExtractor<DeptList>() {
			public DeptList extractData(ResultSet rs) throws SQLException, DataAccessException {
				DeptList dept = new DeptList();

				while (rs.next()) {
					dept.setDept_code(rs.getString("dept_code"));
					dept.setDept_name(rs.getString("dept_name"));

				}
				return dept;
			}
		});
	}

//	-----------------------------------------------------------------------------------------------------------------------------------------------------------------

//	----------------------------------------------------original project methods------------------------------------------------------------------------------------------

	private String trimString(String data) {
		return data == null ? null : data.trim();
	}

	public List<User> getUser(String userName) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		logger.info("getUser UserName::" + userName);
		// return select.query("select u.username, u.passwd, u.is_active from
		// public.users as u where u.username = ?",
		return select.query(
				"select u.username, u.passwd,u.dept_is_active from public.dept_details as u  where  u.username = ?",
				new Object[] { userName }, new RowMapper<User>() {
					public User mapRow(ResultSet rs, int arg1) throws SQLException {
						User user = new User();
						user.setUsername(rs.getString(1));
						user.setPasswd(rs.getString(2));
						user.setActive(rs.getBoolean(3));
						return user;
					}
				});
	}

	public List<User> loadUserByUsernameAndTenantname(String username, String tenantName) {
		logger.info(
				"_________________________________________________________________________________________________");

		logger.info("UserName ::" + username + " ::tenant name::" + tenantName);
		JdbcTemplate jdbcTemp = jdbcTemplate(tenantName);
		// String q="select u.username, u.passwd, u.is_active ,m.para_desc from
		// public.users as u,m_config_para m where m.para_value=? and u.username = ?";
		String q = "select u.username, u.passwd,u.dept_is_active ,m.para_desc from public.dept_details as u,m_config_para m where m.para_value=? and u.username = ?";
		List<User> user = jdbcTemp.query(q, new Object[] { tenantName, username }, new RowMapper<User>() {
			public User mapRow(ResultSet rs, int arg1) throws SQLException {
				User user = new User();
				user.setUsername(rs.getString(1));
				user.setPasswd(rs.getString(2));
				user.setActive(rs.getBoolean(3));
				user.setTenantname(rs.getString(4));
				return user;
			}
		});
		return user;
	}

	public int getRoleIdFromUsername(String username) {
		JdbcTemplate ds = jdbcTemplate(getTenantName());
		int roleId = ds.queryForObject(
				"select a.role_id from roles a, user_roles b  where a.role_id=b.role_id and username=?",
				new Object[] { username }, Integer.class);
		logger.info("roleId::" + roleId);
		return roleId;

	}

	public void updatePassword(String userName, String password) {
		JdbcTemplate update = jdbcTemplate(getTenantName());
		logger.info("updatePassword userName::" + userName);
		try {
			update.update("UPDATE public.dept_details SET  passwd=? WHERE username=?",
					new Object[] { password, userName });
		} catch (Exception e) {
			logger.info(e);
			throw new RuntimeException();
		}
	}

	public List<ProfileDetail> getProfileDetails(String userName) {
		JdbcTemplate select = jdbcTemplate(getTenantName());

		logger.info("getProfileDetails UserName::" + userName);
		String deptCode = select.queryForObject("SELECT dept_code FROM public.dept_details where username=?",
				new Object[] { userName }, String.class);
		/*
		 * return select.query(
		 * "SELECT  address_line, city, state_code, pincode,  cd_name, cd_designation, cd_email, cd_mobile, cd_phone  FROM public.dept_registration where dept_id =?"
		 * , new Object[] { deptCode }, new RowMapper<ProfileDetail>() { public
		 * ProfileDetail mapRow(ResultSet rs, int arg1) throws SQLException {
		 * ProfileDetail user = new ProfileDetail();
		 * user.setAddressLine(rs.getString("address_line"));
		 * user.setCity(rs.getString("city")); user.setPincode(rs.getString("pincode"));
		 * user.setCd_name(rs.getString("cd_name"));
		 * user.setCd_designation(rs.getString("cd_designation"));
		 * user.setCd_mobile(Util.trimValues(rs.getString("cd_mobile")));
		 * user.setCd_phone(Util.trimValues(rs.getString("cd_phone")));
		 * user.setEmailId(rs.getString("cd_email")); return user; } });
		 */

		// *****************

		return select.query(
				"SELECT  address,city,state_code,pincode,dept_name,designation,email,mobile,phone FROM public.dept_details where dept_code =?",
				new Object[] { deptCode }, new RowMapper<ProfileDetail>() {
					public ProfileDetail mapRow(ResultSet rs, int arg1) throws SQLException {
						ProfileDetail user = new ProfileDetail();
						user.setAddressLine(rs.getString("address"));
						user.setCity(rs.getString("city"));
						user.setPincode(rs.getString("pincode"));
						user.setCd_name(rs.getString("dept_name"));
						user.setCd_designation(rs.getString("designation"));
						user.setCd_mobile(Util.trimValues(rs.getString("mobile")));
						user.setCd_phone(Util.trimValues(rs.getString("phone")));
						user.setEmailId(rs.getString("email"));
						return user;
					}
				});
	}

	public void updateProfileDetails(String userName, ProfileDetail profileDetail) {
		JdbcTemplate jt = jdbcTemplate(getTenantName());
		logger.info("updateProfileDetails userName::" + userName);
		try {
			String deptCode = jt.queryForObject("SELECT dept_code FROM public.dept_details where username=?",
					new Object[] { userName }, String.class);
			jt.update(
					"UPDATE public.dept_details SET address=?, city=?,pincode=?,dept_name=?,mobile=?,phone=?,designation=? WHERE dept_code =?",
					new Object[] { trimString(profileDetail.getAddressLine()), trimString(profileDetail.getCity()),
							trimString(profileDetail.getPincode()), trimString(profileDetail.getCd_name()),
							trimString(profileDetail.getCd_mobile()), trimString(profileDetail.getCd_phone()),
							trimString(profileDetail.getCd_designation()), deptCode });
		} catch (Exception e) {
			logger.info(e);
		}
	}

	public List<AcCode> getAcCode(String userName) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		long deptId;
		logger.info("getAcCode UserName::" + userName);
		try {
			deptId = select.queryForObject("SELECT dept_id FROM public.users where username=?",
					new Object[] { userName }, Long.class);
			return select.query("select u.aua_code from public.dept_registration as u where  u.dept_id = ?",
					new Object[] { deptId }, new RowMapper<AcCode>() {
						public AcCode mapRow(ResultSet rs, int arg1) throws SQLException {
							AcCode ac = new AcCode();
							ac.setAcCode(rs.getString("aua_code"));
							return ac;
						}
					});
		} catch (Exception e) {
			logger.info(e);
			return null;
		}
	}

	public void updateAc(String userName, String ac) {
		JdbcTemplate update = jdbcTemplate(getTenantName());
		logger.info("updateAc userName::" + userName);
		update.update("UPDATE public.asa_registration SET ac=? WHERE username =?", new Object[] { ac, userName });

	}

	public List<UpdateAuaLk> getlk(String userName) {
		logger.info("getlk userName::" + userName);
		JdbcTemplate select = jdbcTemplate(getTenantName());
		try {
			return select.query(
					"select to_char(lk.valid_till,'DD-MM-YYYY')  as aua_valid_till , lk.license_key ,lk.client_license_key as clk, lk.is_krdh_activated "
							+ "from public.aua_details as lk "
							+ "where lk.is_active=true and lk.license_type=? and lk.dept_id = "
							+ "(Select dept_id from public.asa_registration where  username = ? )",
					new Object[] { LicenceType.AUA.getValue(), userName }, new RowMapper<UpdateAuaLk>() {
						public UpdateAuaLk mapRow(ResultSet rs, int arg1) throws SQLException {
							UpdateAuaLk lk = new UpdateAuaLk();
							lk.setAuaLk(rs.getString("license_key"));
							lk.setExpiryDate(rs.getString("aua_valid_till"));
							lk.setIs_dept_activated(rs.getBoolean("is_krdh_activated"));
							lk.setClk(rs.getString("clk"));
							return lk;
						}
					});
		}

		catch (DataAccessException ex) {
			logger.info(ex);
			return null;
		} catch (Exception e) {
			logger.info(e);
			return null;
		}
	}

	public boolean updateAuaLk(String userName, UpdateAuaLk updateAuaLk) {
		logger.info("UpdateAuaLk::" + updateAuaLk + "::userName::" + userName);
		JdbcTemplate update = jdbcTemplate(getTenantName());
		List<UpdateAuaLk> listOfAuaLk = getlk(userName);
		boolean isDeptActivated = true;
		logger.info("Expiry Date::" + updateAuaLk.getExpiryDate());
		if (listOfAuaLk.size() > 0) {
			isDeptActivated = listOfAuaLk.get(0).getIs_dept_activated();
		}
		try {
			update.update(
					"Update public.license_keys set is_active=false where  license_type=? and  dept_id =(Select dept_id from public.asa_registration where username = ? )",
					new Object[] { LicenceType.AUA.getValue(), userName });
			String randomUuid = UUID.randomUUID().toString();
			update.update(
					"INSERT INTO public.license_keys( dept_id, ac, license_key, valid_till, update_by, update_timestamp,"
							+ "is_active, client_license_key, is_krdh_activated,license_type,username) "
							+ "select dept_id, ac,?,to_date(?,'dd-mm-yyyy')::date,username, now(), true,?,?,?,? from users where username =?",
					new Object[] { updateAuaLk.getAuaLk(), updateAuaLk.getExpiryDate(), randomUuid, isDeptActivated,
							LicenceType.AUA.getValue(), userName, userName });
			return true;
		} catch (Exception e) {
			logger.info(e);
			return false;
		}
	}

	private int getDeptIdSeq() {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		// int deptId = select.queryForObject("select
		// nextval('public.dept_registration_dept_id_seq')", Integer.class);
		int deptId = select.queryForObject("select nextval('public.dept_details_dept_code_seq')", Integer.class);
		logger.info("getDeptIdSeq id generated::" + deptId);
		return deptId;
	}

	private String getAppCode() {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		// String appCode=select.queryForObject("SELECT RPAD('AAP000',8,'0')as app_code
		// from application_details;",String.class);
		String appCode = "A"
				+ select.queryForObject("select nextval('public.application_details_app_code_seq');", String.class);
		return appCode;
	}

	private String getSchemeCode() {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		String saCode = "S"
				+ select.queryForObject("select nextval('public.key_mapping_scheme_code_seq');", String.class);
		return saCode;
	}

	public String addUser(String userName, AddUser user) {
		logger.info("addUser userName::" + userName);
		logger.info("printing user adduser details:: " + user.getDeptName());
		logger.info("printing user email:: " + user.getEmail());
		String deptCode;
		JdbcTemplate update = jdbcTemplate(getTenantName());
		JdbcTemplate select = jdbcTemplate(getTenantName());
		deptCode = select.queryForObject("select dept_code from dept_details where username=?",
				new Object[] { userName }, String.class);
		logger.info("dept code:: " + deptCode);
		String appCode = getAppCode();
		String roleCode;

		String username_prefix = getParaValueByParaName("portal_type");
		if (username_prefix.equals("asa")) {
			username_prefix = "aua";
			roleCode = "AUA";
		} else {
			username_prefix = "saua";
			roleCode = "SAUA";
		}
		String schemaName = "public";
		logger.info("Check the details:: " + userName + " " + user.getDeptName() + " " + user.getEmail());
		logger.info("description details::" + user.getDesc());
		update.update(
				"INSERT INTO public.application_details(app_code,description,dept_code,email,app_name) VALUES(?,?,?,?,?);",
				// new Object[] { appCode, "app details of" + appCode, deptCode,
				// user.getEmail(), user.getDeptName() });
				new Object[] { appCode, user.getDesc(), deptCode, user.getEmail(), user.getDeptName() });
		update.update("INSERT INTO public.application_lk(app_code,dept_code) VALUES(?,?);",
				new Object[] { appCode, deptCode });

		return appCode;
	}

	public boolean checkOldPassword(String userName, String oldPassword) {
		logger.info("checkOldPassword userName::" + userName);
		JdbcTemplate select = jdbcTemplate(getTenantName());
		String queryPassword = select.queryForObject("select passwd from public.dept_details where username=?",
				new Object[] { userName }, String.class);
		return encoder.matches(oldPassword, queryPassword);
	}

	public List<UserStatus> getUserStatus() {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		logger.info("getUserStatus");
		try {
			return select.query(
					"SELECT u.dept_id, d.dept_name, u.username,d.sa_code FROM  public.users as u, "
							+ " public.user_roles as ur,  public.dept_registration as d,  public.roles as r "
							+ " WHERE  ur.username = u.username and   u.dept_id = d.dept_id and "
							+ " r.role_id = ur.role_id and  r.role_id = '2' and  d.is_sa_active=true ",
					new RowMapper<UserStatus>() {

						public UserStatus mapRow(ResultSet rs, int arg1) throws SQLException {
							ResultSetMetaData metaData = rs.getMetaData();
							int count = metaData.getColumnCount();
							UserStatus us = new UserStatus();
							us.setDeptName(rs.getString("dept_name"));
							us.setUserName(rs.getString("username"));
							us.setId(rs.getString("dept_id"));
							us.setAuaCode(rs.getString("sa_code"));

							logger.info("login user::" + rs.getString("username"));

							us.setLoginStatus(select.queryForObject(
									" SELECT a.is_active from public.users a  where a.username = ? ",
									new Object[] { rs.getString("username") }, Boolean.class));
							logger.info("auth sacode::" + rs.getString("sa_code"));

							us.setAuthStatus(select.queryForObject(
									" SELECT a.is_auth_allowed from public.sa_lk_details a  where a.sa_code = ? and is_active='true' ",
									new Object[] { rs.getString("sa_code") }, Boolean.class));
							logger.info("kyc sacode::" + rs.getString("sa_code"));
							us.setEkycStatus(select.queryForObject(
									" SELECT  a.is_ekyc_allowed from public.sa_lk_details a  where a.sa_code = ? and is_active='true' ",
									new Object[] { rs.getString("sa_code") }, Boolean.class));
							logger.info("otp sacode::" + rs.getString("sa_code"));
							us.setOtpStatus(select.queryForObject(
									" SELECT a.is_otp_allowed from public.sa_lk_details a  where a.sa_code = ? and is_active='true'",
									new Object[] { rs.getString("sa_code") }, Boolean.class));
							logger.info("validity sacode::" + rs.getString("sa_code"));
							us.setValidTill(select.queryForObject(
									" SELECT a.sa_valid_till from public.sa_lk_details a  where a.sa_code = ? and is_active='true'",
									new Object[] { rs.getString("sa_code") }, Date.class));
							if (count > 5) {
								us.setType(rs.getString("type"));

							}
							return us;
						}
					});
		}

		catch (DataAccessException ex) {
			logger.info(ex);
			return null;
		} catch (Exception e) {
			logger.info(e);
			return null;
		}
	}

	public List<UserStatus> getLkStatus() {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		logger.info(" getLkStatus ");
		try {

			return select.query(
					/*
					 * "SELECT u.dept_id, d.dept_name, u.username,d.sa_code FROM public.application_details as u "
					 * + " join public.user_roles as ur on  ur.username = u.username " +
					 * " join public.dept_registration as d on u.dept_id = d.dept_id " +
					 * " join public.roles as r on r.role_id = ur.role_id  WHERE r.role_id = '2' ",
					 */
					"SELECT u.app_code,ad.app_name FROM public.application_lk as u  "
							// + " join public.user_roles as ur on ur.username = u.username "
							// + " join public.dept_registration as d on u.dept_id = d.dept_id "
							// + " join public.roles as r on r.role_id = ur.role_id WHERE r.role_id = '2' ",
							+ " join public.application_details as ad on ad. app_code = u. app_code where u.lk IS NULL",
					new RowMapper<UserStatus>() {
						public UserStatus mapRow(ResultSet rs, int arg1) throws SQLException {
							ResultSetMetaData metaData = rs.getMetaData();
							int count = metaData.getColumnCount();
							UserStatus us = new UserStatus();
							us.setDeptName(rs.getString("app_name"));
							// us.setUserName(rs.getString("username"));
							// us.setId(rs.getString("dept_id"));
//							us.setLoginStatus(select.queryForObject(
//									" SELECT a.app_is_active from public.application_details a  where a.app_name = ? ",
//									new Object[] { rs.getString("app_name") }, Boolean.class));
							us.setAuaCode(rs.getString("app_code"));
							if (count > 5) {
								us.setType(rs.getString("type"));
							}
							return us;
						}
					});
		} catch (DataAccessException ex) {
			logger.info(ex);
			return null;

		} catch (Exception e) {
			logger.info(e);
			return null;
		}
	}

	public List<UserStatus> getSAStatus() {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		logger.info(" getSAStatus Method Dao ");
		try {

			return select.query(
					/*
					 * "SELECT u.dept_id, d.dept_name, u.username,d.sa_code FROM public.application_details as u "
					 * + " join public.user_roles as ur on  ur.username = u.username " +
					 * " join public.dept_registration as d on u.dept_id = d.dept_id " +
					 * " join public.roles as r on r.role_id = ur.role_id  WHERE r.role_id = '2' ",
					 */
					"SELECT u.app_code  FROM public.application_lk as u  where u.lk IS NOT NULL",
					// + " join public.user_roles as ur on ur.username = u.username "
					// + " join public.dept_registration as d on u.dept_id = d.dept_id "
					// + " join public.roles as r on r.role_id = ur.role_id WHERE r.role_id = '2' ",
					new RowMapper<UserStatus>() {
						public UserStatus mapRow(ResultSet rs, int arg1) throws SQLException {
							ResultSetMetaData metaData = rs.getMetaData();
							int count = metaData.getColumnCount();
							UserStatus us = new UserStatus();
							// us.setDeptName(rs.getString("app_name"));
							// us.setUserName(rs.getString("username"));
							// us.setId(rs.getString("dept_id"));
//							us.setLoginStatus(select.queryForObject(
//									" SELECT a.app_is_active from public.application_details a  where a.app_name = ? ",
//									new Object[] { rs.getString("app_name") }, Boolean.class));
							us.setAuaCode(rs.getString("app_code"));
							// us.setEmail(rs.getString("email"));
							// us.setAppName(rs.getString("app_name"));
							if (count > 5) {
								us.setType(rs.getString("type"));
							}
							return us;
						}
					});
		} catch (DataAccessException ex) {
			logger.info(ex);
			return null;

		} catch (Exception e) {
			logger.info(e);
			return null;
		}
	}

	public List<UserStatus> getAppcode() {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		logger.info(" getAppcode Method Dao ");
		try {

			return select.query("SELECT ac  FROM public.trans_stats group by ac",
					// + " join public.user_roles as ur on ur.username = u.username "
					// + " join public.dept_registration as d on u.dept_id = d.dept_id "
					// + " join public.roles as r on r.role_id = ur.role_id WHERE r.role_id = '2' ",
					new RowMapper<UserStatus>() {
						public UserStatus mapRow(ResultSet rs, int arg1) throws SQLException {
							ResultSetMetaData metaData = rs.getMetaData();
							int count = metaData.getColumnCount();
							UserStatus us = new UserStatus();
							// us.setDeptName(rs.getString("app_name"));
							// us.setUserName(rs.getString("username"));
							// us.setId(rs.getString("dept_id"));
//							us.setLoginStatus(select.queryForObject(
//									" SELECT a.app_is_active from public.application_details a  where a.app_name = ? ",
//									new Object[] { rs.getString("app_name") }, Boolean.class));
							us.setAuaCode(rs.getString("ac"));
							// us.setEmail(rs.getString("email"));
							// us.setAppName(rs.getString("app_name"));
							if (count > 5) {
								us.setType(rs.getString("type"));
							}
							return us;
						}
					});
		} catch (DataAccessException ex) {
			logger.info(ex);
			return null;

		} catch (Exception e) {
			logger.info(e);
			return null;
		}
	}

	public List<UserStatus> getEmailAppnameByAppcode(String appcode) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		logger.info(" getEmailAppnameByAppcode Method Dao ");
		logger.info("appcode::" + appcode);
		try {

			/*
			 * return select.
			 * query("SELECT u.email,u.app_name  FROM public.application_details as u  where u.app_code=?"
			 * , new Object[] {appcode}, String.class, new RowMapper<UserStatus>() { public
			 * UserStatus mapRow(ResultSet rs, int arg1) throws SQLException {
			 * ResultSetMetaData metaData = rs.getMetaData(); int count =
			 * metaData.getColumnCount(); UserStatus us = new UserStatus();
			 * us.setEmail(rs.getString("email")); us.setAppName(rs.getString("app_name"));
			 * if (count > 5) { us.setType(rs.getString("type")); } return us; } });
			 */
			return select.query("SELECT u.email,u.app_name  FROM public.application_details as u  where u.app_code=?",
					new Object[] { appcode }, new RowMapper<UserStatus>() {
						public UserStatus mapRow(ResultSet rs, int arg1) throws SQLException {
							UserStatus us = new UserStatus();
							us.setEmail(rs.getString("email"));
							us.setAppName(rs.getString("app_name"));
							return us;
						}
					});

		} catch (DataAccessException ex) {
			logger.info(ex);
			return null;

		} catch (Exception e) {
			logger.info(e);
			return null;
		}
	}

	// ***************
	public List<AddUser> getAPPCodes() {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		logger.info(" getLkStatus ");
		try {

			return select.query(
					/*
					 * "SELECT u.dept_id, d.dept_name, u.username,d.sa_code FROM public.application_details as u "
					 * + " join public.user_roles as ur on  ur.username = u.username " +
					 * " join public.dept_registration as d on u.dept_id = d.dept_id " +
					 * " join public.roles as r on r.role_id = ur.role_id  WHERE r.role_id = '2' ",
					 */
					"SELECT u.app_code FROM public.application_lk as u  where u.lk IS NOT NULL",
					// + " join public.user_roles as ur on ur.username = u.username "
					// + " join public.dept_registration as d on u.dept_id = d.dept_id "
					// + " join public.roles as r on r.role_id = ur.role_id WHERE r.role_id = '2' ",
					new RowMapper<AddUser>() {
						public AddUser mapRow(ResultSet rs, int arg1) throws SQLException {
							ResultSetMetaData metaData = rs.getMetaData();
							int count = metaData.getColumnCount();
							AddUser us = new AddUser();
							us.setAppCode(rs.getString("app_code"));
							// us.setUserName(rs.getString("username"));
							// us.setId(rs.getString("dept_id"));
//							us.setLoginStatus(select.queryForObject(
//									" SELECT a.app_is_active from public.application_details a  where a.app_name = ? ",
//									new Object[] { rs.getString("app_name") }, Boolean.class));
							return us;
						}
					});
		} catch (DataAccessException ex) {
			logger.info(ex);
			return null;

		} catch (Exception e) {
			logger.info(e);
			return null;
		}
	}
/////************************

	public List<UserStatus> getsaLkStatus() {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		logger.info(" getsaLkStatus ");
		try {

			return select.query(
//					"SELECT u.dept_id, d.dept_name, u.username,d.sa_code,sa.sa_license_key, to_char(sa.sa_valid_till,'DD/MM/YYYY')  as sa_valid_till "
//							+ "  FROM public.users as u "
//							+ " join public.user_roles as ur on  ur.username = u.username "
//							+ " join public.dept_registration as d on u.dept_id = d.dept_id "
//							+ " join public.roles as r on r.role_id = ur.role_id "
//							+ " join public.sa_lk_details as sa on sa.sa_code = d.sa_code  WHERE  sa.is_active=true",
					"SELECT u.app_name,u.app_code,ur.lk,to_char(ur.lk_expiry_date,'DD/MM/YYYY')  as sa_valid_till "
							+ "  FROM public.application_details as u"
							+ " join public.application_lk as ur on  ur.app_code = u.app_code where ur.lk IS NOT NULL",
//					+ " join public.dept_registration as d on u.dept_id = d.dept_id "
//					+ " join public.roles as r on r.role_id = ur.role_id "
//					+ " join public.sa_lk_details as sa on sa.sa_code = d.sa_code  WHERE  sa.is_active=true",
					new RowMapper<UserStatus>() {

						public UserStatus mapRow(ResultSet rs, int arg1) throws SQLException {
							UserStatus us = new UserStatus();
							us.setDeptName(rs.getString("app_name"));
							// us.setUserName(rs.getString("username"));
							us.setId(rs.getString("app_code"));
							us.setLk(rs.getString("lk"));
							us.setValidity((rs.getString("sa_valid_till")));
							us.setLoginStatus(select.queryForObject(
									" SELECT a.app_is_active from public.application_lk a  where a.app_code = ? ",
									new Object[] { rs.getString("app_code") }, Boolean.class));
							us.setAuaCode(rs.getString("app_code"));
							return us;
						}
					});
		}

		catch (DataAccessException ex) {
			logger.info(ex);
			return null;

		} catch (Exception e) {
			logger.info(e);
			return null;
		}
	}

	public List<String> checkSaLKPersistance(List saCode) {
		logger.info("checkSaLKPersistance saCode List::" + saCode);
		List<String> list = new ArrayList<String>();
		JdbcTemplate ds = jdbcTemplate(getTenantName());
		Iterator itr = saCode.iterator();
		String sa_code = "";
		// String query="select sa_code from sa_lk_details where is_active ='true' and
		// sa_code=?";
		String query = "select app_code from application_lk where lk IS NULL  and app_code=?";
		// String query="select app_code from application_details where
		// app_is_active='true' and app_code=?";
		while (itr.hasNext()) {
			sa_code = (String) itr.next();
			try {
				String saCode1 = ds.queryForObject(query, new Object[] { sa_code }, String.class);
				logger.info("sacode ::" + sa_code);
				if (saCode1 != null) {
					list.add(saCode1);
				}
			} catch (DataAccessException e) {
				logger.info(e);
			}
		}
		return list;
	}

	public List<UserStatus> getSuspendUserStatus() {
		logger.info("getSuspendUserStatus");
		JdbcTemplate select = jdbcTemplate(getTenantName());
		try {
			return select.query("SELECT u.dept_id, d.dept_name, u.username,d.is_sa_active,d.sa_code FROM "
					+ " public.users as u, " + " public.user_roles as ur, " + " public.dept_registration as d, "
					+ " public.roles as r " + " WHERE " + " ur.username = u.username and  "
					+ " u.dept_id = d.dept_id and " + " r.role_id = ur.role_id and " + " r.role_id = '2'",
					new RowMapper<UserStatus>() {
						public UserStatus mapRow(ResultSet rs, int arg1) throws SQLException {
							ResultSetMetaData metaData = rs.getMetaData();
							int count = metaData.getColumnCount();
							UserStatus us = new UserStatus();
							us.setDeptName(rs.getString("dept_name"));
							us.setUserName(rs.getString("username"));
							us.setLoginStatus(rs.getBoolean("is_sa_active"));
							us.setId(rs.getString("dept_id"));
							if (count > 5) {
								us.setType(rs.getString("type"));
							}
							return us;
						}
					});
		}

		catch (DataAccessException ex) {
			logger.info(ex);
			return null;

		} catch (Exception e) {
			logger.info(e);
			return null;
		}
	}

	public void emailVerificationAccountPasswordUpdate(int dept, String password) {
		logger.info("emailVerificationAccountPasswordUpdate dept::" + dept);
		JdbcTemplate update = jdbcTemplate(getTenantName());
		update.update("update users set passwd= ? where dept_id = ?", new Object[] { password, dept });
		update.update("update dept_registration set email_verification_timestamp = now() where dept_id = ?",
				new Object[] { dept });

	}

	public void updateLoginStatus(List<String> usernames, List<String> auacodes, List<Boolean> loginStatusList,
			List<Boolean> authStatusList, List<Boolean> otpStatusList, List<Boolean> ekycStatusList) {
		JdbcTemplate update = jdbcTemplate(getTenantName());
		logger.info(" updateLoginStatus usernames::" + usernames + " \n auacodes::" + auacodes + ""
				+ "\n loginStatusList::" + loginStatusList + "" + "\n authStatusList::" + authStatusList + ""
				+ "\n otpStatusList::" + otpStatusList + "" + "\n ekycStatusList::" + ekycStatusList);
		try {
			long dept_id;
			int count = 0;
			boolean isActive = false;
			String tempSaCode;
			List<Long> deptIds = new ArrayList<Long>();
			String usersTableUpdateQuery = " UPDATE public.users SET is_active=?,update_by=?,update_timestamp=now()  WHERE username=?";
			String auaDetailTableUpdateQuery = " UPDATE public.sa_lk_details SET is_auth_allowed=?,is_otp_allowed=?, is_ekyc_allowed=?,update_by=?,update_timestamp=now()  WHERE sa_code=? ";
			for (String username : usernames) {
				isActive = update.queryForObject(" SELECT a.is_active from public.users a  where a.username = ? ",
						new Object[] { username }, Boolean.class);
				if (loginStatusList.get(count) != isActive) {

					update.update(usersTableUpdateQuery,
							new Object[] { loginStatusList.get(count), getPrincipal(), username });
				}

				dept_id = update.queryForObject("select dept_id from public.users where username = ?",
						new Object[] { username }, Long.class);
				deptIds.add(dept_id);

				count++;
			}

			count = 0;
			for (Long deptId : deptIds) {

				try {

					tempSaCode = update.queryForObject(
							" SELECT a.sa_code from public.dept_registration a  where a.dept_id = ? ",
							new Object[] { deptId }, String.class);

					update.update(auaDetailTableUpdateQuery, new Object[] { authStatusList.get(count),
							otpStatusList.get(count), ekycStatusList.get(count), getPrincipal(), tempSaCode });
				} catch (EmptyResultDataAccessException ex) {
					logger.info(ex);
				} catch (Exception e) {
					logger.info(e);
				}
				count++;
			}
		} catch (Exception e) {
			logger.info(e);
		}
	}

	public void generateSaLk(List<String> appCode, List<String> dateValueList) {
		JdbcTemplate update = jdbcTemplate(getTenantName());
		logger.info("generateSaLk saCode::" + appCode + "\n dateValueList::" + dateValueList);
		try {
			/*
			 * String app_name=update.
			 * queryForObject("select app_name from public.application_detials where app_code = ?"
			 * , new Object[] { saCode }, String.class); long dept_id =
			 * update.queryForObject("select dept_id from public.users where username = ?",
			 * new Object[] { getPrincipal() }, Long.class); String auaCode = update.
			 * queryForObject("select aua_code from public.dept_registration where dept_id = ?"
			 * , new Object[] { dept_id }, String.class);
			 */
			// logger.info("auaCode:" + auaCode);
			int count = 0;
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			java.util.Date javaDate = null;
			List<java.sql.Date> sqlDateList = new ArrayList<java.sql.Date>();
			for (String date : dateValueList) {
				javaDate = sdf.parse(date);
				sqlDateList.add(new java.sql.Date(javaDate.getTime()));
			}

			/*
			 * for (String sacode : saCode) {
			 * update.update(" INSERT INTO public.sa_lk_details " +
			 * " ( aua_code,sa_code,is_active,sa_valid_till, update_by, update_timestamp,sa_license_key,is_auth_allowed,is_otp_allowed,is_ekyc_allowed)"
			 * + "   values (?,?,?,?,?,now(),?,?,?,?);", new Object[] { auaCode, sacode,
			 * true, sqlDateList.get(count), getPrincipal(),
			 * UUID.randomUUID(),false,false,false });
			 */
			for (String appcode : appCode) {
				update.update(
						" UPDATE public.application_lk SET lk=?, lk_expiry_date=?,app_is_active=true  WHERE app_code=?",
						new Object[] { UUID.randomUUID(), sqlDateList.get(count), appcode });

				/*
				 * update.update(
				 * " UPDATE public.dept_registration SET is_sa_active=true,update_by=?,update_timestamp=now()  WHERE sa_code=?"
				 * , new Object[] { getPrincipal(), sacode });
				 */

				count++;
			}

		} catch (EmptyResultDataAccessException ex) {
			logger.info(ex);
		} catch (Exception e) {
			logger.info(e);
		}
	}

	public void generateSchemeCode(List<String> saCode, List<String> schemeDesc) {
		JdbcTemplate update = jdbcTemplate(getTenantName());
		logger.info("saCode::" + saCode);
		try {
			/*
			 * String app_name=update.
			 * queryForObject("select app_name from public.application_detials where app_code = ?"
			 * , new Object[] { saCode }, String.class); long dept_id =
			 * update.queryForObject("select dept_id from public.users where username = ?",
			 * new Object[] { getPrincipal() }, Long.class); String auaCode = update.
			 * queryForObject("select aua_code from public.dept_registration where dept_id = ?"
			 * , new Object[] { dept_id }, String.class);
			 */
			// logger.info("auaCode:" + auaCode);
			int count = 0;
			/*
			 * SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy"); java.util.Date
			 * javaDate = null; List<java.sql.Date> sqlDateList = new
			 * ArrayList<java.sql.Date>(); for (String date : dateValueList) { javaDate =
			 * sdf.parse(date); sqlDateList.add(new java.sql.Date(javaDate.getTime())); }
			 */

			/*
			 * for (String sacode : saCode) {
			 * update.update(" INSERT INTO public.sa_lk_details " +
			 * " ( aua_code,sa_code,is_active,sa_valid_till, update_by, update_timestamp,sa_license_key,is_auth_allowed,is_otp_allowed,is_ekyc_allowed)"
			 * + "   values (?,?,?,?,?,now(),?,?,?,?);", new Object[] { auaCode, sacode,
			 * true, sqlDateList.get(count), getPrincipal(),
			 * 
			 * UUID.randomUUID(),false,false,false });
			 */
			String schemeCode = getSchemeCode();
			for (String sacode : saCode) {
				/*
				 * update.
				 * update(" INSERT INTO public.key_mapping ( app_code,scheme_code,schema_description) values(?,?,?)"
				 * , new Object[] { saCode.get(count),schemeCode,schemeDesc.get(count) });
				 */

				update.update(
						" INSERT INTO public.scheme_details ( app_code,scheme_code,schema_description) values(?,?,?)",
						new Object[] { saCode.get(count), schemeCode, schemeDesc.get(count) });

				/*
				 * update.update(
				 * " UPDATE public.dept_registration SET is_sa_active=true,update_by=?,update_timestamp=now()  WHERE sa_code=?"
				 * , new Object[] { getPrincipal(), sacode });
				 */

				count++;
			}

		} catch (EmptyResultDataAccessException ex) {
			logger.info(ex);
		} catch (Exception e) {
			logger.info(e);
		}
	}

	public boolean updateSaLk(List<String> saCode, List<String> saLkList, List<String> dateValueList) {
		JdbcTemplate update = jdbcTemplate(getTenantName());
		logger.info(
				"updateSaLk saCode::" + saCode + " \n saLkList::" + saLkList + " \n dateValueList::" + dateValueList);

		try {
			int count = 0;
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			java.util.Date javaDate = null;
			List<java.sql.Date> sqlDateList = new ArrayList<java.sql.Date>();
			for (String date : dateValueList) {
				javaDate = sdf.parse(date);
				sqlDateList.add(new java.sql.Date(javaDate.getTime()));
			}
			/*
			 * List<LicensekeyDetails> salk = null; long dept_id =
			 * update.queryForObject("select dept_id from public.users where username = ?",
			 * new Object[] { getPrincipal() }, Long.class); String auaCode = update.
			 * queryForObject("select aua_code from public.dept_registration where dept_id = ?"
			 * , new Object[] { dept_id }, String.class); for (String sacode : saCode) {
			 * salk = update.query(
			 * "select is_active,is_auth_allowed,is_otp_allowed,is_ekyc_allowed from public.sa_lk_details where sa_code = ? and is_active=true"
			 * , new Object[] { sacode }, new RowMapper<LicensekeyDetails>() { public
			 * LicensekeyDetails mapRow(ResultSet rs, int arg1) throws SQLException {
			 * ResultSetMetaData metaData = rs.getMetaData(); int count =
			 * metaData.getColumnCount(); LicensekeyDetails us = new LicensekeyDetails();
			 * us.setActive(rs.getBoolean("is_active"));
			 * us.setAuthActive(rs.getBoolean("is_auth_allowed"));
			 * us.setKycActive(rs.getBoolean("is_ekyc_allowed"));
			 * us.setOtpActive(rs.getBoolean("is_otp_allowed")); return us; } });
			 * 
			 * logger.info("salk::" + salk.toString());
			 */
			for (String sacode : saCode) {
				update.update(
						" UPDATE public.application_lk SET app_is_active=true,lk=?,lk_expiry_date=?  WHERE app_code=?",
						new Object[] { UUID.randomUUID(), sqlDateList.get(count), saCode.get(count) });

				/*
				 * update.update(" INSERT INTO public.sa_lk_details " +
				 * " ( aua_code,sa_code,is_active,sa_valid_till, update_by, update_timestamp,sa_license_key,is_auth_allowed,is_otp_allowed,is_ekyc_allowed)"
				 * + "   values (?,?,?,?,?,now(),?,?,?,?);", new Object[] { auaCode, sacode,
				 * salk.get(0).isActive(), sqlDateList.get(count), getPrincipal(),
				 * UUID.fromString(saLkList.get(count)), salk.get(0).isAuthActive(),
				 * salk.get(0).isOtpActive(), salk.get(0).isKycActive() });
				 */
				count++;
			}

		} catch (EmptyResultDataAccessException ex) {
			logger.info(ex);
		} catch (DuplicateKeyException e) {
			logger.info(e);
			return false;
		} catch (Exception e) {
			logger.info(e);
			return false;
		}
		return true;
	}

	public void suspendUser(List<String> deptIdList, boolean status) {
		JdbcTemplate update = jdbcTemplate(getTenantName());
		logger.info(" suspendUser deptIdList::" + deptIdList + "\n  status::" + status);
		try {
			long deptId;
			String saCode;
			List<Long> deptIds = new ArrayList<Long>();
			List<String> saCodeList = new ArrayList<String>();
			String deptRegTableUpdateQuery = " UPDATE public.dept_registration SET is_sa_active=?,update_by=?,update_timestamp=now() WHERE	 dept_id=?";
			String auaDetailTableUpdateQuery = " UPDATE public.sa_lk_details SET is_active=?,is_auth_allowed=?,is_otp_allowed=?,is_ekyc_allowed=? ,"
					+ "update_by=?,update_timestamp=now()  WHERE sa_code=? ";
			for (String id : deptIdList) {
				deptId = Long.parseLong(id);
				update.update(deptRegTableUpdateQuery, new Object[] { status, getPrincipal(), deptId });
				saCode = update.queryForObject("select sa_code from public.dept_registration where dept_id = ?",
						new Object[] { deptId }, String.class);
				if (saCode != null)
					saCodeList.add(saCode);
			}
			for (String tempAuaCode : saCodeList) {
				update.update(auaDetailTableUpdateQuery,
						new Object[] { status, status, status, status, getPrincipal(), tempAuaCode });
			}
		} catch (Exception e) {
			logger.info(e);
		}
	}

	public boolean checkEmailVerificationStatus(int deptId) {
		logger.info("Checking for  emaile verification for uer : " + deptId);
		JdbcTemplate select = jdbcTemplate(getTenantName());
		java.sql.Timestamp queryEmailVerificationTimestamp = null;
		try {
			queryEmailVerificationTimestamp = select.queryForObject(
					"select email_verification_timestamp from public.dept_registration where dept_id=?",
					new Object[] { deptId }, java.sql.Timestamp.class);
		} catch (Exception e) {
			logger.info(e);
			return false;
		}
		if (queryEmailVerificationTimestamp != null)
			return true;
		else
			return false;
	}

	public List<UserStatus> getTransactionStatus() {
		logger.info("getTransactionStatus");
		JdbcTemplate select = jdbcTemplate(getTenantName());
		try {
			return select.query(
					"Select concat(lk.dept_id::text,'_', lk.license_type::text) AS dept_id,lk.is_krdh_activated as is_active , users.dept_name,users.username,lk.license_type as type from public.license_keys as lk ,public.asa_registration as users  where lk.dept_id=users.dept_id and lk.is_active=true and lk.license_type not in ('ASA','KSA')",
					new RowMapper<UserStatus>() {
						public UserStatus mapRow(ResultSet rs, int arg1) throws SQLException {
							ResultSetMetaData metaData = rs.getMetaData();
							int count = metaData.getColumnCount();
							UserStatus us = new UserStatus();
							us.setDeptName(rs.getString("dept_name"));
							us.setUserName(rs.getString("username"));
							us.setLoginStatus(rs.getBoolean("is_active"));
							us.setId(rs.getString("dept_id"));

							if (count > 4) {
								us.setType(rs.getString("type"));
							}
							return us;
						}
					});
		} catch (DataAccessException ex) {
			logger.info(ex);
			return null;
		} catch (Exception e) {
			logger.info(e);
			return null;
		}
	}

	public void updateTransactionStatus(final List<String> deptId, final List<String> type,
			final boolean transactionStatus) {
		JdbcTemplate update = jdbcTemplate(getTenantName());
		logger.info("updateTransactionStatus deptId  deptId::" + deptId + "\n type::" + type + " \n transactionStatus"
				+ transactionStatus);
		String sql = "UPDATE public.license_keys SET is_krdh_activated=?  WHERE license_type=? and dept_id=? and is_active=true";
		update.batchUpdate(sql, new BatchPreparedStatementSetter() {
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				String dept_id = deptId.get(i);
				String lkType = type.get(i);
				ps.setBoolean(1, transactionStatus);
				ps.setString(2, lkType);
				ps.setInt(3, Integer.valueOf(dept_id));
			}

			public int getBatchSize() {
				return deptId.size();
			}
		});
	}

	@Override
	public List<TransactionDetailReport> getTransactionDetailsReport(String username, int roleid, String txnType,
			String fDate, String lDate) {
		JdbcTemplate ds = jdbcTemplate(getTenantName());

		StringTokenizer stringTokenizer = new StringTokenizer(fDate, "-");
		int i = 0;
		String[] a1 = new String[3];
		while (stringTokenizer.hasMoreElements()) {
			String aa = (String) stringTokenizer.nextElement();
			a1[i] = aa;
			i++;
		}
		String fDate1 = a1[2] + "-" + a1[1] + "-" + a1[0];

		StringTokenizer stringTokenizer2 = new StringTokenizer(lDate, "-");
		int j = 0;
		String[] a2 = new String[3];
		while (stringTokenizer2.hasMoreElements()) {
			String aa = (String) stringTokenizer2.nextElement();
			a2[j] = aa;
			j++;
		}
		String lDate1 = a2[2] + "-" + a2[1] + "-" + a2[0];

		String query = "";
		String whereClause2 = "date(request_receipt_time) between '" + fDate1 + "' and '" + lDate1 + "'";
		String select = "";

		if (txnType.equalsIgnoreCase("otp")) {
			select = "select txn,aua_code,ver,sa,type,ret,resp_code,err,request_receipt_time,request_forward_time,response_receipt_time,response_forward_time,packet_response_time,packet_request_time,ch from otp_log  ";
		} else if (txnType.equalsIgnoreCase("kyc")) {
			select = "select ver,ra,rc,lr,de,pfr,status,ko,ret,code,txn,ts,err,actn,auth_rc,aua_code,sa,auth_ver,auth_txn,pi,pa,pfa,bio,bt,pin,otp,request_receipt_time,request_forward_time,response_receipt_time,response_forward_time,"
					+ "response_time_cidr,type,auth_actn,kyc_ret,kyc_err,auth_err,ci from kyc_log  ";
		} else if (txnType.equalsIgnoreCase("auth")) {
			select = "select txn,aua_code,ver,pi,pa,pfa,bio,bt,pin,otp,res_code,sa,rc,actn,ret,err,request_receipt_time,request_forward_time,response_receipt_time,response_forward_time,packet_response_time,type,ci from auth_log ";
		}
		if (roleid == 1) {
			query = select + " where " + whereClause2;
		} else {
			String sa_code = getSACodeFromUsername(username);
			query = select + " where sa_code=" + sa_code + " and " + whereClause2;
		}
		List<TransactionDetailReport> list = new ArrayList<TransactionDetailReport>();
		if (txnType.equalsIgnoreCase("otp")) {
			logger.info("final Query for otp::" + query);

			list = ds.query(query, new RowMapper<TransactionDetailReport>() {
				public TransactionDetailReport mapRow(ResultSet rs, int arg1) throws SQLException {
					TransactionDetailReport obj = new TransactionDetailReport();
					obj.setTxn(rs.getString("txn"));
					obj.setAua_code(rs.getString("aua_code"));
					obj.setVer(rs.getString("ver"));
					obj.setSa(rs.getString("sa"));
					obj.setType(rs.getString("type"));
					obj.setRet(rs.getString("ret"));
					obj.setResponseCode(rs.getString("resp_code"));
					obj.setErrorCode(rs.getString("err"));
					obj.setRequestReceiptTime(rs.getString("request_receipt_time"));
					obj.setResponseReceiptTime(rs.getString("request_forward_time"));
					obj.setResponseReceiptTime(rs.getString("response_receipt_time"));
					obj.setResponse_forward_time(rs.getString("response_forward_time"));
					obj.setPacket_response_time(rs.getString("packet_response_time"));
					obj.setPacket_request_time(rs.getString("packet_request_time"));
					obj.setCh(rs.getString("ch"));

					return obj;
				}
			});

		} else if (txnType.equalsIgnoreCase("kyc")) {
			logger.info("final Query kyc ::" + query);
			list = ds.query(query, new RowMapper<TransactionDetailReport>() {

				public TransactionDetailReport mapRow(ResultSet rs, int arg1) throws SQLException {
					TransactionDetailReport obj = new TransactionDetailReport();
					obj.setTxn(rs.getString("txn"));
					obj.setAua_code(rs.getString("aua_code"));
					obj.setVer(rs.getString("ver"));
					obj.setPi(rs.getString("pi"));
					obj.setPa(rs.getString("pa"));
					obj.setPfa(rs.getString("pfa"));
					obj.setBio(rs.getString("bio"));
					obj.setBt(rs.getString("bt"));
					obj.setPin(rs.getString("pin"));
					obj.setOtp(rs.getString("otp"));
					obj.setSa(rs.getString("sa"));
					obj.setRc(rs.getString("rc"));
					obj.setActn(rs.getString("actn"));
					obj.setType(rs.getString("type"));
					obj.setRet(rs.getString("ret"));
					obj.setErrorCode(rs.getString("err"));
					obj.setRequestReceiptTime(rs.getString("request_receipt_time"));
					obj.setResponseReceiptTime(rs.getString("request_forward_time"));
					obj.setResponseReceiptTime(rs.getString("response_receipt_time"));
					obj.setResponse_forward_time(rs.getString("response_forward_time"));
					obj.setResponse_time_cidr(rs.getString("response_time_cidr"));
					obj.setCi(rs.getString("ci"));
					obj.setRa(rs.getString("ra"));
					obj.setLr(rs.getString("lr"));
					obj.setDe(rs.getString("de"));
					obj.setPfr(rs.getString("pfr"));
					obj.setStatus(rs.getString("status"));
					obj.setKo(rs.getString("ko"));
					obj.setCode(rs.getString("code"));
					obj.setTs(rs.getString("ts"));
					obj.setAuth_rc(rs.getString("auth_rc"));
					obj.setAuth_ver(rs.getString("auth_ver"));
					obj.setAuth_txn(rs.getString("auth_txn"));
					obj.setAuth_actn(rs.getString("auth_actn"));
					obj.setKyc_ret(rs.getString("kyc_ret"));
					obj.setKyc_err(rs.getString("kyc_err"));
					obj.setAuth_err(rs.getString("auth_err"));

					return obj;
				}
			});
		} else if (txnType.equalsIgnoreCase("auth")) {
			logger.info("final Query auth::" + query);
			list = ds.query(query, new RowMapper<TransactionDetailReport>() {
				public TransactionDetailReport mapRow(ResultSet rs, int arg1) throws SQLException {
					TransactionDetailReport obj = new TransactionDetailReport();
					obj.setTxn(rs.getString("txn"));
					obj.setAua_code(rs.getString("aua_code"));
					obj.setVer(rs.getString("ver"));
					obj.setPi(rs.getString("pi"));
					obj.setPa(rs.getString("pa"));
					obj.setPfa(rs.getString("pfa"));
					obj.setBio(rs.getString("bio"));
					obj.setBt(rs.getString("bt"));
					obj.setPin(rs.getString("pin"));
					obj.setOtp(rs.getString("otp"));
					obj.setSa(rs.getString("sa"));
					obj.setRc(rs.getString("rc"));
					obj.setActn(rs.getString("actn"));
					obj.setType(rs.getString("type"));
					obj.setRet(rs.getString("ret"));
					obj.setResponseCode(rs.getString("res_code"));
					obj.setErrorCode(rs.getString("err"));
					obj.setRequestReceiptTime(rs.getString("request_receipt_time"));
					obj.setResponseReceiptTime(rs.getString("request_forward_time"));
					obj.setResponseReceiptTime(rs.getString("response_receipt_time"));
					obj.setResponse_forward_time(rs.getString("response_forward_time"));
					obj.setPacket_response_time(rs.getString("packet_response_time"));
					obj.setCi(rs.getString("ci"));
					return obj;
				}
			});
		}
		return list;

	}

	@Override
	public List<TransactionDetailReport> getTransactionDetailsCsvReport(String username, String txnType, String fDate,
			String lDate) {
		JdbcTemplate ds = jdbcTemplate(getTenantName());

		StringTokenizer stringTokenizer = new StringTokenizer(fDate, "-");
		int i = 0;
		String[] a1 = new String[3];
		while (stringTokenizer.hasMoreElements()) {
			String aa = (String) stringTokenizer.nextElement();
			a1[i] = aa;
			i++;
		}
		String fDate1 = a1[2] + "-" + a1[1] + "-" + a1[0];

		StringTokenizer stringTokenizer2 = new StringTokenizer(lDate, "-");
		int j = 0;
		String[] a2 = new String[3];
		while (stringTokenizer2.hasMoreElements()) {
			String aa = (String) stringTokenizer2.nextElement();
			a2[j] = aa;
			j++;
		}
		String lDate1 = a2[2] + "-" + a2[1] + "-" + a2[0];

		String query = "select sum(txn_count) filter(where status ilike'y') as success,\r\n"
				+ "sum(txn_count) filter(where status ilike 'n') as unsuccess,\r\n"
				+ "sum(txn_count) filter (where status ilike 'y' or status ilike 'n') as Total from trans_stats\r\n"
				+ "where ac in(select app_code  from application_details where dept_code in (select schema_name from dept_details where username='"
				+ username + "')) and date BETWEEN '" + fDate1 + "' and '" + lDate1 + "';";

		List<TransactionDetailReport> list = new ArrayList<TransactionDetailReport>();
		if (txnType.equalsIgnoreCase("custom")) {
			logger.info("final Query for custom::" + query);

			list = ds.query(query, new RowMapper<TransactionDetailReport>() {
				public TransactionDetailReport mapRow(ResultSet rs, int arg1) throws SQLException {
					TransactionDetailReport obj = new TransactionDetailReport();
					obj.setSuccess(rs.getString("Success"));
					obj.setUnsuccess(rs.getString("Unsuccess"));
					obj.setTotal(rs.getString("Total"));
					return obj;
				}
			});

		} else if (txnType.equalsIgnoreCase("current")) {
			logger.info("final Query current ::" + query);
			list = ds.query(query, new RowMapper<TransactionDetailReport>() {

				public TransactionDetailReport mapRow(ResultSet rs, int arg1) throws SQLException {
					TransactionDetailReport obj = new TransactionDetailReport();
					obj.setSuccess(rs.getString("Success"));
					obj.setUnsuccess(rs.getString("Unsuccess"));
					obj.setTotal(rs.getString("Total"));

					return obj;
				}
			});
		} else if (txnType.equalsIgnoreCase("threemonth")) {
			logger.info("final Query threemonth::" + query);
			list = ds.query(query, new RowMapper<TransactionDetailReport>() {
				public TransactionDetailReport mapRow(ResultSet rs, int arg1) throws SQLException {
					TransactionDetailReport obj = new TransactionDetailReport();
					obj.setSuccess(rs.getString("Success"));
					obj.setUnsuccess(rs.getString("Unsuccess"));
					obj.setTotal(rs.getString("Total"));
					return obj;
				}
			});
		} else if (txnType.equalsIgnoreCase("sixmonth")) {
			logger.info("final Query threemonth::" + query);
			list = ds.query(query, new RowMapper<TransactionDetailReport>() {
				public TransactionDetailReport mapRow(ResultSet rs, int arg1) throws SQLException {
					TransactionDetailReport obj = new TransactionDetailReport();
					obj.setSuccess(rs.getString("Success"));
					obj.setUnsuccess(rs.getString("Unsuccess"));
					obj.setTotal(rs.getString("Total"));
					return obj;
				}
			});
		}

		return list;

	}

	public List<KuaLk> getKualk(String userName) {
		logger.info("getKualk userName::" + userName);

		JdbcTemplate select = jdbcTemplate(getTenantName());
		try {
			return select.query(
					"select to_char(lk.valid_till,'DD-MM-YYYY')  as valid_till , lk.license_key , lk.is_krdh_activated , lk.client_license_key as clk from public.license_keys as lk where lk.is_active=true and lk.license_type=? and lk.dept_id = (Select dept_id from public.asa_registration where  username = ?)",
					new Object[] { LicenceType.KUA.getValue(), userName }, new RowMapper<KuaLk>() {
						public KuaLk mapRow(ResultSet rs, int arg1) throws SQLException {
							KuaLk lk = new KuaLk();
							lk.setLk(rs.getString("license_key"));
							lk.setValidTill(rs.getString("valid_till"));
							lk.setServiceActivated(rs.getBoolean("is_krdh_activated"));
							lk.setClk(rs.getString("clk"));
							return lk;
						}
					});
		} catch (DataAccessException ex) {
			logger.info(ex);
			return null;
		} catch (Exception e) {
			logger.info(e);
			return null;
		}
	}

	public boolean updatekuaLk(String userName, KuaLk kua) {
		logger.info("updatekuaLk userName" + userName);

		JdbcTemplate update = jdbcTemplate(getTenantName());
		List<KuaLk> listOfKuaLk = getKualk(userName);
		boolean isActivated = true;
		if (listOfKuaLk.size() > 0) {
			isActivated = listOfKuaLk.get(0).isServiceActivated();
		}
		try {
			if (listOfKuaLk.size() > 0) {
				update.update(
						"Update public.license_keys set is_active=false where license_type=? and dept_id =(Select dept_id from public.asa_registration where username = ? )",
						new Object[] { LicenceType.KUA.getValue(), userName });
			}
			String randomUuid = UUID.randomUUID().toString();
			logger.info("check the value of isActivated" + isActivated);
			update.update(
					"INSERT INTO public.license_keys( dept_id, ac, license_key, valid_till, update_by, update_timestamp,"
							+ "is_active, client_license_key, is_krdh_activated,license_type,username) "
							+ "select dept_id, ac,?,to_date(?,'dd-mm-yyyy')::date,username, now(), true, ?, ?,?,? from users where username =?",
					new Object[] { kua.getLk(), kua.getValidTill(), randomUuid, isActivated, LicenceType.KUA.getValue(),
							userName, userName });
			return true;
		} catch (Exception e) {
			logger.info(e);
			return false;
		}
	}

	public String generateUdcCode(String userName, GenerateUdcCode udc) {
		logger.info("generateUdcCode userName::" + userName);
		JdbcTemplate update = jdbcTemplate(getTenantName());
		String udcCode = null;
		SimpleDateFormat format2 = new SimpleDateFormat("ddMMMyyyy");
		Date date = new Date();
		String dateString = format2.format(date);
		String vendorCode = udc.getVendorCode();
		udcCode = vendorCode.substring(0, 3) + dateString + getUdcSequence();
		udcCode = udcCode.toUpperCase();
		AcCode acCode = getAcCode(userName).get(0);
		update.update(
				"INSERT INTO public.ac_device_codes(udc, ac, vendor_code,update_by,update_timestamp,username) VALUES (?, ?, ?, ?,now(),?);",
				new Object[] { udcCode, acCode.getAcCode(), udc.getVendorCode(), userName, userName });
		return udcCode;

	}

	public List<GenerateUdcCode> getUdc(String userName) {
		logger.info("getUdc userName::" + userName);
		JdbcTemplate select = jdbcTemplate(getTenantName());
		try {
			return select.query(
					"select devices.* from public.ac_device_codes as devices, public.asa_registration as users where users.ac = devices.ac and users.username = ?",
					new Object[] { userName }, new GenerateUdcCodeRowMapper());
		} catch (DataAccessException ex) {
			logger.info(ex);
			return null;
		} catch (Exception e) {
			logger.info(e);
			return null;
		}
	}

	public String getCurrentDeptId(String userName) {
		logger.info("getCurrentDeptId userName::" + userName);
		JdbcTemplate select = jdbcTemplate(getTenantName());
		String deptId = null;
		try {
			deptId = select.queryForObject("select dept_code from public.dept_details where username=?",
					new Object[] { userName }, String.class);
		} catch (DataAccessException ex) {
			logger.info(ex);
			return null;
		} catch (Exception e) {
			logger.info(e);
			return null;
		}
		return deptId;
	}

	public String getAppCode(String dept) {
		logger.info("getCurrentAPPCode::" + dept);
		JdbcTemplate select = jdbcTemplate(getTenantName());
		String deptId = null;
		try {
			deptId = select.queryForObject("select app_code from public.application_details where dept_code=?",
					new Object[] { dept }, String.class);
		} catch (DataAccessException ex) {
			logger.info(ex);
			return null;
		} catch (Exception e) {
			logger.info(e);
			return null;
		}
		return deptId;
	}

	public List<AuthCount> getAuthTransStats(String userName) {
		logger.info("getAuthTransStats userName::" + userName);
		JdbcTemplate select = jdbcTemplate(getTenantName());
		String whereClause = " ";
		try {
			return select.query(
					"SELECT sum(ts.trans_count) as count, ts.dept_id,us.dept_name FROM public.trans_stats as ts ,public.asa_registration as us  where ts.table_name like 'auth%' and ts.dept_id=us.dept_id "
							+ whereClause + " group by ts.dept_id,us.dept_name",
					new RowMapper<AuthCount>() {
						public AuthCount mapRow(ResultSet rs, int arg1) throws SQLException {
							AuthCount count = new AuthCount();
							count.setCount(rs.getInt("count"));
							count.setDeptId(rs.getInt("dept_id"));
							count.setDeptName(rs.getString("dept_name"));
							return count;
						}
					});
		} catch (DataAccessException ex) {
			logger.info(ex);
			return null;
		} catch (Exception e) {
			logger.info(e);
			return null;
		}
	}

	public List<AuthCount> getOtpTransStats(String userName) {
		logger.info("getOtpTransStats userName::" + userName);
		JdbcTemplate select = jdbcTemplate(getTenantName());
		String whereClause = " ";
		try {
			return select.query(
					"SELECT sum(ts.trans_count) as count, ts.dept_id,us.dept_name FROM public.trans_stats as ts ,public.asa_registration as us  where ts.table_name like 'otp%' and ts.dept_id=us.dept_id "
							+ whereClause + " group by ts.dept_id,us.dept_name",
					new RowMapper<AuthCount>() {
						public AuthCount mapRow(ResultSet rs, int arg1) throws SQLException {
							AuthCount count = new AuthCount();
							count.setCount(rs.getInt("count"));
							count.setDeptId(rs.getInt("dept_id"));
							count.setDeptName(rs.getString("dept_name"));
							return count;
						}
					});
		} catch (DataAccessException ex) {
			logger.info(ex);
			return null;

		} catch (Exception e) {
			logger.info(e);
			return null;
		}
	}

	public List<AuthCount> getKycTransStats(String userName) {
		logger.info("getKycTransStats userName::" + userName);
		JdbcTemplate select = jdbcTemplate(getTenantName());
		String whereClause = " ";
		try {
			return select.query(
					"SELECT sum(ts.trans_count) as count, ts.dept_id,us.dept_name FROM public.trans_stats as ts ,public.asa_registration as us  where ts.table_name like 'kyc%' and ts.dept_id=us.dept_id "
							+ whereClause + " group by ts.dept_id,us.dept_name",
					new RowMapper<AuthCount>() {
						public AuthCount mapRow(ResultSet rs, int arg1) throws SQLException {
							AuthCount count = new AuthCount();
							count.setCount(rs.getInt("count"));
							count.setDeptId(rs.getInt("dept_id"));
							count.setDeptName(rs.getString("dept_name"));
							return count;
						}
					});
		} catch (DataAccessException ex) {
			logger.info(ex);
			return null;
		} catch (Exception e) {
			logger.info(e);
			return null;
		}
	}

	public Map<String, List<TransactionCountDetails>> getMonthlyCountAdmin(String userName, Integer role) {
		logger.info("getMonthlyCountAdmin userName::" + userName + "::role::" + role);
		JdbcTemplate select = jdbcTemplate(getTenantName());
		String whereClause = "";
		if (role == 1) {
			whereClause = "where dept_id=" + getCurrentDeptId(userName);
		}
		return select.query(
				"SELECT sum(trans_count) as count, substring(table_name,0 , position('_' in table_name)) as table_name ,"
						+ "to_char(to_timestamp (date_part('month', txn_date)::text, 'MM'), 'Mon')"
						+ " as dates FROM public.trans_stats " + whereClause
						+ " group by dates,table_name order by dates",
				new ResultSetExtractor<Map<String, List<TransactionCountDetails>>>() {

					public Map<String, List<TransactionCountDetails>> extractData(ResultSet rs)
							throws SQLException, DataAccessException {
						Map<String, List<TransactionCountDetails>> map = new LinkedHashMap<String, List<TransactionCountDetails>>();
						String prevMonth = "";
						List<TransactionCountDetails> countList = null;
						while (rs.next()) {
							String tableName = rs.getString("table_name");
							Integer count = rs.getInt("count");
							String month = rs.getString("dates");
							if (!prevMonth.trim().equals(month.trim())) {
								logger.info("Monthchanged::" + prevMonth + "  " + month);
								countList = new ArrayList<TransactionCountDetails>();
								map.put(month, countList);
								prevMonth = month;
							}
							TransactionCountDetails trans = new TransactionCountDetails();
							trans.setCount(count);
							trans.setType(tableName);
							countList.add(trans);
						}
						return map;
					}
				});
	}

	public Map<String, Map<String, Integer>> getHomeBar(String userName) {
		logger.info("getHomeBar userName::" + userName);
		JdbcTemplate select = jdbcTemplate(getTenantName());

		// String whereClause = "";
		/*
		 * if (role == 1) { whereClause = " and dept_id='" + getCurrentDeptId(userName)
		 * + "'"; }
		 */

		return select.query(
				/*
				 * "select to_char(txn_date,'yyyy-mm') as months ,sum(total_count) as count,transaction_type  FROM public.vw_dept_wise_total_count where txn_date  >  CURRENT_DATE - INTERVAL '6 months'"
				 * + whereClause +
				 * " group by months,transaction_type order by months,transaction_type",
				 */

				"select to_char(date,'yyyy-mm') as months ,sum(txn_count) as count,opr  FROM public.trans_stats where date  >  CURRENT_DATE - INTERVAL '6 months'"
						+ " group by months,opr order by opr",

				new HomebarResultSetExtractor());
	}

	public Map<String, Integer> getHomePageCount(String userName) {

		JdbcTemplate select = jdbcTemplate(getTenantName());
		String whereClause = "";
		/*
		 * if (role == 1) { whereClause = "and  dept_id='" + getCurrentDeptId(userName)
		 * + "'"; }
		 */
		return select.query(
				/*
				 * "select sum(trans_count) as count,substring(table_name,0 , position('_' in table_name)) as type from public.trans_stats where resp_status='PASS' "
				 * + whereClause + " group by table_name order by type",
				 */

				" select opr,sum(txn_count) as count from public.trans_stats  group by opr order by opr",
				new ResultSetExtractor<Map<String, Integer>>() {
					public Map<String, Integer> extractData(ResultSet rs) throws SQLException, DataAccessException {
						Map<String, Integer> map = new HashMap<String, Integer>();
						while (rs.next()) {
							map.put(rs.getString("opr"), rs.getInt("count"));
						}
						return map;
					}
				});
	}

	public List<LicensekeyDetails> getAsalk(String userName) {
		logger.info("getAsalk userName::" + userName);
		JdbcTemplate select = jdbcTemplate(getTenantName());
		try {
			return select.query(
					"select to_char(lk.aua_valid_till,'DD-MM-YYYY')  as aua_valid_till , lk.aua_license_key , lk.is_dept_activated from public.aua_lk_details as lk where lk.is_active=true and lk.license_type=? and lk.dept_id = (Select dept_id from public.users where  username = ?)",
					new Object[] { LicenceType.AUA.getValue(), userName }, new RowMapper<LicensekeyDetails>() {
						public LicensekeyDetails mapRow(ResultSet rs, int arg1) throws SQLException {
							LicensekeyDetails lk = new LicensekeyDetails();
							lk.setLicenseKey(rs.getString("aua_license_key"));
							lk.setValidTill(rs.getString("aua_valid_till"));
							lk.setDeptActivated(rs.getBoolean("is_dept_activated"));
							return lk;
						}
					});
		} catch (DataAccessException ex) {
			logger.info(ex);
			return null;
		} catch (Exception e) {
			logger.info(e);
			return null;
		}
	}

	public boolean updateAsaLk(String userName, LicensekeyDetails updateAsaLK) {
		logger.info("updateAsaLk userName::" + userName);
		JdbcTemplate update = jdbcTemplate(getTenantName());
		List<LicensekeyDetails> listOfAsaLk = getAsalk(userName);
		boolean isDeptActivated = true;
		if (listOfAsaLk.size() > 0) {
			isDeptActivated = listOfAsaLk.get(0).isDeptActivated();
		}
		Integer deptId = null;
		try {
			if (deptId == null) {
				long dept_id = update.queryForObject("select dept_id from public.users where username = ?",
						new Object[] { userName }, Long.class);
				update.update(
						"Update public.aua_lk_details set is_active=false where license_type=? and dept_id =(Select dept_id from public.users where username = ? )",
						new Object[] { LicenceType.AUA.getValue(), userName });
				logger.info("inserting new lk" + updateAsaLK.getLicenseKey());
				update.update(
						"INSERT INTO public.aua_lk_details( dept_id, aua_code, aua_license_key, aua_valid_till, update_by, update_timestamp,"
								+ "is_active,  is_dept_activated,license_type) "
								+ "select dept_id, aua_code,?,to_date(?,'dd-mm-yyyy')::date, ?,now(), true,  ?,? from dept_registration where dept_id =?",
						new Object[] { updateAsaLK.getLicenseKey(), updateAsaLK.getValidTill(), userName,
								isDeptActivated, LicenceType.AUA.getValue(), dept_id });
				return true;
			}
		} catch (Exception e) {
			logger.info(e);
			return false;
		}
		return false;
	}

	public List<LicensekeyDetails> getKsalk(String userName) {

		logger.info("getKsalk userName::" + userName);
		JdbcTemplate select = jdbcTemplate(getTenantName());
		try {
			return select.query(
					"select to_char(lk.aua_valid_till,'DD-MM-YYYY')  as aua_valid_till , lk.aua_license_key , lk.is_dept_activated from public.aua_lk_details as lk where lk.is_active=true and lk.license_type=? and lk.dept_id = (Select dept_id from public.users where  username = ?)",
					new Object[] { LicenceType.KUA.getValue(), userName }, new RowMapper<LicensekeyDetails>() {

						public LicensekeyDetails mapRow(ResultSet rs, int arg1) throws SQLException {
							LicensekeyDetails lk = new LicensekeyDetails();
							lk.setLicenseKey(rs.getString("aua_license_key"));
							lk.setValidTill(rs.getString("aua_valid_till"));
							lk.setDeptActivated(rs.getBoolean("is_dept_activated"));
							return lk;
						}
					});
		} catch (DataAccessException ex) {
			logger.info(ex);
			return null;
		} catch (Exception e) {
			logger.info(e);
			return null;
		}
	}

	public boolean updateKsaLk(String userName, LicensekeyDetails updateKsaLK)
			throws DataAccessException, ParseException {
		logger.info("updateKsaLk userName" + userName);
		JdbcTemplate update = jdbcTemplate(getTenantName());
		List<LicensekeyDetails> listOfKsaLk = getKsalk(userName);
		boolean isDeptActivated = true;
		if (listOfKsaLk.size() > 0) {
			isDeptActivated = listOfKsaLk.get(0).isDeptActivated();
		}
		try {
			update.update(
					"Update public.aua_lk_details set is_active=false where license_type=? and dept_id =(Select dept_id from public.users where username = ? )",
					new Object[] { LicenceType.KUA.getValue(), userName });
			logger.info("inserting new lk" + updateKsaLK.getLicenseKey());
			long dept_id = update.queryForObject("SELECT dept_id FROM public.users where username=?",
					new Object[] { userName }, Long.class);
			update.update(
					"INSERT INTO public.aua_lk_details( dept_id, aua_code, aua_license_key, aua_valid_till, update_by, update_timestamp,"
							+ "is_active, is_dept_activated,license_type) "
							+ "select dept_id, aua_code,?,to_date(?,'dd-mm-yyyy')::date,?, now(), true, ?,? from dept_registration where dept_id =?",
					new Object[] { updateKsaLK.getLicenseKey(), updateKsaLK.getValidTill(), userName, isDeptActivated,
							LicenceType.KUA.getValue(), dept_id });
			return true;
		} catch (Exception e) {
			logger.info(e);
			return false;
		}
	}

	public ConnectorParam getconnectorParam(String userName) {

		logger.info("getconnectorParam userName::" + userName);
		JdbcTemplate select = jdbcTemplate(getTenantName());
		List<LicensekeyDetails> licenseKeyDetails = null;
		Map<Integer, String> udcDetails = null;
		String ac = null;
		String deptName = "";
		try {
			licenseKeyDetails = select.query(
					"SELECT ac, license_key as lk,license_type,client_license_key as clk,valid_till FROM public.license_keys where is_active = true and username=?",
					new Object[] { userName }, new RowMapper<LicensekeyDetails>() {
						public LicensekeyDetails mapRow(ResultSet rs, int arg1) throws SQLException {
							LicensekeyDetails licensekey = new LicensekeyDetails();
							licensekey.setLicenseKey(rs.getString("lk"));
							licensekey.setLicenseKeyType(LicenceType.valueOf(rs.getString("license_type")));
							licensekey.setClientLicensekey(rs.getString("clk"));
							licensekey.setValidTill(rs.getString("valid_till"));
							return licensekey;
						}
					});
			udcDetails = select.query("SELECT udc FROM public.ac_device_codes where username=?",
					new Object[] { userName }, new ResultSetExtractor<Map<Integer, String>>() {
						public Map<Integer, String> extractData(ResultSet rs) throws SQLException, DataAccessException {
							Map<Integer, String> map = new HashMap<Integer, String>();
							int i = 1;
							while (rs.next()) {
								String udc = rs.getString("udc");
								map.put(i, udc);
								i++;
							}
							return map;
						}
					});
			ac = select.queryForObject(
					"select users.ac from public.asa_registration as users where  users.username = ?",
					new Object[] { userName }, String.class);
			deptName = select.queryForObject(
					"select users.dept_name from public.asa_registration as users where  users.username = ?",
					new Object[] { userName }, String.class);
		} catch (DataAccessException ex) {
			logger.info(ex);
			return null;
		} catch (Exception e) {
			logger.info(e);
			return null;
		}
		ConnectorParam param = new ConnectorParam();
		param.setDeptName(deptName);
		param.setAc(ac);
		param.setUdc(udcDetails);
		param.setLkDetails(licenseKeyDetails);
		return param;
	}

	public List<String> getUdcList(String userName) {
		logger.info("getUdcList userName::" + userName);
		JdbcTemplate select = jdbcTemplate(getTenantName());
		try {
			return select.query("SELECT udc FROM public.ac_device_codes where username=?", new Object[] { userName },
					new RowMapper<String>() {
						public String mapRow(ResultSet rs, int arg1) throws SQLException {
							return rs.getString("udc");
						}
					});
		} catch (DataAccessException ex) {
			logger.info(ex);
			return null;
		} catch (Exception e) {
			logger.info(e);
			return null;
		}
	}

	public Object getparamdetails(String userName) {
		return null;
	}

	public Map<String, Integer> getMonthlyTotalTrans(String userName) {
		logger.info("getMonthlyTotalTrans userName::" + userName);
		JdbcTemplate select = jdbcTemplate(getTenantName());
		String whereClause = "";
		/*
		 * if (role == 1) { whereClause = " and dept_id='" + getCurrentDeptId(userName)
		 * + "'"; }
		 */
		try {
			return select.query(
					"select to_char(date,'yyyy-mm') as month,sum(txn_count) as count from public.trans_stats  "
							+ " group by 1,1 order by month desc limit 12 ",
					new ResultSetExtractor<Map<String, Integer>>() {
						public Map<String, Integer> extractData(ResultSet rs) throws SQLException, DataAccessException {
							Map<String, Integer> map = new LinkedHashMap<String, Integer>();
							String month = null;
							int count = 0;
							while (rs.next()) {
								month = rs.getString("month");
								count = rs.getInt("count");
								map.put(month, count);
							}
							return map;
						}
					});
		} catch (DataAccessException ex) {
			logger.info(ex);
			return null;
		} catch (Exception e) {
			logger.info(e);
			return null;
		}
	}

	public boolean checkUserFromEmailId(String emailId) {
		logger.info("checkUserFromEmailId emailId::" + emailId);
		JdbcTemplate select = jdbcTemplate(getTenantName());
		// Integer deptId = 0;
		String deptCode = null;
		try {
			deptCode = select.queryForObject("select dept_code from public.dept_details where email = ?",
					new Object[] { emailId }, String.class);
		} catch (DataAccessException ex) {
			logger.info(ex);
			return false;
		} catch (Exception e) {
			logger.info(e);
			return false;
		}
		logger.info("Dept code::" + deptCode);
		if (deptCode == null)
			return false;
		else
			return true;
	}

	public String getUserNameFromEmailId(String emailId) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		String userName = select.queryForObject("select username from public.dept_details where email = ?",
				new Object[] { emailId }, String.class);
		logger.info("UserName  : " + userName);
		return userName;
	}

	public boolean checkAuaCode(String auaCode) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		String fetchedAuaCode = select.queryForObject("select ac from public.asa_registration where ac = ?",
				new Object[] { auaCode }, String.class);
		logger.info("Aua Code : " + fetchedAuaCode);
		if (fetchedAuaCode == null)
			return false;
		else
			return true;
	}

	public List<AdminDeptCount> getAdminDeptCount() {

		JdbcTemplate select = jdbcTemplate(getTenantName());

		return select.query(
				// "select u.dept_name,t.dept_id, t.table_name, sum(t.trans_count) as count from
				// trans_stats t,users u where t.dept_id=u.dept_id and resp_status='PASS' group
				// by u.dept_name,t.dept_id, table_name order by dept_name;",
				"select u.app_name, sum(t.txn_count) as count from trans_stats t,application_details u where t.ac=u.app_code and status='y' group by u.app_name,t.ac order by app_name;",
				new AdminDeptCountResultSetExtractor());

	}

	public int getDeptCount(String userName) {

		JdbcTemplate select = jdbcTemplate(getTenantName());
		int count = 0;
		try {

			count = select.queryForObject("select count(Distinct ac) FROM public.trans_stats ", Integer.class);
		} catch (DataAccessException ex) {
			logger.info(ex);
			return 0;

		} catch (Exception e) {
			logger.info(e);
			return 0;
		}

		return count;
	}

	public String getCurrentEmailId(String userName) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		String email = null;
		try {
			email = select.queryForObject("SELECT email FROM public.dept_details where username= ?",
					new Object[] { userName }, String.class);

		} catch (DataAccessException ex) {
			logger.info(ex);
			return null;

		} catch (Exception e) {
			logger.info(e);
			return null;
		}

		return email;
	}

	public String getCurrentDeptName(String emailId) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		String deptName = null;
		try {
			deptName = select.queryForObject("SELECT dept_name FROM public.asa_registration where cd_email= ?",
					new Object[] { emailId }, String.class);
		}

		catch (DataAccessException ex) {
			logger.info(ex);

			return null;

		} catch (Exception e) {
			logger.info(e);
			return null;
		}

		return deptName;
	}

	public boolean checkUserFromDeptName(String appName) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		// Integer deptId = 0;
		logger.info("*****appName::" + appName);
		String appCode = null;
		try {
			appCode = select.queryForObject("select app_code from public.application_details where app_name = ?",
					new Object[] { appName.trim() }, String.class);
		} catch (DataAccessException ex) {
			logger.info("*******" + appCode);
			logger.info(ex);
			return false;
		}

		logger.info("app code : " + appCode);
		if (appCode == null)
			return false;
		else
			return true;
	}

	public List<String> getEmailIdFromDeptId(List<String> deptId) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		List<String> emails = new ArrayList<String>();
		String email;
		for (int i = 0; i < deptId.size(); i++) {

			email = select.queryForObject("select cd_email from public.dept_registration where dept_id = ?",
					new Object[] { Integer.parseInt(deptId.get(i)) }, String.class);
			emails.add(email);
		}

		return emails;
	}

	public List<String> getEmailIdFromUsername(List<String> username) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		List<String> emails = new ArrayList<String>();
		String email;
		for (int i = 0; i < username.size(); i++) {

			email = select.queryForObject("select email from public.users where username = ?",
					new Object[] { username.get(i) }, String.class);
			emails.add(email);

		}

		return emails;
	}

	private int getUdcSequence() {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		int udcsequence = select.queryForObject("select nextval('public.udc_codes_seq')", Integer.class);
		return udcsequence;
	}

	public boolean checkForDuplicateKey(LicensekeyDetails lk, String type, int currentDeptId) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		Integer deptid = null;
		try {
			deptid = select.queryForObject(
					"SELECT dept_id FROM public.license_keys where license_key=? and valid_till=to_date(?,'dd-mm-yyyy')::date and license_type=? and dept_id=? and client_license_key=?",
					new Object[] { lk.getLicenseKey(), lk.getValidTill(), type, currentDeptId,
							lk.getClientLicensekey() },
					new int[] { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.VARCHAR },
					Integer.class);
		} catch (EmptyResultDataAccessException e) {
			logger.info(e);
		}
		logger.info(deptid);
		if (deptid != null) {
			return true;
		} else {
			return false;
		}

	}

	public boolean checkForgetPasswordDetail(ForgetPassword fg) {

		JdbcTemplate select = jdbcTemplate(getTenantName());
		Integer deptid = null;
		try {
			deptid = select.queryForObject("SELECT dept_id FROM public.users where username=? and email=?",
					new Object[] { fg.getUserName(), fg.getEmail() }, new int[] { Types.VARCHAR, Types.VARCHAR, },
					Integer.class);
		} catch (DataAccessException ex) {
			logger.info(ex);
			deptid = null;
		} catch (Exception e) {
			logger.info(e);
			deptid = null;
		}

		if (deptid != null) {
			return true;
		} else {
			return false;
		}
	}

	public boolean sendPasswordRecoveryEmail(ForgetPassword forgetpassword) {
		JdbcTemplate update = jdbcTemplate(getTenantName());

		try {
			update.update("update  public.asa_registration set is_active=false where username=?",
					new Object[] { forgetpassword.getUserName() });
			return true;
		} catch (Exception e) {
			logger.info(e);
			return false;

		}

	}

	public boolean UpdateRecoverPassword(String userName, String encode) {
		JdbcTemplate update = jdbcTemplate(getTenantName());

		logger.info("Updating password for userName : " + userName);
		try {
			update.update(
					"UPDATE public.users SET  passwd=?,is_fp_active=null,fp_request_timestamp=null,fp_token=null WHERE username=?",
					new Object[] { encode, userName });
			return true;
		} catch (Exception e) {
			logger.info(e);
			return true;
		}

	}

	public List<ResendActivationList> getActivationReSendList() {

		JdbcTemplate select = jdbcTemplate(getTenantName());
		try {
			return select.query(
					"select d.dept_id,d.dept_name,u.username,d.cd_email from dept_registration d, users u,user_roles ur  "
							+ "where d.dept_id=u.dept_id and d.email_verification_timestamp is null and u.username=ur.username and ur.role_id!='1'",
					new RowMapper<ResendActivationList>() {

						public ResendActivationList mapRow(ResultSet rs, int arg1) throws SQLException {
							ResendActivationList obj = new ResendActivationList();
							obj.setDeptName(rs.getString("dept_name"));
							obj.setEmailId(rs.getString("cd_email"));
							obj.setId(rs.getInt("dept_id"));
							obj.setUserName(rs.getString("username"));
							return obj;
						}
					});
		}

		catch (DataAccessException ex) {
			logger.info(ex);
			return null;

		} catch (Exception e) {
			logger.info(e);
			return null;
		}

	}

	public List<AboutToExpireLK> getAboutToExpireLK() {

		JdbcTemplate select = jdbcTemplate(getTenantName());
		String frequency = "";
		String maxdays = "";
		try {
			frequency = select.queryForObject(
					"SELECT para_value FROM public.m_config_para where para_name='lk_expiry_email_frequency';",
					String.class);
			maxdays = select.queryForObject(
					"SELECT para_value FROM public.m_config_para where para_name='lk_expiry_email_start_period';",
					String.class);
		} catch (DataAccessException ex) {
			logger.info(ex);
			frequency = "5";
			maxdays = "30";
		} catch (Exception e) {
			logger.info(e);
			logger.info("config para missing ");
			frequency = "5";
			maxdays = "30";
		}

		try {
			return select.query(
					"SELECT m.para_value,lk.dept_id as id,lk.ac,users.cd_email as dept_email,users.dept_name as dept_name ,lk.valid_till,lk.client_license_key as lkey,lk.license_type as lk_type,lk.is_active, lk.is_krdh_activated  FROM public.license_keys as lk,public.asa_registration as users,public.m_config_para as m where lk.valid_till > CURRENT_DATE and DATE_PART('day', lk.valid_till::timestamp - CURRENT_DATE ::timestamp) < ? and mod(CAST(DATE_PART('day', lk.valid_till::timestamp - CURRENT_DATE ::timestamp) as INTEGER),?)=0 and lk.dept_id=users.dept_id and lk.is_active='true' and m.para_name='deployment_environment' order by id",
					new Object[] { Integer.parseInt(maxdays), Integer.parseInt(frequency) },
					new RowMapper<AboutToExpireLK>() {

						public AboutToExpireLK mapRow(ResultSet rs, int arg1) throws SQLException {
							ResultSetMetaData metaData = rs.getMetaData();
							int count = metaData.getColumnCount();
							AboutToExpireLK obj = new AboutToExpireLK();
							obj.setDeptName(rs.getString("dept_name"));
							obj.setEmail(rs.getString("dept_email"));
							obj.setLicenceKey(rs.getString("lkey"));
							obj.setValidTill(rs.getString("valid_till"));
							obj.setId(rs.getInt("id"));
							obj.setLk_type(rs.getString("lk_type"));
							obj.setAc(rs.getString("ac"));
							obj.setEnvironment(rs.getString("para_value"));
							return obj;
						}
					});
		} catch (DataAccessException ex) {
			logger.info(ex);
			return null;

		} catch (Exception e) {
			logger.info(e);
			return null;
		}
	}

	public List<AboutToExpireCertificate> getAboutToExpireCertificates() {

		JdbcTemplate select = jdbcTemplate(getTenantName());
		String frequency = "";
		String maxdays = "";
		try {
			frequency = select.queryForObject(
					"SELECT para_value FROM public.m_config_para where para_name='cert_expiry_email_frequency';",
					String.class);
			maxdays = select.queryForObject(
					"SELECT para_value FROM public.m_config_para where para_name='cert_exp_email_start_period';",
					String.class);
		} catch (DataAccessException ex) {
			logger.info(ex);
			frequency = "5";
			maxdays = "45";
		} catch (Exception e) {
			logger.info(e);
			logger.info("config para missing ");
		}
		try {

			return select.query(
					"SELECT  m.para_value, cert.dept_id as id,cert.ac,users.cd_email as dept_email,users.dept_name as dept_name ,cert.cert_expiry_date,cert.cert_identifier as cert_identifier,cert. cert_type as cert_type,cert.is_active FROM public.certificate_info as cert,public.asa_registration as users ,public.m_config_para as m where cert.cert_expiry_date > CURRENT_DATE and DATE_PART('day', cert.cert_expiry_date::timestamp - CURRENT_DATE ::timestamp) < ? and mod(CAST(DATE_PART('day', cert.cert_expiry_date::timestamp - CURRENT_DATE ::timestamp) as INTEGER),?)=0 and cert.dept_id=users.dept_id and cert.is_active='true' and m.para_name='deployment_environment' and cert. cert_type in ('sign','decrypt') order by id",
					new Object[] { Integer.parseInt(maxdays), Integer.parseInt(frequency) },
					new RowMapper<AboutToExpireCertificate>() {

						public AboutToExpireCertificate mapRow(ResultSet rs, int arg1) throws SQLException {
							ResultSetMetaData metaData = rs.getMetaData();
							int count = metaData.getColumnCount();
							AboutToExpireCertificate obj = new AboutToExpireCertificate();

							obj.setAc(rs.getString("ac"));
							obj.setCertIdentifier(rs.getString("cert_identifier"));
							obj.setCertificateType(rs.getString("cert_type"));
							obj.setValidTill(rs.getString("cert_expiry_date"));
							obj.setEmailId(rs.getString("dept_email"));
							obj.setDeptName(rs.getString("dept_name"));
							obj.setEnvironment(rs.getString("para_value"));

							return obj;
						}
					});
		}

		catch (DataAccessException ex) {
			logger.info(ex);
			return null;

		} catch (Exception e) {
			logger.info(e);
			return null;
		}
	}

	public boolean UpdateSignDetails(SigningDetails signdetails, String userName) {
		boolean decrypt_ekyc_at_asa = false;
		boolean decrypt_ekyc_at_aua = false;

		boolean is_soft_signing = false;
		boolean is_hard_signing = false;

		boolean is_sign_at_aua = false;
		boolean is_sign_at_asa = false;

		boolean is_hard_decryption = false;
		boolean is_soft_decryption = false;

		boolean is_soft_encryption = false;
		boolean is_hard_encryption = false;

		boolean is_asymetric_encrypt = false;
		boolean is_symetric_encrypt = false;

		boolean is_sign_ekyc_packet = signdetails.iseKycPacketSign();

		if (signdetails.getDecrypeKycDoneAt().equals(SignBy.ASA)) {
			decrypt_ekyc_at_asa = true;
		}
		if (signdetails.getDecrypeKycDoneAt().equals(SignBy.AUA)) {
			decrypt_ekyc_at_aua = true;
		}

		if (signdetails.getRequestSignDoneAt().equals(SignBy.ASA)) {
			is_sign_at_asa = true;
		}
		if (signdetails.getRequestSignDoneAt().equals(SignBy.AUA)) {
			is_sign_at_aua = true;
		}

		if (signdetails.getRequestSignType().equals(SigningType.HARD)) {
			is_hard_signing = true;
		}

		if (signdetails.getRequestSignType().equals(SigningType.SOFT)) {
			is_soft_signing = true;
		}
		if (signdetails.getDecrypType().equals(SigningType.SOFT)) {
			is_soft_decryption = true;
		}
		if (signdetails.getDecrypType().equals(SigningType.HARD)) {
			is_hard_decryption = true;
		}

		if (signdetails.getEncrypType().equals(SigningType.SOFT)) {
			is_soft_encryption = true;
		}
		if (signdetails.getEncrypType().equals(SigningType.HARD)) {
			is_hard_encryption = true;
		}
		if (signdetails.getSymencrypType().equals("asymetric")) {
			is_asymetric_encrypt = true;
		}
		if (signdetails.getSymencrypType().equals("symetric")) {
			is_symetric_encrypt = true;
		}

		JdbcTemplate update = jdbcTemplate(getTenantName());

		logger.info("Updating SIgning prefrence  for userName : " + userName);
		AcCode auaCode = null;
		boolean isRecordFound = true;
		try {
			// JdbcTemplate select = jdbcTemplate(getTenantName());
			auaCode = getAcCode(userName).get(0);
			int count = update.queryForObject("SELECT dept_id FROM public.sign_certificate_details where ac=?",
					new Object[] { signdetails.getAc() }, Integer.class);
//			System.out.println(count);
			isRecordFound = true;

		} catch (DataAccessException ex) {
			logger.info("insert query to be process");
			logger.info(ex);
			isRecordFound = false;
		}

		try {

			if (isRecordFound) {

				update.update(
						"UPDATE public.sign_certificate_details SET is_soft_signing=?, is_hard_signing=?,is_sign_at_aua=?, is_sign_at_asa=?,decrypt_ekyc_at_asa=?, decrypt_ekyc_at_aua=?,is_sign_ekyc_packet=?,is_hard_decryption=?, is_soft_decryption=?,is_soft_encryption=?, is_hard_encryption=?,is_asymetric_encrypt=?,is_symmetric_encrypt=? ,update_by=?, update_timestamp=now()  WHERE ac=?",
						new Object[] { is_soft_signing, is_hard_signing, is_sign_at_aua, is_sign_at_asa,
								decrypt_ekyc_at_asa, decrypt_ekyc_at_aua, is_sign_ekyc_packet, is_hard_decryption,
								is_soft_decryption, is_soft_encryption, is_hard_encryption, is_asymetric_encrypt,
								is_symetric_encrypt, userName, signdetails.getAc() });

			} else {
				int dept = getCurrentDeptIdFromAc(signdetails.getAc());
				update.update(
						"INSERT INTO public.sign_certificate_details(dept_id,ac ,is_soft_signing, is_hard_signing,is_sign_at_aua, is_sign_at_asa,decrypt_ekyc_at_asa, decrypt_ekyc_at_aua,is_sign_ekyc_packet,is_hard_decryption, is_soft_decryption,is_soft_encryption, is_hard_encryption,update_by, update_timestamp ,username,is_asymetric_encrypt,is_symmetric_encrypt)  VALUES (?, ?, ?,?, ?, ?,?, ?, ?,?,?, ?, ?,?, now(), ?,?,?)",
						new Object[] { dept, signdetails.getAc(), is_soft_signing, is_hard_signing, is_sign_at_aua,
								is_sign_at_asa, decrypt_ekyc_at_asa, decrypt_ekyc_at_aua, is_sign_ekyc_packet,
								is_hard_decryption, is_soft_decryption, is_soft_encryption, is_hard_encryption,
								userName, userName, is_asymetric_encrypt, is_symetric_encrypt });

			}
			return true;
		} catch (Exception e) {
			logger.info(e);
			return true;
		}
	}

	public int getCurrentDeptIdFromAc(String ac) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		int deptId = select.queryForObject("SELECT dept_id FROM public.asa_registration where ac=?",
				new Object[] { ac }, Integer.class);
		return deptId;
	}

	public List<DetailedTransaction> getDetailedTransaction(Integer role, String type, String userName) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		String whereClause1 = " ";
		String whereClause2 = " ";
		if (type.equals("demoauth"))
			whereClause1 = " and trans.table_name='auth_log' and trans.transaction_type='AUTH-DEMO'";
		if (type.equals("demootp"))
			whereClause1 = " and trans.table_name='auth_log' and trans.transaction_type='OTP'";
		if (type.equals("demofinger"))
			whereClause1 = " and trans.table_name='auth_log' and trans.transaction_type='BIO-FINGERPRINT'";
		if (type.equals("demoiris"))
			whereClause1 = " and trans.table_name='auth_log' and trans.transaction_type='BIO-IRIS'";
		if (type.equals("kycotp"))
			whereClause1 = " and trans.table_name='kyc_log' and trans.transaction_type='OTP'";
		if (type.equals("kycfinger"))
			whereClause1 = " and trans.table_name='kyc_log' and trans.transaction_type='BIO-FINGERPRINT'";
		if (type.equals("kyciris"))
			whereClause1 = " and trans.table_name='kyc_log' and trans.transaction_type='BIO-IRIS'";
		if (type.equals("otpotp"))
			whereClause1 = " and trans.table_name='otp_log' and trans.transaction_type='OTP-OTP'";

		if (role == 1)
			whereClause2 = " and trans.dept_id=" + getCurrentDeptId(userName);
		try {
			return select.query(
					"select usr.dept_name, trans.dept_id, sum(trans.trans_count) as count,trans.ret_status,trans.resp_status,trans.table_name,trans.transaction_type FROM public.trans_stats as trans, public.asa_registration as usr where usr.dept_id=trans.dept_id and  trans.resp_status='PASS' "
							+ whereClause1 + whereClause2
							+ " group by usr.dept_name,trans.ret_status,trans.dept_id,trans.resp_status,trans.table_name,trans.transaction_type order by usr.dept_name",
					new ResultSetExtractor<List<DetailedTransaction>>() {

						public List<DetailedTransaction> extractData(ResultSet rs)
								throws SQLException, DataAccessException {
							List<DetailedTransaction> list = new ArrayList<DetailedTransaction>();
							DetailedTransaction dt = new DetailedTransaction();
							dt.setFailureCount(0);
							dt.setSuccessCount(0);
							dt.setTotalCount(0);
							String currentDept = null;

							while (rs.next()) {

								if (currentDept == null) {
									currentDept = rs.getString("dept_name");
									dt.setDeptName(rs.getString("dept_name"));
								}
								if (!currentDept.equals(rs.getString("dept_name"))) {
									dt.setTotalCount(dt.getFailureCount() + dt.getSuccessCount());
									currentDept = rs.getString("dept_name");
									list.add(dt);
									dt = new DetailedTransaction();
									dt.setDeptName(currentDept);
									dt.setFailureCount(0);
									dt.setSuccessCount(0);
									dt.setTotalCount(0);
								}

								if (rs.getString("ret_status").equals("y") || rs.getString("ret_status").equals("Y"))
									dt.setSuccessCount(dt.getSuccessCount() + rs.getInt("count"));

								if (rs.getString("ret_status").equals("n") || rs.getString("ret_status").equals("N"))
									dt.setFailureCount(dt.getFailureCount() + rs.getInt("count"));

							}
							dt.setTotalCount(dt.getFailureCount() + dt.getSuccessCount());
							list.add(dt);

							return list;
						}
					});
		} catch (DataAccessException ex) {
			logger.info(ex);
			return null;

		} catch (Exception e) {
			logger.info(e);
			return null;
		}

	}

	public List<SigningDetails> getSignPrefrence(String userName, final String ac) {

		JdbcTemplate select = jdbcTemplate(getTenantName());
		List<SigningDetails> sd = new ArrayList<SigningDetails>();
		try {

			sd = select.query(
					"SELECT is_soft_signing, is_hard_signing, is_sign_at_aua, is_sign_at_asa,  decrypt_ekyc_at_asa, decrypt_ekyc_at_aua, is_sign_ekyc_packet,is_hard_decryption, is_soft_decryption, is_soft_encryption, is_hard_encryption ,is_asymetric_encrypt,is_symmetric_encrypt FROM public.sign_certificate_details where lower(ac)=?;",
					new Object[] { ac.toLowerCase() }, new RowMapper<SigningDetails>() {

						public SigningDetails mapRow(ResultSet rs, int arg1) throws SQLException {
							// ResultSetMetaData metaData = rs.getMetaData();
							// int count = metaData.getColumnCount();
							SigningDetails obj = new SigningDetails();

							if (rs.getBoolean("is_soft_signing"))
								obj.setRequestSignType(SigningType.SOFT);
							if (rs.getBoolean("is_hard_signing"))
								obj.setRequestSignType(SigningType.HARD);

							if (rs.getBoolean("is_sign_at_aua"))
								obj.setRequestSignDoneAt(SignBy.AUA);
							if (rs.getBoolean("is_sign_at_asa"))
								obj.setRequestSignDoneAt(SignBy.ASA);

							if (rs.getBoolean("decrypt_ekyc_at_asa"))
								obj.setDecrypeKycDoneAt(SignBy.ASA);
							if (rs.getBoolean("decrypt_ekyc_at_aua"))
								obj.setDecrypeKycDoneAt(SignBy.AUA);

							if (rs.getBoolean("is_asymetric_encrypt"))
								obj.setSymencrypType("asymetric");
							if (rs.getBoolean("is_symmetric_encrypt"))
								obj.setSymencrypType("symetric");

							obj.seteKycPacketSign(rs.getBoolean("is_sign_ekyc_packet"));

							if (rs.getBoolean("is_hard_decryption"))
								obj.setDecrypType(SigningType.HARD);
							if (rs.getBoolean("is_soft_decryption"))
								obj.setDecrypType(SigningType.SOFT);
							if (rs.getBoolean("is_hard_encryption"))
								obj.setEncrypType(SigningType.HARD);
							if (rs.getBoolean("is_soft_encryption"))
								obj.setEncrypType(SigningType.SOFT);

							obj.setAc(ac);
							obj.setDeptName(getCurrentDeptNameFromAc(ac));

							return obj;
						}
					});
		}

		catch (DataAccessException ex) {
			logger.info(ex);
			return null;

		} catch (Exception e) {
			logger.info(e);
			return null;
		}

		return sd;
	}

	protected String getCurrentDeptNameFromAc(String ac) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		String deptName = null;
		try {
			deptName = select.queryForObject("SELECT dept_name FROM public.asa_registration where ac= ?",
					new Object[] { ac }, String.class);
		}

		catch (DataAccessException ex) {
			logger.info(ex);

			return null;

		} catch (Exception e) {
			logger.info(e);
			return null;
		}

		return deptName;
	}

	public List<ErrorCodeCount> getTotalErrorTrans(Integer role, String userName) {

		JdbcTemplate select = jdbcTemplate(getTenantName());
		String whereClause = " ";
		if (role == 1) {
			whereClause = " and dept_id=" + getCurrentDeptId(userName);
		}
		try {
			return select.query(
					"SELECT error_code,sum(trans_count) as count,err_desc  FROM public.trans_stats LEFT JOIN public.m_err_info ON error_code=err_code where resp_status='PASS' and (ret_status='N' or ret_status='n')   "
							+ whereClause + " group by error_code,err_desc ;",
					new RowMapper<ErrorCodeCount>() {

						public ErrorCodeCount mapRow(ResultSet rs, int arg1) throws SQLException {

							ErrorCodeCount ercount = new ErrorCodeCount();
							ercount.setErrorCode(rs.getString("error_code"));
							ercount.setCount(rs.getInt("count"));
							if (rs.getString("err_desc") != null)
								ercount.setErrorDescription(rs.getString("err_desc"));
							else
								ercount.setErrorDescription("Error code description not avaiable in API document");
							return ercount;
						}
					});
		} catch (DataAccessException ex) {
			logger.info(ex);
			return null;
		} catch (Exception e) {
			logger.info(e);
			return null;
		}
	}

	public List<DetailedTransaction> getDetailedErrorTransaction(String errorCode, String userName, Integer role) {

		JdbcTemplate select = jdbcTemplate(getTenantName());
		String whereClause = " ";
		if (role == 1) {
			whereClause = " and t.dept_id= " + getCurrentDeptId(userName);
		}
		try {
			return select.query(
					"SELECT t.dept_id,lower(t.error_code) as error_codep ,u.dept_name,sum(t.trans_count) as count,e.err_desc FROM public.asa_registration u,public.trans_stats as t LEFT JOIN m_err_info e ON lower(t.error_code)=lower(e.err_code) where t.error_code =? and t.dept_id=u.dept_id and resp_status='PASS'  "
							+ whereClause
							+ " group by t.dept_id,t.error_code,u.dept_name,e.err_desc order by u.dept_name",
					new Object[] { errorCode }, new RowMapper<DetailedTransaction>() {
						public DetailedTransaction mapRow(ResultSet rs, int arg1) throws SQLException {
							DetailedTransaction count = new DetailedTransaction();
							count.setDeptName(rs.getString("dept_name"));
							count.setErrorCode(rs.getString("error_codep"));
							count.setTotalCount(rs.getInt("count"));
							if (rs.getString("err_desc") != null)
								count.setErrorDescription(rs.getString("err_desc"));
							else
								count.setErrorDescription("Error code description not available in API document");

							return count;
						}
					});
		} catch (DataAccessException ex) {
			logger.info(ex);
			return null;
		} catch (Exception e) {
			logger.info(e);
			return null;
		}
	}

	public Map<String, Integer> getTotalTransactionHomePage(String userName) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		String whereClause = " ";
		/*
		 * if (role == 1) { whereClause = "and dept_id=" + getCurrentDeptId(userName); }
		 */
		return select.query(
				/*
				 * "SELECT  sum(trans_count),transaction_type FROM public.trans_stats where resp_status='PASS' "
				 * + whereClause +
				 * " group by transaction_type,table_name order by table_name, transaction_type;"
				 * ,
				 */

				"SELECT  sum(txn_count),opr FROM public.trans_stats " + " group by opr order by  opr;",
				new ResultSetExtractor<Map<String, Integer>>() {
					public Map<String, Integer> extractData(ResultSet rs) throws SQLException, DataAccessException {
						Map<String, Integer> map = new HashMap<String, Integer>();
						map.put("struid", 0);
						map.put("getuid", 0);
						map.put("getrefnum", 0);
						map.put("activate", 0);
						map.put("deactivate", 0);
						while (rs.next()) {

							if (rs.getString("opr").equals("struid")) {
								map.put("struid", rs.getInt("sum"));
							}

							if (rs.getString("opr").equals("getuid")) {
								map.put("getuid", rs.getInt("sum"));
							}
							if (rs.getString("opr").equals("getrefnum")) {
								map.put("getrefnum", rs.getInt("sum"));
							}

							if (rs.getString("opr").equals("activate")) {
								map.put("activate", rs.getInt("sum"));
							}
							if (rs.getString("opr").equals("deactivate")) {
								map.put("deactivate", rs.getInt("sum"));
							}
						}
						logger.info("hometranspage::" + map.toString());
						return map;
					}
				});
	}

	public Map<String, Integer> acwiseTotaltrans(String acCode) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		String whereClause = " ";
		/*
		 * if (role == 1) { whereClause = "and dept_id=" + getCurrentDeptId(userName); }
		 */
		return select.query(
				/*
				 * "SELECT  sum(trans_count),transaction_type FROM public.trans_stats where resp_status='PASS' "
				 * + whereClause +
				 * " group by transaction_type,table_name order by table_name, transaction_type;"
				 * ,
				 */

				// "SELECT sum(txn_count),opr FROM public.trans_stats " + " group by opr order
				// by opr;",
				"SELECT  sum(txn_count),opr FROM public.trans_stats where ac=? and status in ('y', 'n')group by opr order by  opr;",
				new Object[] { acCode }, new ResultSetExtractor<Map<String, Integer>>() {
					public Map<String, Integer> extractData(ResultSet rs) throws SQLException, DataAccessException {
						Map<String, Integer> map = new HashMap<String, Integer>();
						map.put("struid", 0);
						map.put("getuid", 0);
						map.put("getrefnum", 0);
						map.put("activate", 0);
						map.put("deactivate", 0);
						while (rs.next()) {

							if (rs.getString("opr").equals("struid")) {
								map.put("struid", rs.getInt("sum"));
							}

							if (rs.getString("opr").equals("getuid")) {
								map.put("getuid", rs.getInt("sum"));
							}
							if (rs.getString("opr").equals("getrefnum")) {
								map.put("getrefnum", rs.getInt("sum"));
							}

							if (rs.getString("opr").equals("activate")) {
								map.put("activate", rs.getInt("sum"));
							}
							if (rs.getString("opr").equals("deactivate")) {
								map.put("deactivate", rs.getInt("sum"));
							}
						}
						logger.info("AC wise total count::" + map.toString());
						return map;
					}
				});
	}

	public Map<String, Integer> acWiseYesTrans(String acCode) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		String whereClause = " ";
		/*
		 * if (role == 1) { whereClause = "and dept_id=" + getCurrentDeptId(userName); }
		 */
		return select.query(
				/*
				 * "SELECT  sum(trans_count),transaction_type FROM public.trans_stats where resp_status='PASS' "
				 * + whereClause +
				 * " group by transaction_type,table_name order by table_name, transaction_type;"
				 * ,
				 */

				"SELECT  sum(txn_count),opr FROM public.trans_stats where ac=? and status='y' group by opr order by  opr;",
				new Object[] { acCode }, new ResultSetExtractor<Map<String, Integer>>() {
					public Map<String, Integer> extractData(ResultSet rs) throws SQLException, DataAccessException {
						Map<String, Integer> map = new HashMap<String, Integer>();
						map.put("struid", 0);
						map.put("getuid", 0);
						map.put("getrefnum", 0);
						map.put("activate", 0);
						map.put("deactivate", 0);
						while (rs.next()) {

							if (rs.getString("opr").equals("struid")) {
								map.put("struid", rs.getInt("sum"));
							}

							if (rs.getString("opr").equals("getuid")) {
								map.put("getuid", rs.getInt("sum"));
							}
							if (rs.getString("opr").equals("getrefnum")) {
								map.put("getrefnum", rs.getInt("sum"));
							}

							if (rs.getString("opr").equals("activate")) {
								map.put("activate", rs.getInt("sum"));
							}
							if (rs.getString("opr").equals("deactivate")) {
								map.put("deactivate", rs.getInt("sum"));
							}
						}
						logger.info("AC wise Success Count::" + map.toString());
						return map;
					}
				});
	}

	public int getTotalErrorCount(String userName) {
		String whereClause = " ";
		/*
		 * if (roles.get(0) == 1) { whereClause = " and dept_id=" +
		 * getCurrentDeptId(userName); }
		 */
		int count = 0;
		try {
			JdbcTemplate select = jdbcTemplate(getTenantName());
			count = select.queryForObject(
					/*
					 * "SELECT sum(trans_count) FROM public.trans_stats where  resp_status='PASS' and (ret_status='N' or ret_status='n')"
					 * + whereClause + ";",
					 */

					"SELECT sum(txn_count) FROM public.trans_stats where  status='n'",
					// + whereClause + ";",
					Integer.class);

		} catch (DataAccessException ex) {
			logger.info(ex);
			return 0;
		} catch (Exception e) {
			logger.info(e);
			count = 0;

		}
		return count;
	}

	public String getConnectorDowloadFilePath() {

		JdbcTemplate select = jdbcTemplate(getTenantName());
		String filePath = null;
		try {
			filePath = select.queryForObject(
					"SELECT para_value FROM public.m_config_para where para_name='integration_kit_path';",
					String.class);
		} catch (DataAccessException ex) {
			logger.info(ex);
			logger.info("File path Entry not in database , setting default value  ");
			filePath = "/home/iocladmin/aua_connector";
		} catch (Exception e) {
			logger.info("defalult path is been set " + e);
			filePath = "/home/iocladmin/aua_connector";
		}

		return filePath;

	}

	public int getHomePageSuccessCount(String userName) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		int count = 0;

		/*
		 * String whereClause = " "; if (role == 1) { //whereClause = "and dept_id=" +
		 * getCurrentDeptId(userName); }
		 */
		try {
			count = select.queryForObject(
					/*
					 * "select sum(trans_count) FROM public.trans_stats  where  (ret_status='y' or ret_status='Y') and resp_status='PASS'"
					 * + whereClause,
					 */
					"select sum(txn_count) FROM public.trans_stats where status='y'",

					Integer.class);
		} catch (DataAccessException ex) {
			logger.info(ex);
			count = 0;
		} catch (Exception e) {
			logger.info(e);
			count = 0;
		}

		return count;
	}

	// ac count dept wise

	public int getTotalAcCountDeptWise(String userName) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		int count = 0;

		/*
		 * String whereClause = " "; if (role == 1) { //whereClause = "and dept_id=" +
		 * getCurrentDeptId(userName); }
		 */
		String selectQuery = " select count(app_code) as total_ac from application_details where";
		String where = " dept_code in (select dept_code from dept_details where  username = " + "'" + userName + "'"
				+ ")";
		try {
			count = select.queryForObject(
					/*
					 * "select sum(trans_count) FROM public.trans_stats  where  (ret_status='y' or ret_status='Y') and resp_status='PASS'"
					 * + whereClause,
					 */
					selectQuery + where,

					Integer.class);
		} catch (DataAccessException ex) {
			logger.info(ex);
			count = 0;
		} catch (Exception e) {
			logger.info(e);
			count = 0;
		}

		return count;
	}

	public Map<String, Integer> getTotaldeshDeptCouont(String userName) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		int count = 0;
		try {
			return select.query("select count(dept_code) as count from dept_details;",
					new ResultSetExtractor<Map<String, Integer>>() {
						public Map<String, Integer> extractData(ResultSet rs) throws SQLException, DataAccessException {
							Map<String, Integer> map = new HashMap<String, Integer>();
							while (rs.next()) {
								map.put("totalDept", rs.getInt("count"));
							}
							return map;
						}
					});
		} catch (Exception e) {

			e.printStackTrace();
		}
		return null;
	}

	public int getTransactionDetail(String userName) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		int count = 0;

		/*
		 * String whereClause = " "; if (role == 1) { //whereClause = "and dept_id=" +
		 * getCurrentDeptId(userName); }
		 */
		try {
			count = select.queryForObject(
					/*
					 * "select sum(trans_count) FROM public.trans_stats  where  (ret_status='y' or ret_status='Y') and resp_status='PASS'"
					 * + whereClause,
					 */
					"select sum(txn_count) FROM public.trans_stats where status='y'",

					Integer.class);
		} catch (DataAccessException ex) {
			logger.info(ex);
			count = 0;
		} catch (Exception e) {
			logger.info(e);
			count = 0;
		}

		return count;
	}

	public List<TransactionDetailReport> getTransactionDetailReportCount(String userName, String transactiontype,
			String responsetype, int records, String fromDate, String toDate) {

		String schemaName = getSchemaNameFromUserName(userName);
		String transcationTable = " ";
		String responseTypeClause = " ";
		String whereClause = " ";
		String recordLimit = "limit " + records + ";";
		if (transactiontype.equals("otp")) {
			transcationTable = "otp_log";
			if (responsetype.equals("success"))
				responseTypeClause = " and lower(ret)='y' ";
			if (responsetype.equals("failure"))
				responseTypeClause = " and lower(ret)='n' ";
			whereClause = "resp_code is not null";
		}
		if (transactiontype.equals("demoauth")) {
			transcationTable = "auth_log";
			if (responsetype.equals("success"))
				responseTypeClause = " and lower(ret)='y' ";
			if (responsetype.equals("failure"))
				responseTypeClause = " and lower(ret)='n' ";
			whereClause = "res_code  is not null and( lower(pi)='y' or lower(pa)='y' or lower(pfa)='y') ";
		}
		if (transactiontype.equals("demootp")) {
			transcationTable = "auth_log ";
			if (responsetype.equals("success"))
				responseTypeClause = " and lower(ret)='y' ";
			if (responsetype.equals("failure"))
				responseTypeClause = " and lower(ret)='n' ";
			whereClause = "res_code is not null and lower(otp)='y' ";
		}
		if (transactiontype.equals("demobio")) {
			transcationTable = "auth_log";
			if (responsetype.equals("success"))
				responseTypeClause = " and lower(ret)='y' ";
			if (responsetype.equals("failure"))
				responseTypeClause = " and lower(ret)='n' ";
			whereClause = "res_code is not null and lower(bio)='y'";
		}
		if (transactiontype.equals("kycbio")) {
			transcationTable = "kyc_log";
			if (responsetype.equals("success"))
				responseTypeClause = " and lower(ret)='y' ";
			if (responsetype.equals("failure"))
				responseTypeClause = " and lower(ret)='n' ";
			whereClause = "code is not null and lower(bio)='y'";
		}
		if (transactiontype.equals("kycotp")) {
			transcationTable = "kyc_log";
			if (responsetype.equals("success"))
				responseTypeClause = " and lower(ret)='y' ";
			if (responsetype.equals("failure"))
				responseTypeClause = " and lower(ret)='n' ";
			whereClause = "code is not null and lower(otp)='y'";
		}

		if (transactiontype.equals("bfd")) {
			transcationTable = "bfd_log";
			if (responsetype.equals("success"))
				responseTypeClause = " and lower(ret)='y' ";
			if (responsetype.equals("failure"))
				responseTypeClause = " and lower(ret)='n' ";
			whereClause = "res_code is not null";
		}

		JdbcTemplate select = jdbcTemplate(getTenantName());
		try {
			return select.query(
					"SELECT txn,request_receipt_time,err,type,ac,ver,ret FROM " + schemaName + "." + transcationTable
							+ " where  " + whereClause + responseTypeClause
							+ " and  request_receipt_time::date >= to_date('" + fromDate
							+ "' ,'DD-MM-YYYY') and request_receipt_time::date <= to_date('" + toDate
							+ "' ,'DD-MM-YYYY') order by request_receipt_time desc " + recordLimit,
					new RowMapper<TransactionDetailReport>() {

						public TransactionDetailReport mapRow(ResultSet rs, int arg1) throws SQLException {

							TransactionDetailReport obj = new TransactionDetailReport();
							obj.setTimestamp(rs.getString("request_receipt_time"));
							obj.setTxn(rs.getString("txn"));
							obj.setRet(rs.getString("ret"));
							obj.setVer(rs.getString("ver"));
							obj.setType(rs.getString("type"));
							obj.setAc(rs.getString("ac"));
							if (StringUtils.isEmpty(rs.getString("err"))) {
								obj.setErrorCode("");
							} else
								obj.setErrorCode(rs.getString("err"));

							return obj;
						}
					});
		} catch (DataAccessException ex) {
			logger.info(ex);
			return null;

		} catch (Exception e) {
			logger.info(e);
			return null;
		}

	}

	private String getSchemaNameFromUserName(String userName) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		String schemaName = "";

		try {
			schemaName = select.queryForObject("SELECT schema_name FROM public.asa_registration where username=?",
					new Object[] { userName }, String.class);
		} catch (DataAccessException ex) {
			logger.info(ex);
		} catch (Exception e) {
			logger.info(e);
		}

		return schemaName;
	}

	public List<TransactionDetailReport> getTransactionDetail(String userName, String txn, String type) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		String schemaName = getSchemaNameFromUserName(userName);
		String transcationTable = "";
		String sqlquery = "";
		if (type.equals("auth")) {
			transcationTable = "auth_log";
			sqlquery = "SELECT txn as txn,res_code as respcode,ret,err,request_receipt_time as requestreceipttime ,response_forward_time as requestforwardtime,sa,actn FROM "
					+ transcationTable + " where txn=?  order by request_receipt_time desc";
		}
		if (type.equals("kyc")) {
			transcationTable = "kyc_log";
			sqlquery = "SELECT txn as txn,code as respcode,ret,err,request_receipt_time as requestreceipttime ,response_forward_time as requestforwardtime,sa,actn,auth_actn,kyc_err,auth_err FROM "
					+ transcationTable + " where txn=?  order by request_receipt_time desc";
		}
		if (type.equals("otp")) {
			transcationTable = "otp_log";
			sqlquery = "SELECT txn as txn,resp_code as respcode,ret,err,request_receipt_time as requestreceipttime ,response_forward_time as requestforwardtime,sa FROM "
					+ transcationTable + " where txn=?  order by request_receipt_time desc";
		}
		if (type.equals("bfd")) {
			transcationTable = "bfd_log";
			sqlquery = "SELECT txn as txn,res_code as respcode,ret,err,request_receipt_time as requestreceipttime ,response_forward_time as requestforwardtime FROM "
					+ schemaName + "." + transcationTable + " where txn=?  order by request_receipt_time desc";
		}
		try {
			return select.query(sqlquery, new Object[] { txn }, new RowMapper<TransactionDetailReport>() {
				public TransactionDetailReport mapRow(ResultSet rs, int arg1) throws SQLException {
					TransactionDetailReport obj = new TransactionDetailReport();
					obj.setTxn(rs.getString("txn"));
					obj.setErrorCode(rs.getString("err"));
					obj.setRequestReceiptTime(rs.getString("requestreceipttime"));
					obj.setResponseReceiptTime(rs.getString("requestforwardtime"));
					obj.setRet(rs.getString("ret"));
					obj.setResponseCode(rs.getString("respcode"));
					obj.setSa(rs.getString("sa"));
					if (!type.equals("otp")) {
						obj.setActn(rs.getString("actn"));
					} else {
						obj.setActn("");
					}
					if (type.equalsIgnoreCase("kyc")) {
						obj.setAuth_actn(rs.getString("auth_actn"));
						obj.setKyc_err(rs.getString("kyc_err"));
						obj.setAuth_err(rs.getString("auth_err"));

					}
					return obj;
				}
			});
		} catch (DataAccessException ex) {
			logger.info(ex);
			return null;
		} catch (Exception e) {
			logger.info(e);
			return null;
		}
	}

	public boolean updateResetPasswordDetail(String userName, String randomUuid) {
		JdbcTemplate update = jdbcTemplate(getTenantName());
		try {
			update.update("UPDATE users SET  fp_request_timestamp=now(),fp_token=?,is_fp_active =true WHERE username=?",
					new Object[] { UUID.fromString(randomUuid), userName });
		} catch (Exception e) {
			logger.info(e);
			return false;
		}
		return true;
	}

	public boolean checkForPassworResetValidToken(String token, String userName) {
		int deptId = 0;

		try {
			JdbcTemplate select = jdbcTemplate(getTenantName());
			String days = getParaValueByParaName("fp_link_expiry");
			logger.info("days : " + days);
			deptId = select.queryForObject(
					"select dept_id from users where username=? and fp_token =? and DATE_PART('day', fp_request_timestamp::timestamp - CURRENT_DATE ::timestamp) <= '"
							+ days + "' and is_fp_active=true",
					new Object[] { userName, UUID.fromString(token) }, Integer.class);
		} catch (DataAccessException ex) {
			logger.info(ex);
			return false;
		} catch (Exception e) {
			logger.info(e);
			return false;
		}
		return true;
	}

	public String getAuaCodeFromEmail1(String email) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		try {
			String auaCode = select.queryForObject("SELECT ac FROM public.asa_registration where cd_email=?",
					new Object[] { email }, String.class);
			return auaCode;
		} catch (DataAccessException ex) {
			logger.info(ex);
			return null;
		} catch (Exception e) {
			logger.info(e);
			return null;
		}
	}

	public Map<String, String> getAuaCodeFromEmail(String email) {
		JdbcTemplate select = jdbcTemplate(getTenantName());

		long dept_id = select.queryForObject("SELECT dept_id FROM public.users where email=?", new Object[] { email },
				Long.class);
		try {
			return select.query("Select dept_name,ac from public.dept_registration where dept_id=?",
					new Object[] { dept_id }, new ResultSetExtractor<Map<String, String>>() {

						public Map<String, String> extractData(ResultSet rs) throws SQLException, DataAccessException {
							Map<String, String> map = new LinkedHashMap<String, String>();
							while (rs.next()) {
								map.put("ac", rs.getString("ac"));
								map.put("deptName", rs.getString("dept_name"));
							}
							return map;
						}
					});
		} catch (Exception e) {
			logger.info(e);
			return null;
		}
	}

	public Map<String, TransactionCountTotal> getHomePageTabelData(String userName) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		String whereClause = "";
		/*
		 * if (role == 1) { whereClause = "and  dept_id='" + getCurrentDeptId(userName)
		 * + "'"; }
		 */

		return select.query(
				"SELECT  sum(txn_count),opr ,UPPER(status) as status FROM public.trans_stats where status='y'"
						+ " group by opr,table_name,status order by  opr;",
				new ResultSetExtractor<Map<String, TransactionCountTotal>>() {
					public Map<String, TransactionCountTotal> extractData(ResultSet rs)
							throws SQLException, DataAccessException {
						Map<String, Integer> initMap = new HashMap<String, Integer>();
						initMap.put("success", 0);
						initMap.put("failure", 0);
						initMap.put("total", 0);
						Map<String, TransactionCountTotal> outerMap = new HashMap<String, TransactionCountTotal>();
						outerMap.put("demoauth", new TransactionCountTotal());
						outerMap.put("demootp", new TransactionCountTotal());
						outerMap.put("demofinger", new TransactionCountTotal());
						outerMap.put("demoiris", new TransactionCountTotal());
						outerMap.put("kycotp", new TransactionCountTotal());
						outerMap.put("kycfinger", new TransactionCountTotal());
						outerMap.put("kyciris", new TransactionCountTotal());
						outerMap.put("otpotp", new TransactionCountTotal());
						outerMap.put("bfd", new TransactionCountTotal());
						String currentType = "";
						String currentTableName = "";
						TransactionCountTotal obj = null;
						while (rs.next()) {

							if (currentType.equals("")) {
								obj = new TransactionCountTotal();
								currentType = rs.getString("transaction_type");
								currentTableName = rs.getString("table_name");

							}
							if (!(rs.getString("transaction_type").equals(currentType)
									&& rs.getString("table_name").equals(currentTableName))) {

								currentType = rs.getString("transaction_type");
								currentTableName = rs.getString("table_name");
								obj = new TransactionCountTotal();
							}

							if (rs.getString("table_name").equals("auth_log")
									&& rs.getString("transaction_type").equals("AUTH-DEMO")
									&& rs.getString("ret_status").equals("Y")) {
								obj.setSuccess(rs.getInt("sum"));
								outerMap.put("demoauth", obj);

							} else if (rs.getString("table_name").equals("auth_log")
									&& rs.getString("transaction_type").equals("AUTH-DEMO")
									&& rs.getString("ret_status").equals("N")) {
								obj.setFailure(rs.getInt("sum"));
								outerMap.put("demoauth", obj);
							} else if (rs.getString("table_name").equals("auth_log")
									&& rs.getString("transaction_type").equals("OTP")
									&& rs.getString("ret_status").equals("Y")) {
								obj.setSuccess(rs.getInt("sum"));
								outerMap.put("demootp", obj);
							} else if (rs.getString("table_name").equals("auth_log")
									&& rs.getString("transaction_type").equals("OTP")
									&& rs.getString("ret_status").equals("N")) {
								obj.setFailure(rs.getInt("sum"));
								outerMap.put("demootp", obj);
							} else if (rs.getString("table_name").equals("otp_log")
									&& rs.getString("transaction_type").equals("OTP-OTP")
									&& rs.getString("ret_status").equals("Y")) {
								obj.setSuccess(rs.getInt("sum"));
								outerMap.put("otpotp", obj);
							} else if (rs.getString("table_name").equals("otp_log")
									&& rs.getString("transaction_type").equals("OTP-OTP")
									&& rs.getString("ret_status").equals("N")) {
								obj.setFailure(rs.getInt("sum"));
								outerMap.put("otpotp", obj);
							} else if (rs.getString("table_name").equals("auth_log")
									&& rs.getString("transaction_type").equals("BIO-FINGERPRINT")
									&& rs.getString("ret_status").equals("Y")) {
								obj.setSuccess(rs.getInt("sum"));
								outerMap.put("demofinger", obj);
							} else if (rs.getString("table_name").equals("auth_log")
									&& rs.getString("transaction_type").equals("BIO-FINGERPRINT")
									&& rs.getString("ret_status").equals("N")) {
								obj.setFailure(rs.getInt("sum"));
								outerMap.put("demofinger", obj);
							} else if (rs.getString("table_name").equals("auth_log")
									&& rs.getString("transaction_type").equals("BIO-IRIS")
									&& rs.getString("ret_status").equals("Y")) {
								obj.setSuccess(rs.getInt("sum"));
								outerMap.put("demoiris", obj);
							} else if (rs.getString("table_name").equals("auth_log")
									&& rs.getString("transaction_type").equals("BIO-IRIS")
									&& rs.getString("ret_status").equals("N")) {
								obj.setFailure(rs.getInt("sum"));
								outerMap.put("demoiris", obj);
							} else if (rs.getString("table_name").equals("kyc_log")
									&& rs.getString("transaction_type").equals("OTP")
									&& rs.getString("ret_status").equals("Y")) {
								obj.setSuccess(rs.getInt("sum"));
								outerMap.put("kycotp", obj);
							} else if (rs.getString("table_name").equals("kyc_log")
									&& rs.getString("transaction_type").equals("OTP")
									&& rs.getString("ret_status").equals("N")) {
								obj.setFailure(rs.getInt("sum"));
								outerMap.put("kycotp", obj);
							} else if (rs.getString("table_name").equals("kyc_log")
									&& rs.getString("transaction_type").equals("BIO-FINGERPRINT")
									&& rs.getString("ret_status").equals("Y")) {
								obj.setSuccess(rs.getInt("sum"));
								outerMap.put("kycfinger", obj);
							} else if (rs.getString("table_name").equals("kyc_log")
									&& rs.getString("transaction_type").equals("BIO-FINGERPRINT")
									&& rs.getString("ret_status").equals("N")) {
								obj.setFailure(rs.getInt("sum"));
								outerMap.put("kycfinger", obj);
							} else if (rs.getString("table_name").equals("kyc_log")
									&& rs.getString("transaction_type").equals("BIO-IRIS")
									&& rs.getString("ret_status").equals("Y")) {
								obj.setSuccess(rs.getInt("sum"));
								outerMap.put("kyciris", obj);
							} else if (rs.getString("table_name").equals("kyc_log")
									&& rs.getString("transaction_type").equals("BIO-IRIS")
									&& rs.getString("ret_status").equals("N")) {
								obj.setFailure(rs.getInt("sum"));
								outerMap.put("kyciris", obj);
							} else if (rs.getString("table_name").equals("bfd_log")
									&& rs.getString("ret_status").equals("Y")) {
								obj.setSuccess(rs.getInt("sum"));
								outerMap.put("bfd", obj);
							} else if (rs.getString("table_name").equals("bfd_log")
									&& rs.getString("ret_status").equals("N")) {
								obj.setFailure(rs.getInt("sum"));
								outerMap.put("bfd", obj);
							}
						}
						return outerMap;
					}
				});
	}

	public Map<String, Integer> getSuccessCount(String userName) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		String whereClause = "";
		/*
		 * if (role == 1) { whereClause = "and t.dept_id=" + getCurrentDeptId(userName);
		 * }
		 */

		return select.query(
				/*
				 * "select u.dept_name,t.dept_id, t.table_name, sum(t.trans_count) as count from trans_stats t,users u where t.dept_id=u.dept_id and resp_status='PASS' and (t.ret_status='y' or t.ret_status='Y' ) "
				 * + whereClause +
				 * "  group by u.dept_name,t.dept_id, table_name order by dept_name;",
				 */

				"select  t.ac,t.opr,sum(t.txn_count) as count from trans_stats t where status='y' "
						+ "  group by t.ac,t.opr order by count;",
				// new AdminDeptCountResultSetExtractor());
				new ResultSetExtractor<Map<String, Integer>>() {
					public Map<String, Integer> extractData(ResultSet rs) throws SQLException, DataAccessException {
						Map<String, Integer> map = new HashMap<String, Integer>();
						map.put("struid", 0);
						map.put("getuid", 0);
						map.put("getrefnum", 0);
						map.put("activate", 0);
						map.put("deactivate", 0);
						while (rs.next()) {

							if (rs.getString("opr").equals("struid")) {
								map.put("struid", rs.getInt("count"));
							}

							if (rs.getString("opr").equals("getuid")) {
								map.put("getuid", rs.getInt("count"));
							}
							if (rs.getString("opr").equals("getrefnum")) {
								map.put("getrefnum", rs.getInt("count"));
							}

							if (rs.getString("opr").equals("activate")) {
								map.put("activate", rs.getInt("count"));
							}
							if (rs.getString("opr").equals("deactivate")) {
								map.put("deactivate", rs.getInt("count"));
							}
						}
						logger.info("getsuccesscount::" + map.toString());
						return map;
					}
				});
	}

	public Map<String, Integer> getFailureCount(String userName) {
		JdbcTemplate select = jdbcTemplate(getTenantName());

		String whereClause = "";
		/*
		 * if (role == 1) { whereClause = "and u.dept_id=" + getCurrentDeptId(userName);
		 * }
		 */

		return select.query(
				"select  t.ac,t.opr,sum(t.txn_count) as count from trans_stats t where status='n'  group by t.ac,t.opr order by count;",
				new ResultSetExtractor<Map<String, Integer>>() {
					public Map<String, Integer> extractData(ResultSet rs) throws SQLException, DataAccessException {
						Map<String, Integer> map = new HashMap<String, Integer>();
						map.put("struid", 0);
						map.put("getuid", 0);
						map.put("getrefnum", 0);
						map.put("activate", 0);
						map.put("deactivate", 0);
						while (rs.next()) {

							if (rs.getString("opr").equals("struid")) {
								map.put("struid", rs.getInt("count"));
							}

							if (rs.getString("opr").equals("getuid")) {
								map.put("getuid", rs.getInt("count"));
							}
							if (rs.getString("opr").equals("getrefnum")) {
								map.put("getrefnum", rs.getInt("count"));
							}

							if (rs.getString("opr").equals("activate")) {
								map.put("activate", rs.getInt("count"));
							}
							if (rs.getString("opr").equals("deactivate")) {
								map.put("deactivate", rs.getInt("count"));
							}
						}
						logger.info("getFailureCount::" + map.toString());
						return map;
					}
				});
	}

	public Map<String, Integer> acwiseNotrans(String acCode) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		try {
			return select.query(

					"SELECT  sum(txn_count) as count,opr FROM public.trans_stats where ac=? and status='n' group by opr order by  opr;",
					new Object[] { acCode }, new ResultSetExtractor<Map<String, Integer>>() {
						public Map<String, Integer> extractData(ResultSet rs) throws SQLException, DataAccessException {
							Map<String, Integer> map = new HashMap<String, Integer>();
							map.put("struid", 0);
							map.put("getuid", 0);
							map.put("getrefnum", 0);
							map.put("activate", 0);
							map.put("deactivate", 0);
							while (rs.next()) {

								if (rs.getString("opr").equals("struid")) {
									map.put("struid", rs.getInt("count"));
								}

								if (rs.getString("opr").equals("getuid")) {
									map.put("getuid", rs.getInt("count"));
								}
								if (rs.getString("opr").equals("getrefnum")) {
									map.put("getrefnum", rs.getInt("count"));
								}

								if (rs.getString("opr").equals("activate")) {
									map.put("activate", rs.getInt("count"));
								}
								if (rs.getString("opr").equals("deactivate")) {
									map.put("deactivate", rs.getInt("count"));
								}
							}
							logger.info(" AC wise failure count::" + map.toString());
							return map;
						}
					});
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	public List<AdminDeptCount> getTimeExecutionRecords(String fromDate, String toDate, Integer role, String deptId) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		String schemaName = getSchemaNameFromId(deptId);
		if (role == 1) {

		}
		return select.query("SELECT\r\n"
				+ "unnest(array[ 'zero_to_1' ,'one_to_2','two_to_5','five_to_10','ten_to_60','gt_than_60']) AS timep,\r\n"
				+ "unnest(array[sum(zero_to_1),sum(one_to_2),sum(two_to_5),sum(five_to_10),sum(ten_to_60),sum(gt_than_60)]) AS \"Count\", table_name\r\n"
				+ "FROM public.track_execution_time WHERE schema_name=? and txn_date::date >= to_date('" + fromDate
				+ "' ,'DD-MM-YYYY') and txn_date::date <= to_date('" + toDate
				+ "' ,'DD-MM-YYYY')  group by  table_name order by timep,table_name", new Object[] { schemaName },
				new ResultSetExtractor<List<AdminDeptCount>>() {
					public List<AdminDeptCount> extractData(ResultSet rs) throws SQLException, DataAccessException {
						List<AdminDeptCount> list = new ArrayList<AdminDeptCount>();
						AdminDeptCount obj = null;
						String currentRecord = "";

						while (rs.next()) {
							if (currentRecord.equals("")) {
								currentRecord = rs.getString("timep");
								obj = new AdminDeptCount();
							}
							if (!currentRecord.equals(rs.getString("timep"))) {

								list.add(obj);
								currentRecord = rs.getString("timep");
								obj = new AdminDeptCount();
							}

							if (rs.getString("timep").equals("zero_to_1")) {
								obj.setTimePeriod(" 0 sec  to 1 sec");
								/*
								 * obj.setDeptId(2); if (rs.getString("table_name").equals("auth_log")) {
								 * obj.setAuthCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("bfd_log")) {
								 * obj.setBfdCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("kyc_log")) {
								 * obj.setKycCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("otp_log")) {
								 * obj.setOtpCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("bfd_log")) {
								 * obj.setBfdCount(rs.getInt("count")); }
								 */
							}

							if (rs.getString("timep").equals("one_to_2")) {
								obj.setTimePeriod(" 1 sec to 2 sec");
								/*
								 * obj.setDeptId(3); if (rs.getString("table_name").equals("auth_log")) {
								 * obj.setAuthCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("bfd_log")) {
								 * obj.setBfdCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("kyc_log")) {
								 * obj.setKycCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("otp_log")) {
								 * obj.setOtpCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("bfd_log")) {
								 * obj.setBfdCount(rs.getInt("count")); }
								 */

							}

							if (rs.getString("timep").equals("two_to_5")) {
								obj.setTimePeriod(" 2 sec to 5 sec");
								/*
								 * obj.setDeptId(4); if (rs.getString("table_name").equals("auth_log")) {
								 * obj.setAuthCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("bfd_log")) {
								 * obj.setBfdCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("kyc_log")) {
								 * obj.setKycCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("otp_log")) {
								 * obj.setOtpCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("bfd_log")) {
								 * obj.setBfdCount(rs.getInt("count")); }
								 */

							}

							if (rs.getString("timep").equals("five_to_10")) {
								obj.setTimePeriod("5 sec to 10 sec");
								/*
								 * obj.setDeptId(5); if (rs.getString("table_name").equals("auth_log")) {
								 * obj.setAuthCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("bfd_log")) {
								 * obj.setBfdCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("kyc_log")) {
								 * obj.setKycCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("otp_log")) {
								 * obj.setOtpCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("bfd_log")) {
								 * obj.setBfdCount(rs.getInt("count")); }
								 */

							}

							if (rs.getString("timep").equals("ten_to_60")) {
								obj.setTimePeriod(" 10 sec to 1 min");
								/*
								 * obj.setDeptId(6); if (rs.getString("table_name").equals("auth_log")) {
								 * obj.setAuthCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("bfd_log")) {
								 * obj.setBfdCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("kyc_log")) {
								 * obj.setKycCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("otp_log")) {
								 * obj.setOtpCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("bfd_log")) {
								 * obj.setBfdCount(rs.getInt("count")); }
								 */

							}

							if (rs.getString("timep").equals("gt_than_60")) {
								obj.setTimePeriod("Greater than 1 min");
								/*
								 * obj.setDeptId(7); if (rs.getString("table_name").equals("auth_log")) {
								 * obj.setAuthCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("bfd_log")) {
								 * obj.setBfdCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("kyc_log")) {
								 * obj.setKycCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("otp_log")) {
								 * obj.setOtpCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("bfd_log")) {
								 * obj.setBfdCount(rs.getInt("count")); }
								 */

							}

						}
						list.add(obj);
						return list;
					}
				});

	}

	public List<AdminDeptCount> getFailureTimeExecutionRecords(String fromDate, String toDate, Integer role,
			String deptId) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		String schemaName = getSchemaNameFromId(deptId);

		if (role == 1) {

		}
		return select.query("SELECT\r\n"
				+ "unnest(array[ 'zero_to_1' ,'one_to_2','two_to_5','five_to_10','ten_to_60','gt_than_60']) AS timep,\r\n"
				+ "unnest(array[sum(zero_to_1),sum(one_to_2),sum(two_to_5),sum(five_to_10),sum(ten_to_60),sum(gt_than_60)]) AS \"Count\", table_name\r\n"
				+ "FROM public.track_execution_time_for_fail_trans WHERE schema_name=? and txn_date::date >= to_date('"
				+ fromDate + "' ,'DD-MM-YYYY') and txn_date::date <= to_date('" + toDate
				+ "' ,'DD-MM-YYYY')  group by  table_name order by timep,table_name", new Object[] { schemaName },
				new ResultSetExtractor<List<AdminDeptCount>>() {
					public List<AdminDeptCount> extractData(ResultSet rs) throws SQLException, DataAccessException {

						List<AdminDeptCount> list = new ArrayList<AdminDeptCount>();

						AdminDeptCount obj = null;

						String currentRecord = "";

						while (rs.next()) {
							if (currentRecord.equals("")) {
								currentRecord = rs.getString("timep");
								obj = new AdminDeptCount();
							}
							if (!currentRecord.equals(rs.getString("timep"))) {

								list.add(obj);
								currentRecord = rs.getString("timep");
								obj = new AdminDeptCount();
							}

							if (rs.getString("timep").equals("zero_to_1")) {
								obj.setTimePeriod(" 0 sec  to 1 sec");
								/*
								 * obj.setDeptId(2); if (rs.getString("table_name").equals("auth_log")) {
								 * obj.setAuthCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("bfd_log")) {
								 * obj.setBfdCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("kyc_log")) {
								 * obj.setKycCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("otp_log")) {
								 * obj.setOtpCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("bfd_log")) {
								 * obj.setBfdCount(rs.getInt("count")); }
								 */

							}

							if (rs.getString("timep").equals("one_to_2")) {
								obj.setTimePeriod(" 1 sec to 2 sec");
								/*
								 * obj.setDeptId(3); if (rs.getString("table_name").equals("auth_log")) {
								 * obj.setAuthCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("bfd_log")) {
								 * obj.setBfdCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("kyc_log")) {
								 * obj.setKycCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("otp_log")) {
								 * obj.setOtpCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("bfd_log")) {
								 * obj.setBfdCount(rs.getInt("count")); }
								 */

							}

							if (rs.getString("timep").equals("two_to_5")) {
								obj.setTimePeriod(" 2 sec to 5 sec");
								/*
								 * obj.setDeptId(4); if (rs.getString("table_name").equals("auth_log")) {
								 * obj.setAuthCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("bfd_log")) {
								 * obj.setBfdCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("kyc_log")) {
								 * obj.setKycCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("otp_log")) {
								 * obj.setOtpCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("bfd_log")) {
								 * obj.setBfdCount(rs.getInt("count")); }
								 */

							}

							if (rs.getString("timep").equals("five_to_10")) {
								obj.setTimePeriod("5 sec to 10 sec");
								/*
								 * obj.setDeptId(5); if (rs.getString("table_name").equals("auth_log")) {
								 * obj.setAuthCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("bfd_log")) {
								 * obj.setBfdCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("kyc_log")) {
								 * obj.setKycCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("otp_log")) {
								 * obj.setOtpCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("bfd_log")) {
								 * obj.setBfdCount(rs.getInt("count")); }
								 */

							}

							if (rs.getString("timep").equals("ten_to_60")) {
								obj.setTimePeriod(" 10 sec to 1 min");
								/*
								 * obj.setDeptId(6); if (rs.getString("table_name").equals("auth_log")) {
								 * obj.setAuthCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("bfd_log")) {
								 * obj.setBfdCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("kyc_log")) {
								 * obj.setKycCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("otp_log")) {
								 * obj.setOtpCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("bfd_log")) {
								 * obj.setBfdCount(rs.getInt("count")); }
								 */

							}

							if (rs.getString("timep").equals("gt_than_60")) {
								obj.setTimePeriod("Greater than 1 min");
								/*
								 * obj.setDeptId(7); if (rs.getString("table_name").equals("auth_log")) {
								 * obj.setAuthCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("bfd_log")) {
								 * obj.setBfdCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("kyc_log")) {
								 * obj.setKycCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("otp_log")) {
								 * obj.setOtpCount(rs.getInt("count")); } else if
								 * (rs.getString("table_name").equals("bfd_log")) {
								 * obj.setBfdCount(rs.getInt("count")); }
								 */

							}

						}
						list.add(obj);
						return list;
					}
				});

	}

	public List<AdminDeptCount> getFailureReportCount(String deptId, String fromDate, String toDate) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		/*
		 * return select.query(
		 * "SELECT error_code,table_name,sum(trans_count) as count,err_desc  FROM public.trans_stats LEFT JOIN public.m_err_info ON error_code=err_code  where resp_status='PASS' and (ret_status='n' or ret_status='N' )  and dept_id=? and txn_date::date >= to_date('"
		 * + fromDate + "' ,'DD-MM-YYYY') and txn_date::date <= to_date('" + toDate +
		 * "' ,'DD-MM-YYYY') group by error_code,table_name,err_desc order by error_code ;"
		 * , new Object[] { Integer.parseInt(deptId) }, new
		 * ResultSetExtractor<List<AdminDeptCount>>() {
		 * 
		 * public List<AdminDeptCount> extractData(ResultSet rs) throws SQLException,
		 * DataAccessException { List<AdminDeptCount> list = new
		 * ArrayList<AdminDeptCount>();
		 * 
		 * AdminDeptCount obj = new AdminDeptCount(); String errorCode = ""; while
		 * (rs.next()) { if (errorCode.equals("")) { errorCode =
		 * rs.getString("error_code"); obj.setErrorCode(errorCode); } if
		 * (!rs.getString("error_code").equals(errorCode)) {
		 * obj.setTotal(obj.getAuthCount() + obj.getKycCount() + obj.getBfdCount());
		 * list.add(obj);
		 * 
		 * obj = new AdminDeptCount(); errorCode = rs.getString("error_code");
		 * obj.setErrorCode(errorCode); }
		 * 
		 * if (rs.getString("table_name").equals("otp_log")) {
		 * obj.setOtpCount(rs.getInt("count")); } else if
		 * (rs.getString("table_name").equals("auth_log")) {
		 * obj.setAuthCount(rs.getInt("count")); } else if
		 * (rs.getString("table_name").equals("kyc_log")) {
		 * obj.setKycCount(rs.getInt("count")); } else if
		 * (rs.getString("table_name").equals("bfd_log")) {
		 * obj.setBfdCount(rs.getInt("count")); }
		 * 
		 * } obj.setTotal(obj.getAuthCount() + obj.getKycCount() + obj.getBfdCount());
		 * list.add(obj); return list; } }});
		 */
		return null;
	}

	public String getDeptNameFromId(String deptId) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		String deptName = "";

		try {
			deptName = select.queryForObject("select dept_name from public.asa_registration where dept_id=?",
					new Object[] { Integer.parseInt(deptId) }, String.class);

		} catch (Exception e) {
			logger.info(e);
			return "Department";
		}
		return deptName;
	}

	public String getSchemaNameFromId(String deptId) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		String schemaName = "";
		try {
			schemaName = select.queryForObject("select schema_name from public.asa_registration where dept_id=?",
					new Object[] { Integer.parseInt(deptId) }, String.class);
		} catch (Exception e) {
			logger.info(e);
			return "null";
		}
		return schemaName;
	}

	public String getAcFromId(String deptId) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		String acCode = "";
		try {
			acCode = select.queryForObject("select ac from public.asa_registration where dept_id=?",
					new Object[] { Integer.parseInt(deptId) }, String.class);
		} catch (Exception e) {
			logger.info(e);
			return "AC";
		}
		return acCode;
	}

	public String getFraudDetectionTimeSchedule() {
		return "* * * * * ?";
	}

	public List<FraudDetectionObject> getDetectedFraudTransaction() {

		JdbcTemplate select = jdbcTemplate(getTenantName());
		return select.query(
				"SELECT fd.ac,fd.udc,fd.trans_count,fd.txn_date,fd.table_name,fd.start_time,fd.end_time,u.dept_name, u.cd_email  FROM public.fraud_detection fd,public.asa_registration u where fd.ac=u.ac and fd.is_email_sent=false and  fd.is_fraud=true group by fd.ac,fd.trans_count,fd.table_name,fd.start_time,fd.end_time,u.dept_name, u.cd_email,fd.txn_date,fd.udc order by fd.ac ,fd.txn_date",
				new RowMapper<FraudDetectionObject>() {

					public FraudDetectionObject mapRow(ResultSet rs, int arg1) throws SQLException {
						FraudDetectionObject obj = new FraudDetectionObject();
						obj.setAc(rs.getString("ac"));
						obj.setCount(rs.getInt("trans_count"));
						obj.setDeptName(rs.getString("dept_name"));
						obj.setTransDate(rs.getString("txn_date"));
						obj.setEmail(rs.getString("cd_email"));

						if (rs.getString("table_name").equals("otp_log"))
							obj.setType("OTP");
						else if (rs.getString("table_name").equals("auth_log"))
							obj.setType("AUTH");

						else if (rs.getString("table_name").equals("kyc_log"))
							obj.setType("KYC");
						else if (rs.getString("table_name").equals("bfd_log"))
							obj.setType("BFD");

						obj.setStartTime(rs.getString("start_time"));
						obj.setEndTime(rs.getString("end_time"));

						if (rs.getString("udc") != null) {
							obj.setUdc(rs.getString("udc"));
						} else {
							obj.setUdc("N/A");
						}

						return obj;
					}
				});

	}

	public void updateFraudDetectionEmailSent(FraudDetectionObject obj) {
		JdbcTemplate update = jdbcTemplate(getTenantName());

		update.update(
				"UPDATE public.fraud_detection SET is_email_sent=true  WHERE ac=? and  trans_count = ? and  txn_date=to_date(?,'YYYY-MM-DD')",
				new Object[] { obj.getAc(), obj.getCount(), obj.getTransDate() });

	}

	public String getPortalUrl() {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		String url = "";

		url = select.queryForObject("select para_value from public.m_config_para where para_name='portal_url'",
				String.class);

		return url.trim();
	}

	public String getParaValueByParaName(String para_name) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		String url = "";

		url = select.queryForObject("select para_value from public.m_config_para where para_name=? ",
				new Object[] { para_name }, String.class);

		return url.trim();
	}

	public void uploadCertificate(String userName, MultipartFile[] cert, String certIdentifier, String certpath,
			String certalias, String certpass, String type, String validTill) throws DataAccessException, IOException {
		JdbcTemplate update = jdbcTemplate(getTenantName());
		String deptId = getCurrentDeptId(userName);
		AcCode ac = getAcCode(userName).get(0);

		boolean record_exist = getCertificateRecord(ac.getAcCode(), type);
		update.update(
				"UPDATE public.certificate_info SET is_active=false, update_by=?, update_timestamp=now() WHERE ac=? and cert_type=?::cert_types",
				new Object[] { userName, ac.getAcCode(), type });

		update.update(
				"INSERT INTO public.certificate_info(dept_id, ac, username, cert_identifier, cert_key, cert_path,cert_alias, cert_password, cert_expiry_date, cert_type, is_active,update_by, update_timestamp) VALUES (?, ?, ?, ?, ?, ?,?, ?,to_date(?,'dd-mm-yyyy')::date,?::cert_types, true,?, now());",
				new Object[] { deptId, ac.getAcCode(), userName, certIdentifier, cert[0].getBytes(), certpath,
						certalias, certpass, validTill, type, userName });

	}

	private boolean getCertificateRecord(String acCode, String type) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		String ac = "";

		try {
			ac = select.queryForObject(
					"select ac from public.certificate_info where ac=? and cert_type=?::cert_types and is_active=true",
					new Object[] { acCode, Cert_types.valueOf(type) }, String.class);

		} catch (DataAccessException ex) {
			logger.info(ex);
			return false;
		} catch (Exception e) {
			logger.info(e);
			return true;
		}
		return true;
	}

	public List<CertificateDetails> getCerticateDetails(String userName) {
		JdbcTemplate select = jdbcTemplate(getTenantName());

		logger.info("UserName::" + userName);

		return select.query(
				"SELECT cert_identifier,cert_expiry_date, cert_type  FROM public.certificate_info where is_active=true and username='"
						+ userName + "'",
				new RowMapper<CertificateDetails>() {
					public CertificateDetails mapRow(ResultSet rs, int arg1) throws SQLException {
						CertificateDetails certDetails = new CertificateDetails();

						certDetails.setCertificateIdentifier(rs.getString("cert_identifier"));
						certDetails.setValidTill(rs.getString("cert_expiry_date"));
						certDetails.setType(rs.getString("cert_type"));
						return certDetails;
					}
				});
	}

	public List<AcCode> getAcList() {
		JdbcTemplate select = jdbcTemplate(getTenantName());

		return select.query("SELECT dept_name, ac  FROM public.dept_registration;", new RowMapper<AcCode>() {
			// new Object[] { userName },
			public AcCode mapRow(ResultSet rs, int arg1) throws SQLException {
				AcCode obj = new AcCode();
				obj.setAcCode(rs.getString("ac"));
				obj.setDeptName(rs.getString("dept_name"));
				return obj;
			}
		});
	}

	public String getDeptNameFromAc(String ac) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		String deptName = "";

		deptName = select.queryForObject("select dept_name from public.asa_registration where ac='" + ac + "'",
				String.class);

		return deptName.trim();
	}

	public String getCcEmailId(String to) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		String emailId = "";
		long deptId;
		try {

			deptId = select.queryForObject("SELECT dept_id FROM public.users where email=?", new Object[] { to },
					Long.class);

			emailId = select.queryForObject("SELECT ca_email FROM public.dept_registration where dept_id=?",
					new Object[] { deptId }, String.class);
			return emailId;
		} catch (Exception e) {
			logger.info(e);
			return null;
		}
	}

	public List<SuccessCount> getSuccessCount1(String userName) {

		JdbcTemplate select = jdbcTemplate(getTenantName());
		String whereClause = "";
		/*
		 * if (role == 1) { whereClause = "and t.dept_id=" + getCurrentDeptId(userName);
		 * }
		 */

		return select.query(
				/*
				 * "select u.dept_name,t.dept_id, t.table_name, sum(t.trans_count) as count,t.transaction_type \r\n"
				 * +
				 * "from trans_stats t,users u where t.dept_id=u.dept_id and resp_status='PASS' and (t.ret_status='y' or t.ret_status='Y' )  "
				 * + whereClause +
				 * " group by u.dept_name,t.dept_id, table_name,transaction_type order by dept_name;"
				 * ,
				 */

				"select u.app_name, sum(t.txn_count) as count,t.opr \r\n"
						+ "from trans_stats t,application_details u where t.ac=u.app_code  and (t.status='y' or t.status='Y' )  "
						+ whereClause + " group by u.app_name,opr order by app_name;",
				new ResultSetExtractor<List<SuccessCount>>() {

					public List<SuccessCount> extractData(ResultSet rs) throws SQLException, DataAccessException {
						List<SuccessCount> list = new ArrayList<SuccessCount>();
						SuccessCount obj = null;
						String currentType = "";
						// String currentTableName = "";
						String currentDept = "";

						while (rs.next()) {
							if (currentType.equals("")) {
								obj = new SuccessCount();
								currentType = rs.getString("opr");
								// currentTableName = rs.getString("table_name");
								currentDept = rs.getString("app_name");
								obj.setAppName(currentDept);

							}

							if (!currentDept.equals(rs.getString("app_name"))) {

								obj.setTotal(obj.getStrUidCount() + obj.getGetUidCount() + obj.getGetRefNumCount()
										+ obj.getActivateCount() + obj.getDeactivateCount());
								list.add(obj);

								obj = new SuccessCount();
								currentDept = rs.getString("app_name");
								obj.setAppName(currentDept);
								// obj.setDeptId(rs.getInt("dept_id"));

							}

							if (rs.getString("opr").equals("getuid")) {
								obj.setGetUidCount(rs.getInt("count"));
							} else if (rs.getString("opr").equals("struid")) {
								obj.setStrUidCount(rs.getInt("count"));

							} else if (rs.getString("opr").equals("getrefnum")) {

								obj.setGetRefNumCount(rs.getInt("count"));
							} else if (rs.getString("opr").equals("activate")) {

								obj.setActivateCount(rs.getInt("count"));
							} else if (rs.getString("opr").equals("deactivate")) {

								obj.setDeactivateCount(rs.getInt("count"));
							}
						}
						obj.setTotal(obj.getStrUidCount() + obj.getGetUidCount() + obj.getGetRefNumCount()
								+ obj.getActivateCount() + obj.getDeactivateCount());
						list.add(obj);
						logger.info("sucess list::" + list.toString());
						return list;
					}
				});
	}

	public List<SuccessCount> getFailureCountNew(String userName, Integer role) {

		JdbcTemplate select = jdbcTemplate(getTenantName());
		String whereClause = "";
		if (role == 1) {
			whereClause = "and t.dept_id=" + getCurrentDeptId(userName);
		}

		return select.query(
				"select u.dept_name,t.dept_id, t.table_name, sum(t.trans_count) as count,t.transaction_type \r\n"
						+ "from trans_stats t,users u where t.dept_id=u.dept_id and resp_status='PASS' and (t.ret_status='n' or t.ret_status='N' )  "
						+ whereClause
						+ " group by u.dept_name,t.dept_id, table_name,transaction_type order by dept_name;",
				new ResultSetExtractor<List<SuccessCount>>() {

					public List<SuccessCount> extractData(ResultSet rs) throws SQLException, DataAccessException {
						List<SuccessCount> list = new ArrayList<SuccessCount>();
						SuccessCount obj = null;
						String currentType = "";
						String currentTableName = "";
						String currentDept = "";

						/*
						 * while (rs.next()) {
						 * 
						 * if (currentType.equals("")) { obj = new SuccessCount(); currentType =
						 * rs.getString("transaction_type"); currentTableName =
						 * rs.getString("table_name"); currentDept = rs.getString("dept_name");
						 * obj.setAppName(currentDept); obj.setDeptId(rs.getInt("dept_id")); }
						 * 
						 * if (!currentDept.equals(rs.getString("dept_name"))) {
						 * obj.setDemototal(obj.getDemototal() + obj.getDemoauth() + obj.getDemofinger()
						 * + obj.getDemoiris() + obj.getDemootp()); obj.setKyctotal( obj.getKyctotal() +
						 * obj.getKycfinger() + obj.getKyciris() + obj.getKycotp());
						 * obj.setTotal(obj.getDemototal() + obj.getKyctotal() + obj.getBfd());
						 * list.add(obj);
						 * 
						 * obj = new SuccessCount(); currentDept = rs.getString("dept_name");
						 * obj.setAppName(currentDept); obj.setDeptId(rs.getInt("dept_id"));
						 * 
						 * }
						 * 
						 * 
						 * if (rs.getString("table_name").equals("auth_log") &&
						 * rs.getString("transaction_type").equals("AUTH-DEMO")) {
						 * 
						 * obj.setDemoauth(rs.getInt("count"));
						 * 
						 * } else if (rs.getString("table_name").equals("auth_log") &&
						 * rs.getString("transaction_type").equals("OTP")) {
						 * obj.setDemootp(rs.getInt("count"));
						 * 
						 * }
						 * 
						 * else if (rs.getString("table_name").equals("auth_log") &&
						 * rs.getString("transaction_type").equals("BIO-FINGERPRINT")) {
						 * 
						 * obj.setDemofinger(rs.getInt("count")); } else if
						 * (rs.getString("table_name").equals("auth_log") &&
						 * rs.getString("transaction_type").equals("BIO-IRIS")) {
						 * 
						 * obj.setDemoiris(rs.getInt("count")); } else if
						 * (rs.getString("table_name").equals("kyc_log") &&
						 * rs.getString("transaction_type").equals("OTP")) {
						 * 
						 * obj.setKycotp(rs.getInt("count")); } else if
						 * (rs.getString("table_name").equals("kyc_log") &&
						 * rs.getString("transaction_type").equals("BIO-FINGERPRINT")) {
						 * 
						 * obj.setKycfinger(rs.getInt("count")); } else if
						 * (rs.getString("table_name").equals("kyc_log") &&
						 * rs.getString("transaction_type").equals("BIO-IRIS")) {
						 * 
						 * obj.setKyciris(rs.getInt("count")); } else if
						 * (rs.getString("table_name").equals("bfd_log")) {
						 * 
						 * obj.setBfd(rs.getInt("count")); } } obj.setDemototal(obj.getDemototal() +
						 * obj.getDemoauth() + obj.getDemofinger() + obj.getDemoiris() +
						 * obj.getDemootp()); obj.setKyctotal(obj.getKyctotal() + obj.getKycfinger() +
						 * obj.getKyciris() + obj.getKycotp()); obj.setTotal(obj.getDemototal() +
						 * obj.getKyctotal() + obj.getBfd());
						 */
						list.add(obj);
						return list;
					}
				});

	}

	@Override
	public List<String> getActivityListByUsername(String username, String tenant) {
		JdbcTemplate select = jdbcTemplate(tenant);
		logger.info("username " + username);
		List<String> activityList = new ArrayList<String>();
		return select.query(
				"select a.activity from activities a join role_activities ra on a.activity_id = ra.activity_id join  user_roles ur on ra.role_id = ur.role_id  where ur.username = ?; ",
				new Object[] { username }, new RowMapper<String>() {

					public String mapRow(ResultSet rs, int arg1) throws SQLException {
						return rs.getString(1);
					}
				});
	}

	public List<String> getUsernameList(long dept_id) {
		JdbcTemplate select = jdbcTemplate(getTenantName());
		logger.info("dept_id " + dept_id);
		return select.query("select username from public.users  where dept_id = ? ", new Object[] { dept_id },
				new RowMapper<String>() {

					public String mapRow(ResultSet rs, int arg1) throws SQLException {
						return rs.getString(1);
					}
				});
	}

	public String getSACodeFromUsername(String username) {
		JdbcTemplate ds = jdbcTemplate(getTenantName());
		String sa_code = ds.queryForObject(
				"select sa_code from dept_registration a, users b where a.dept_id=b.dept_id and username=?",
				new Object[] { username }, String.class);
		logger.info("sa_code::" + sa_code);
		return sa_code;

	}

	
	private String getTenantName() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String tenantName = null;
		if (auth != null && !auth.getClass().equals(AnonymousAuthenticationToken.class)) {
			// User user = (User) auth.getPrincipal();
			CustomeUserDetails userDetails = (CustomeUserDetails) auth.getPrincipal();
			tenantName = userDetails.getTenant();
		}
		return tenantName;
	}

	private String getPrincipal() {
		String userName = null;
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

		if (principal instanceof UserDetails) {
			userName = ((UserDetails) principal).getUsername();
		} else {
			userName = principal.toString();
		}
		return userName;
	}

	@Override
	public String deptRegistrationR(DeptDetails deptdetails) {
		// TODO Auto-generated method stub
		JdbcTemplate update = jdbcTemplate("test");

//		insert into dept_details (dept_name,address,contact_person,designation,email,mobile,phone,username,passwd,city,state_code,pincode) values ('demo1','demo1','demo1','demo1','demo1@gmail.com','1234567891','1234556781','demo1','demo1','demo1','10','400044');

		String dept_name = deptdetails.getDept_name();
		String address = deptdetails.getAddress();
		String contact_person = deptdetails.getContact_person();
		String designation = deptdetails.getDesignation();
		String email = deptdetails.getEmail();
		String mobile = deptdetails.getMobile();
		String phone = deptdetails.getPhone();
		String username = deptdetails.getUsername();
		String passwd = deptdetails.getPasswd();
		String city = deptdetails.getCity();
		String state_code = deptdetails.getState_code();
		String pincode = deptdetails.getPincode();

		String url = "insert into dept_details (dept_name,address,contact_person,designation,email,mobile,phone,username,passwd,city,state_code,pincode) values ('"
				+ dept_name + "','" + address + "','" + contact_person + "','" + designation + "','" + email + "','"
				+ mobile + "','" + phone + "','" + username + "','" + passwd + "','" + city + "','" + state_code + "','"
				+ pincode + "');";

		System.out.println(url);
//		System.out.println(struid + " " + appcode);
		try {
			update.update(url);

		} catch (Exception e) {
			throw new RuntimeException();
		}
		return "successfully dept created";

	}

//	@Override
//	public List<OprList> getOprList() {
//		// TODO Auto-generated method stub
//		JdbcTemplate update = jdbcTemplate("test");
//		
////		String url="select * from m_crypto_opr";
////		int count = 0;
//		return select.query("select * from m_crypto_opr;",
//				new ResultSetExtractor<List<OprList>>() {
//					public List<OprList> extractData(ResultSet rs) throws SQLException, DataAccessException {
////						Map<String, String> map = new HashMap<String, String>();
//						List<OprList> opr = new ArrayList<>();
//						while (rs.next()) {
//							OprList oprlist=new OprList();
//							oprlist.setOpr_id(rs.getInt("opr_id"));
//							oprlist.setOpr_code(rs.getString("opr_code"));
//							oprlist.setOpr_type(rs.getString("opr_type"));
//							
//							opr.add(oprlist);
//					
//							
////							StateList state = new StateList();
////							state.setStateCode(rs.getString("codes"));
////							state.setStateName(rs.getString("statenames"));
////							states.add(state);
////							map.put(rs.getString("codes"), rs.getString("statenames"));
//						}
//						return opr;
//					}
//				});
//	}

	@Override
	public List<OprList> getOprList() {

		JdbcTemplate select = jdbcTemplate("test");
//		int count = 0;
		return select.query("select opr_id,opr_code,opr_type from m_crypto_opr;",
				new ResultSetExtractor<List<OprList>>() {
					public List<OprList> extractData(ResultSet rs) throws SQLException, DataAccessException {
						List<OprList> opr = new ArrayList<>();
						while (rs.next()) {
							OprList oprlist = new OprList();
							oprlist.setOpr_id(rs.getInt("opr_id"));
							oprlist.setOpr_code(rs.getString("opr_code"));
							oprlist.setOpr_type(rs.getString("opr_type"));

							opr.add(oprlist);

						}
						return opr;
					}
				});
	}

	@Override
	public List<Algo_Info> getAlgoIdList() {
		// TODO Auto-generated method stub
		JdbcTemplate select = jdbcTemplate("test");
		return select.query("select algo_id,algo from algo_info;", new ResultSetExtractor<List<Algo_Info>>() {
			public List<Algo_Info> extractData(ResultSet rs) throws SQLException, DataAccessException {
				List<Algo_Info> algoid = new ArrayList<>();
				while (rs.next()) {
					Algo_Info algolist = new Algo_Info();
					algolist.setAlgo_id(rs.getInt("algo_id"));
					algolist.setAlgo(rs.getString("algo"));

					algoid.add(algolist);
				}
				return algoid;
			}
		});
	}

	@Override
	public List<Slot> getSlotList() {
		// TODO Auto-generated method stub
		JdbcTemplate select = jdbcTemplate("test");
		return select.query("select slot,passwd from hsm_info;", new ResultSetExtractor<List<Slot>>() {
			public List<Slot> extractData(ResultSet rs) throws SQLException, DataAccessException {
				List<Slot> slotlist = new ArrayList<>();
				while (rs.next()) {
					Slot slot = new Slot();
					slot.setSlot(rs.getString("slot"));
					slot.setPasswd(rs.getString("passwd"));
					slotlist.add(slot);
				}
				return slotlist;
			}
		});
	}

	@Override
	public List<KeyInfo> getKeyId() {
		// TODO Auto-generated method stub
		JdbcTemplate select = jdbcTemplate("test");
		return select.query("select key_info_id from key_info;", new ResultSetExtractor<List<KeyInfo>>() {
			public List<KeyInfo> extractData(ResultSet rs) throws SQLException, DataAccessException {
				List<KeyInfo> keyidlist = new ArrayList<>();
				while (rs.next()) {
					KeyInfo keyid = new KeyInfo();
					keyid.setKey_info_id(rs.getInt("key_info_id"));
					keyidlist.add(keyid);
				}
				return keyidlist;
			}
		});

	}

	@Override
	public KeyInfo getKeyinfo(int key_info_id) {
		// TODO Auto-generated method stub
		JdbcTemplate select = jdbcTemplate("test");
		return select.query(
				" select a.algo,o.opr_type,ki.key_info_id,ki.hash_key_id,ki.slot,ki.key_label,ki.key,ki.key_expiry_date,ki.key_is_active,ki.is_default,ki.tkn_type,ki.dept_code  from key_info as ki inner join algo_info a on ki.algo_id= a.algo_id inner join m_crypto_opr o on o.opr_code=ki.opr  where key_info_id='"
						+ key_info_id + "';",
				new ResultSetExtractor<KeyInfo>() {
					public KeyInfo extractData(ResultSet rs) throws SQLException, DataAccessException {
//						List<KeyInfo> keyinfo  = new ArrayList<>();
						KeyInfo keyinfo = new KeyInfo();
						while (rs.next()) {

							keyinfo.setKey_info_id(rs.getInt("key_info_id"));
//							keyinfo.setOpr(rs.getString("opr"));
							keyinfo.setOpr_type(rs.getString("opr_type"));
//							keyinfo.setAlgo_id(rs.getInt("algo_id"));
							keyinfo.setAlgo(rs.getString("algo"));
							keyinfo.setHash_key_id(rs.getString("hash_key_id"));
							keyinfo.setSlot(rs.getString("slot"));
							keyinfo.setKey_label(rs.getString("key_label"));
							keyinfo.setKey(rs.getString("key"));
							keyinfo.setKey_expiry_date_display(rs.getDate("key_expiry_date"));
							keyinfo.setKey_is_active(rs.getBoolean("key_is_active"));
							keyinfo.setIs_default(rs.getBoolean("is_default"));
							keyinfo.setTkn_type(rs.getString("tkn_type"));
							keyinfo.setDept_code(rs.getString("dept_code"));
						}
						return keyinfo;
					}
				});

	}

	@Override
	public DeptList getDeptnamewithDeptcode(String deptcode) {
		// TODO Auto-generated method stub
		JdbcTemplate select = jdbcTemplate("test");
		return select.query("select dept_name ,dept_code from dept_details where dept_code='" + deptcode + "';",
				new ResultSetExtractor<DeptList>() {
					public DeptList extractData(ResultSet rs) throws SQLException, DataAccessException {
//						List<KeyInfo> keyidlist  = new ArrayList<>();
						DeptList deptname = new DeptList();

						while (rs.next()) {

							deptname.setDept_name(rs.getString("dept_name"));
							deptname.setDept_code(rs.getString("dept_code"));

						}
						return deptname;
					}
				});
	}

	@Override
	public String keyMappingInsert(KeyMapping keymap) {
		// TODO Auto-generated method stub
		JdbcTemplate update = jdbcTemplate("test");
		String appcode = keymap.getappcode();
		String deptcode = keymap.getdeptcode();
		int keyinfoid = keymap.getkeyinfoid();
//		System.out.println(appcreate + " " + deptcode);
		String url = "insert into key_mapping (app_code,key_info_id,dept_code) values ('" + appcode + "','" + keyinfoid
				+ "','" + deptcode + "');";

//		System.out.println(struid + " " + appcode);
		try {
			update.update(url);

		} catch (Exception e) {
			throw new RuntimeException();
		}
		return "successfully key mapping created";

	}

	// for hash key id generation

	public static byte[] getSHA(String input) throws NoSuchAlgorithmException {
		// Static getInstance method is called with hashing SHA
		MessageDigest md = MessageDigest.getInstance("SHA-256");

		// digest() method called
		// to calculate message digest of an input
		// and return array of byte
		return md.digest(input.getBytes(StandardCharsets.UTF_8));
	}

	public static String toHexString(byte[] hash) {
		// Convert byte array into signum representation
		BigInteger number = new BigInteger(1, hash);

		// Convert message digest into hex value
		StringBuilder hexString = new StringBuilder(number.toString(16));

		// Pad with leading zeros
		while (hexString.length() < 64) {
			hexString.insert(0, '0');
		}

		return hexString.toString();
	}

	@Override
	public String keyInfoInsert(KeyInfo keyinfo, String deptcode) {
		// TODO Auto-generated method stub
		JdbcTemplate update = jdbcTemplate("test");
		String opr = keyinfo.getOpr();
		int algoid = keyinfo.getAlgo_id();
		String keylabel = keyinfo.getKey_label();
		String hashkeyid = "";
		// for hash key id generation

		try {
			hashkeyid = toHexString(getSHA(keylabel));
		} catch (NoSuchAlgorithmException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		//////////////////////////////////////////

		String slot = keyinfo.getSlot();

//		String key = keyinfo.getKey();
		String keyexpirydate = keyinfo.getkey_expiry_date();

		Timestamp timestampkeyexpirydate = Timestamp.valueOf(keyexpirydate);
		Boolean keyisactive = keyinfo.isKey_is_active();
		Boolean isdefault = keyinfo.isIs_default();
		String tkntype = keyinfo.getTkn_type();
//		String deptcode=keyinfo.getDept_code();
//		String appcode = keymap.getappcode();
//		String deptcode = keymap.getdeptcode();
//		int keyinfoid = keymap.getkeyinfoid();
//		System.out.println(appcreate + " " + deptcode);

//		Timestamp.valueOf("2018-09-01 09:01:16");  
		String url = " insert into key_info(opr,algo_id,hash_key_id,slot,key_label,key,key_expiry_date,key_is_active,is_default,tkn_type,dept_code) values ('"
				+ opr + "','" + algoid + "','" + hashkeyid + "','" + slot + "','" + keylabel + "','" + "','"
				+ timestampkeyexpirydate + "','" + keyisactive + "','" + isdefault + "','" + tkntype + "','" + deptcode
				+ "');";

		System.out.println(url);

//		System.out.println(struid + " " + appcode);
		try {
			update.update(url);

		} catch (Exception e) {
			throw new RuntimeException();
		}
		return "successfully key mapping created";

	}

	@Override
	public long getDataForChart(String date ,String userName) {
		JdbcTemplate select = jdbcTemplate("test");
		return select.query(
//						"select ac,scheme_code,status,err,is_exist_ref_num,sum(txn_count) as txn,date from trans_stats where date ='"+ date +"' group by date,ac,scheme_code,status,err,is_exist_ref_num;",
//				"select txn_count from trans_stats where date='" + date + "' ;",
				"SELECT  sum(t.txn_count) as txn_count  from dept_details  as d inner join application_details as a on d.dept_code=a.dept_code left join trans_stats as t  on a.app_code=t.ac where d.username='"+userName+"' and t.date='"+date+"' ;",

				new ResultSetExtractor<Long>() {
					public Long extractData(ResultSet rs) throws SQLException, DataAccessException {
						int txncnt = 0;
						while (rs.next()) {
							if(rs.getString("txn_count")!=null)
							txncnt = txncnt + Integer.parseInt(rs.getString("txn_count"));
						}
						return (long) txncnt;
					}
				});
	}

	@Override
	public List<Activities> getActivity() {
		// TODO Auto-generated method stub
		JdbcTemplate select = jdbcTemplate("test");
		return select.query(
//				"select ac,scheme_code,status,err,is_exist_ref_num,sum(txn_count) as txn,date from trans_stats where date ='"+ date +"' group by date,ac,scheme_code,status,err,is_exist_ref_num;",
//		"select txn_count from trans_stats where date='" + date + "' ;",

				"select activity_id,activity from activities;", new ResultSetExtractor<List<Activities>>() {
					public List<Activities> extractData(ResultSet rs) throws SQLException, DataAccessException {
//				int txncnt = 0;
						List<Activities> actlist = new ArrayList<>();

						while (rs.next()) {
							Activities activity = new Activities();
//					txncnt = txncnt + Integer.parseInt(rs.getString("txn_count"));

							activity.setActivity_id(rs.getString("activity_id"));
							activity.setActivity(rs.getString("activity"));
							actlist.add(activity);
						}
//				return (long) txncnt;
						return actlist;
					}
				});

	}

	@Override
	public String getuserroleinsertR(UserRolesforUserManagement userrole) {
		// TODO Auto-generated method stub
		JdbcTemplate update = jdbcTemplate("test");
//		String appcode = us.getappcode();
//		String deptcode = keymap.getdeptcode();
//		int keyinfoid = keymap.getkeyinfoid();

		String roleid = userrole.getRole_id();
		String username = userrole.getUsername();
//		System.out.println(appcreate + " " + deptcode);
		String url = "insert into user_roles (username,role_id) values ('" + username + "','" + roleid + "');";

//		System.out.println(struid + " " + appcode);
		try {
			update.update(url);

		} catch (Exception e) {
			throw new RuntimeException();
		}
		return "successfully user role inserted";

	}

	@Override
	public String getroleactivityinsertR(RoleActivity roleact) {
		// TODO Auto-generated method stub
		JdbcTemplate update = jdbcTemplate("test");
		String roleid = roleact.getRole_id();
		String activityid = roleact.getActivity_id();

		String url = "insert into role_activities (role_id,activity_id) values ('" + roleid + "','" + activityid
				+ "');";
		try {
			update.update(url);

		} catch (Exception e) {
			throw new RuntimeException();
		}
		return "successfully role activities inserted";
	}

	@Override
	public String keyinfoinsertforsoft(KeyInfo keyinfo, String deptcode) {
		// TODO Auto-generated method stub
		JdbcTemplate update = jdbcTemplate("test");
		String opr = keyinfo.getOpr();
		int algoid = keyinfo.getAlgo_id();
		String keylabel = keyinfo.getKey_label();
		String hashkeyid = "";
		// for hash key id generation

		try {
			hashkeyid = toHexString(getSHA(keylabel));
		} catch (NoSuchAlgorithmException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		//////////////////////////////////////////

		String slot = keyinfo.getSlot();

//		String key = keyinfo.getKey();
		String keyexpirydate = keyinfo.getkey_expiry_date();

		Timestamp timestampkeyexpirydate = Timestamp.valueOf(keyexpirydate);
		Boolean keyisactive = keyinfo.isKey_is_active();
		Boolean isdefault = keyinfo.isIs_default();
		String tkntype = keyinfo.getTkn_type();
		String key=keyinfo.getKey();
//		System.out.println(key+" ------key");

//		String deptcode=keyinfo.getDept_code();
//		String appcode = keymap.getappcode();
//		String deptcode = keymap.getdeptcode();
//		int keyinfoid = keymap.getkeyinfoid();
//		System.out.println(appcreate + " " + deptcode);

//		Timestamp.valueOf("2018-09-01 09:01:16");  
		String url = " insert into key_info(opr,algo_id,hash_key_id,slot,key_label,key_expiry_date,key_is_active,is_default,tkn_type,key,dept_code) values ('"
				+ opr + "','" + algoid + "','" + hashkeyid + "','" + slot + "','" + keylabel + "','" 
				+ timestampkeyexpirydate + "','" + keyisactive + "','" + isdefault + "','" + tkntype + "','" +key+"','"+ deptcode
				+ "');";

		System.out.println(url);
	
//		System.out.println(struid + " " + appcode);
		try {
			update.update(url);

		} catch (Exception e) {
			throw new RuntimeException();
		}
		return "successfully key mapping created";

	}

	@Override
	public String getDeptcodeFromUsernameforreport(String username) {
		// TODO Auto-generated method stub
		try {
			
		
		JdbcTemplate select = jdbcTemplate("test");
		String url = "select dept_name,  dept_code from dept_details where username =" + "'" + username + "' ;";
		return select.query(url, new ResultSetExtractor<String>() {
			public String extractData(ResultSet rs) throws SQLException, DataAccessException {
				String deptcode="";
				while (rs.next()) {
					deptcode=rs.getString("dept_code")+","+rs.getString("dept_name");					
				}
				return deptcode;
			}
		});
		
		} catch (Exception e) {
			// TODO: handle exception
			return "";
		}
	}
	
	public ArrayList<Summary> getSummaryForJasperIgnite(String first, String last, String deptcode) {
		int currentQuarter = LocalDate.now().get(IsoFields.QUARTER_OF_YEAR);
		System.out.println("current QUARTER: " + currentQuarter);
		System.out.println("deptcode: " + deptcode);

		String[] blank = { "" };

		@SuppressWarnings("unused")
		String[] summaryColumn = { "  OPERATION", " ", "   COUNT" };
		ArrayList<Report> finalRepo = GetFileData.getAllOprSummaryForJasper(deptcode);

		
		Map<String, Summary> summarydata = new HashMap<>();
		ArrayList<Summary> dataforsummary =new ArrayList<>(); 
		Summary summaryobj = new Summary();
		summaryobj.setActivate_Incorrectattempt("0");
		summaryobj.setActivate_Retrievereferencenumber("0");
		summaryobj.setDeActivate_Incorrectattempt("0");
		summaryobj.setDeActivate_Retrievereferencenumber("0");
		summaryobj.setGetRef_Incorrectattempt("0");
		summaryobj.setGetRef_Retrievereferencenumber("0");
		summaryobj.setGetUid_Incorrectattempt("0");
		summaryobj.setGetUid_Retrievereferencenumber("0");
		summaryobj.setStrUid_Aadhaarduplicatecheck("0");
		summaryobj.setStrUid_Getexistingreferencenumber("0");
		summaryobj.setStrUid_StoreAadhaarNumber("0");
		summaryobj.setTotalCount("0");

		for (Report rep : finalRepo) {
			System.out.println("===" + rep.getApkName() + "===");
			summaryobj.setApplicationName(rep.getApkName());
			for (Map.Entry<String, HashMap<String, Integer>> entry : rep.getSummary().entrySet()) {

				System.out.println("::::::::OPR:::::::::: " + entry.getKey() + ":");
				for (Map.Entry<String, Integer> en : rep.getSummary().get(entry.getKey()).entrySet()) {
					
					if(entry.getKey().trim().equalsIgnoreCase("struid"))
					{
						if (en.getKey().trim().equalsIgnoreCase("false")) {						
								summaryobj.setStrUid_Aadhaarduplicatecheck(Integer.toString(en.getValue()));

						} else if (en.getKey().trim().equalsIgnoreCase("true")) {							
								summaryobj.setStrUid_Getexistingreferencenumber(Integer.toString(en.getValue()));						
							
						} else {						
								summaryobj.setStrUid_StoreAadhaarNumber(Integer.toString(en.getValue()));														
							
						}

				
					}else if(entry.getKey().trim().equalsIgnoreCase("getrefnum"))
					{
						if (en.getKey().trim().equalsIgnoreCase("y")) {							
								summaryobj.setGetRef_Retrievereferencenumber(Integer.toString(en.getValue()));							
							
						} else {							
								summaryobj.setGetRef_Incorrectattempt(Integer.toString(en.getValue()));						
							
						}
						
					}else if(entry.getKey().trim().equalsIgnoreCase("getuid"))
					{
						if (en.getKey().trim().equalsIgnoreCase("y")) {							
								summaryobj.setGetUid_Retrievereferencenumber(Integer.toString(en.getValue()));					
							
						} else {							
								summaryobj.setGetUid_Incorrectattempt(Integer.toString(en.getValue()));							
						}
						
					}else if(entry.getKey().trim().equalsIgnoreCase("activate"))
					{
						if (en.getKey().trim().equalsIgnoreCase("y")) {							
								summaryobj.setActivate_Retrievereferencenumber(Integer.toString(en.getValue()));	
						} else {							
								summaryobj.setActivate_Incorrectattempt(Integer.toString(en.getValue()));														
						}
						
					}else if(entry.getKey().trim().equalsIgnoreCase("deactivate"))
					{
						if (en.getKey().trim().equalsIgnoreCase("y")) {						
								summaryobj.setDeActivate_Retrievereferencenumber(Integer.toString(en.getValue()));								
						} else {							
								summaryobj.setDeActivate_Incorrectattempt(Integer.toString(en.getValue()));															
						}						
					}
					
					System.out.println(en.getKey() + "::" + en.getValue());

				}
				
				

			}
			System.out.println("------------");
			dataforsummary.add(summaryobj);
			
		}
		for (Summary summary : dataforsummary) {
			System.out.println("----------------------final"+summary.toString());
		}
		
		return dataforsummary;

	}
		
		

}
