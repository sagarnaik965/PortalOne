package in.cdac.portal.dao;

import java.io.IOException;
import java.text.ParseException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.web.multipart.MultipartFile;
import in.cdac.portal.modal.*;

import in.cdac.portal.entities.User;

public interface UserDao {

	public List<User> getUser(String userName);

	public void updatePassword(String userName, String password);

	public List<User> loadUserByUsernameAndTenantname(String username, String tenantName);

	public List<ProfileDetail> getProfileDetails(String userName);

	public void updateProfileDetails(String userName, ProfileDetail profileDetail);

	public List<AcCode> getAcCode(String userName);

	public void updateAc(String userName, String ac);

	public List<UpdateAuaLk> getlk(String userName);

	public boolean updateAuaLk(String userName, UpdateAuaLk updateAuaLk);

//	public int addUser(String userName, AddUser user);
	public String addUser(String userName, AddUser user);

	public boolean checkOldPassword(String userName, String oldPassword);

	public List<UserStatus> getUserStatus();

	public List<UserStatus> getLkStatus();

	public List<UserStatus> getSAStatus();

	public List<UserStatus> getAppcode();

	public List<UserStatus> getEmailAppnameByAppcode(String appcode);

	public List<AddUser> getAPPCodes();

	public List<String> checkSaLKPersistance(List saCode);

	public List<UserStatus> getsaLkStatus();

	public void emailVerificationAccountPasswordUpdate(int dept, String password);

	// public void updateLoginStatus(List<String> deptId, boolean loginStatus);

	public int getRoleIdFromUsername(String username);

	public List<TransactionDetailReport> getTransactionDetailsReport(String username, int roleid, String txnType,
			String fDate, String lDate);

	public List<TransactionDetailReport> getTransactionDetailsCsvReport(String username, String txnType, String fDate,
			String lDate);

	public boolean checkEmailVerificationStatus(int deptId);

	public List<UserStatus> getTransactionStatus();

	public void updateTransactionStatus(List<String> deptId, List<String> type, boolean transactionStatus);

	public String generateUdcCode(String userName, GenerateUdcCode udc);

	public List<KuaLk> getKualk(String userName);

	public boolean updatekuaLk(String userName, KuaLk updateKuaLK);

	public List<GenerateUdcCode> getUdc(String userName);

	public List<AuthCount> getAuthTransStats(String userName);

	public List<AuthCount> getOtpTransStats(String userName);

	public List<AuthCount> getKycTransStats(String userName);

	public Map<String, List<TransactionCountDetails>> getMonthlyCountAdmin(String userName, Integer role);

	// public List<HomebarGraph> getHomeBar(String userName,Integer role);
	// public Map<String, Map<String, Integer>> getHomeBar(String userName, Integer
	// role);
	public Map<String, Map<String, Integer>> getHomeBar(String userName);

	// public Map<String, Integer> getHomePageCount(String userName, Integer role);
	public Map<String, Integer> getHomePageCount(String userName);

	public List<LicensekeyDetails> getAsalk(String userName);

	public boolean updateAsaLk(String userName, LicensekeyDetails updateAsaLK);

	public ConnectorParam getconnectorParam(String userName);

	public List<String> getUdcList(String userName);

	public Object getparamdetails(String userName);

	// public Map<String, Integer> getMonthlyTotalTrans(String userName, Integer
	// role);
	public Map<String, Integer> getMonthlyTotalTrans(String userName);

	public boolean checkUserFromEmailId(String userName);

	public String getUserNameFromEmailId(String emailId);

	public boolean checkAuaCode(String auaCode);

	public String getCurrentDeptId(String userName);

	public String getAppCode(String dept);

	public List<AdminDeptCount> getAdminDeptCount();

	public int getDeptCount(String userName);

	public String getCurrentEmailId(String userName);

	public String getCurrentDeptName(String emailId);

	public boolean checkUserFromDeptName(String deptName);

	public List<String> getEmailIdFromDeptId(List<String> deptId);

	public List<String> getEmailIdFromUsername(List<String> username);

	public List<LicensekeyDetails> getKsalk(String userName);

	public boolean updateKsaLk(String userName, LicensekeyDetails updateKsaLK)
			throws DataAccessException, ParseException;

	public boolean checkForDuplicateKey(LicensekeyDetails lk, String type, int currentDeptId);

	public boolean checkForgetPasswordDetail(ForgetPassword forgetpassword);

	public boolean sendPasswordRecoveryEmail(ForgetPassword forgetpassword);

	public boolean UpdateRecoverPassword(String userName, String encode);

	public List<ResendActivationList> getActivationReSendList();

	public List<AboutToExpireLK> getAboutToExpireLK();

	public boolean UpdateSignDetails(SigningDetails signdetails, String userName);

	public List<DetailedTransaction> getDetailedTransaction(Integer role, String type, String userName);

	public List<SigningDetails> getSignPrefrence(String userName, String ac);

	public List<ErrorCodeCount> getTotalErrorTrans(Integer role, String userName);

	public List<DetailedTransaction> getDetailedErrorTransaction(String errorCode, String userName, Integer role);

	// public Map<String, Integer> getTotalTransactionHomePage(Integer role, String
	// userName);
	public Map<String, Integer> getTotalTransactionHomePage(String userName);

	public Map<String, Integer> acwiseTotaltrans(String acCode);

	public Map<String, Integer> acWiseYesTrans(String acCode);

	// public int getTotalErrorCount(List<Integer> roles, String userName);
	public int getTotalErrorCount(String userName);

	/*
	 * public List<GenerateUdcCode> getkunaludc(String userName);
	 * 
	 * public String getupdateno(String userName);
	 * 
	 * public List<ProfileInfo> getmobileno(String username);
	 * 
	 * public boolean getupdatenumber(ProfileInfo profileinfo, String userName);
	 */

	public String getConnectorDowloadFilePath();

	// public int getHomePageSuccessCount(int role, String userName);
	public int getHomePageSuccessCount(String userName);

	public int getTotalAcCountDeptWise(String userName);

	public Map<String, Integer> getTotaldeshDeptCouont(String userName);

	public int getTransactionDetail(String userName);

	public List<TransactionDetailReport> getTransactionDetailReportCount(String userName, String transactiontype,
			String responsetype, int records, String fromDate, String toDate);

	public List<TransactionDetailReport> getTransactionDetail(String userName, String txn, String type);

	public boolean updateResetPasswordDetail(String userName, String randomUuid);

	public boolean checkForPassworResetValidToken(String token, String userName);

	public Map<String, String> getAuaCodeFromEmail(String email);

	public Map<String, TransactionCountTotal> getHomePageTabelData(String userName);

	// public List<AdminDeptCount> getSuccessCount(String userName, Integer role);
	public Map<String, Integer> getSuccessCount(String userName);

	// public List<AdminDeptCount> getFailureCount(String userName, Integer role);
	public Map<String, Integer> getFailureCount(String userName);

	public Map<String, Integer> acwiseNotrans(String acCode);

	public List<AdminDeptCount> getTimeExecutionRecords(String fromDate, String toDate, Integer role, String deptId);

	public List<AdminDeptCount> getFailureReportCount(String deptId, String fromDate, String toDate);

	public String getDeptNameFromId(String deptId);

	public String getAcFromId(String deptId);

	public String getFraudDetectionTimeSchedule();

	public List<FraudDetectionObject> getDetectedFraudTransaction();

	public void updateFraudDetectionEmailSent(FraudDetectionObject obj);

	// public String getPasswordRecoveryURLStart();

	// public String getEmailActivationUrlStart();

	// public String getDeploymentEnviroment();

	public void uploadCertificate(String userName, MultipartFile[] cert, String certIdentifier, String certpath,
			String certalias, String certpass, String type, String validTill) throws DataAccessException, IOException;

	public List<CertificateDetails> getCerticateDetails(String userName);

	public List<AcCode> getAcList();

	public String getDeptNameFromAc(String ac);

	// public String getBccEmailId();

	public String getCcEmailId(String to);

	public List<AboutToExpireCertificate> getAboutToExpireCertificates();

	public List<SuccessCount> getSuccessCount1(String userName);

	public List<SuccessCount> getFailureCountNew(String userName, Integer role);

	public List<AdminDeptCount> getFailureTimeExecutionRecords(String fromDate, String toDate, Integer role,
			String deptId);

	public String getParaValueByParaName(String string);

	public String getPortalUrl();

	public List<String> getActivityListByUsername(String username, String tenant);

	public void updateLoginStatus(List<String> usernames, List<String> auacodes, List<Boolean> loginStatusList,
			List<Boolean> authStatusList, List<Boolean> otpStatusList, List<Boolean> ekycStatusList);

	public void generateSaLk(List<String> auacodes, List<String> dateValueList);

	public void generateSchemeCode(List<String> saCode, List<String> schemeDesc);

	public void suspendUser(List<String> usernames, boolean status);

	public List<UserStatus> getSuspendUserStatus();

	public boolean updateSaLk(List<String> saCode, List<String> salk, List<String> dateValueList);

//	-----------------------Methods for react application---------------------------------------

	public List<StateList> getStateList();

	public int getHomePageSuccessCountR(String userName);

	public int getTotalErrorCountR(String userName);

	public Map<String, Integer> getMonthlyTotalTransR(String userName);

	public int getTotalAcCountDeptWiseR(String userName);

	public Map<String, Integer> getTotalTransactionHomePageR(String userName);

	public List<UserStatus> getAppcodeR(String username);

	public Map<String, Integer> acwiseNotransR(String acCode);

	public Map<String, Integer> acWiseYesTransR(String acCode);

	public Map<String, Integer> acwiseTotaltransR(String[] acCode);

	public List<String[]> Reports(String firstOfMonth, String lastOfMonth , String username);

	public String getRole(String principal);

	public Map<String, DeptDetails> getrecordR(String deptcode);

//	*************************************************************************************************

	List<DeptList> getDeptListR();

	List<AppList> getAppListR(String deptcode);

	AppDetail getAppDetailR(String appcode);

	AppLk getAppLkR(String appcode);

	AllowedOpr getOprR(String appcode);

	String getAppUpdateR(AppDetail appdetail, String appcode);

	String getOprUpdateR(AllowedOpr opr, String appcode);

	public String getstruidR(AllowedOpr opr, String appcode);

	public String getrefnumR(AllowedOpr opr, String appcode);

	public String getuidR(AllowedOpr opr, String appcode);

	public String getactivateR(AllowedOpr opr, String appcode);

	public String getdeactivateR(AllowedOpr opr, String appcode);

	public String getEmailUpdateR(AppDetail appdetail, String appcode);

	public String getAppnameUpdateR(AppDetail appdetail, String appcode);

	public String getlkexpiryupdateR(AppLk applkex, String appcode);

	public String generatelkR(GenerateAppLK genlk, String appcode);

	public String getdupcheckR(AllowedOpr opr, String appcode);

	DeptList getDeptcodeFromUsername(String username);

	// 28-09-2022
	public AppLk getAdminAppLkR(String appcode);

	public String appCreateR(AppDetail appcreate, String deptcode);

	public String deptRegistrationR(DeptDetails deptdetails);

	public List<OprList> getOprList();

	public List<Algo_Info> getAlgoIdList();

	public List<Slot> getSlotList();

	public List<KeyInfo> getKeyId();

	public KeyInfo getKeyinfo(int key_info_id);

	public DeptList getDeptnamewithDeptcode(String deptcode);

	public String keyMappingInsert(KeyMapping keymap);

	public String keyInfoInsert(KeyInfo keyinfo, String deptcode);

	public long getDataForChart(String date,String Username);

	public List<String> getactivityofuser(String user);

	public List<Activities> getActivity();

	public String getuserroleinsertR(UserRolesforUserManagement userrole);

	public String getroleactivityinsertR(RoleActivity roleact);

	public String keyinfoinsertforsoft(KeyInfo keyinfo, String deptcode);

	public Map<String, Summary> Reportspdf(String first, String last, String username);

	String getDeptcodeFromUsernameforreport(String username);

	public ArrayList<Summary> getSummaryForJasperIgnite(String first, String last, String username);

	

}
