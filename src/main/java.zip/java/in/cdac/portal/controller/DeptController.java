package in.cdac.portal.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.ZoneId;
import java.time.temporal.IsoFields;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import in.cdac.portal.billing.BillingServices;
import in.cdac.portal.modal.Activities;
import in.cdac.portal.modal.Algo_Info;
import in.cdac.portal.modal.AllowedOpr;
import in.cdac.portal.modal.AppDetail;
import in.cdac.portal.modal.AppList;
import in.cdac.portal.modal.AppLk;
import in.cdac.portal.modal.ChartData;
import in.cdac.portal.modal.Count;
import in.cdac.portal.modal.Count1;
import in.cdac.portal.modal.DeptDetails;
import in.cdac.portal.modal.DeptList;
import in.cdac.portal.modal.GenerateAppLK;
import in.cdac.portal.modal.KeyInfo;
import in.cdac.portal.modal.KeyMapping;
import in.cdac.portal.modal.OprList;
import in.cdac.portal.modal.PortalConstant;
import in.cdac.portal.modal.RoleActivity;
import in.cdac.portal.modal.Slot;
import in.cdac.portal.modal.UserRolesforUserManagement;
import in.cdac.portal.modal.UserStatus;
import in.cdac.portal.service.UserService;

@CrossOrigin(origins = { PortalConstant.BASEURL+PortalConstant.PORT, "http://localhost:8080" })
@RequestMapping("/dept")
@RestController
public class DeptController {

	@Autowired
	UserService service;

	@Autowired(required = true)
	BillingServices billSer;

	static HttpSession sess;

	private final static Logger logger = Logger.getLogger(DeptController.class);

	

	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@GetMapping(value = "/homepagesuccesscount")
	public int getHomePageSuccessCountR() {
		int count = 0;
		try {
			if (sess != null)
				count = service.getHomePageSuccessCountR((String) sess.getAttribute("username"));
			return count;
		} catch (Exception e) {
			logger.info("Exception Data for Success count not found " + e.getMessage());
			return count;
		}

	}

	@CrossOrigin(origins  = PortalConstant.BASEURL+PortalConstant.PORT)
	@GetMapping(value = "totalerrorcount")
	public int totalErrorCountR() {
		int count = 0;
		try {
			if (sess != null)
				count = service.getTotalErrorCountR((String) sess.getAttribute("username"));
			return count;
		} catch (Exception e) {
			logger.info("Exception Data for unsuccessful count not found " + e.getMessage());
			return 0;
		}
	}

	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@RequestMapping(value = "/totalaccountdeptwise", method = RequestMethod.GET)
	public int getTotalAcCountDeptWiseR() {
		int count = 0;
		try {
			if (sess != null)
				count = service.getTotalAcCountDeptWiseR((String) sess.getAttribute("username"));
			return count;
		} catch (Exception e) {
			logger.info("Exception Data for application count  not found " + e.getMessage());
			return count;
		}

	}

	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@RequestMapping(value = "homepagetranstable", method = RequestMethod.GET)
	public List<Count1> homePageTransTableR() {
		List<Count1> coundata = new ArrayList<>();
		try {
			if (sess != null) {
				coundata = service.getTotalTransactionHomePageR((String) sess.getAttribute("username"));
			}
			return coundata;
		} catch (Exception e) {
			logger.info("Exception Data for home page chart txn count  not found " + e.getMessage());
			return coundata;
		}
	}

	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@ResponseBody
	@GetMapping("/appcodedetails")
	public List<UserStatus> appcodeDetailsR() {
		List<UserStatus> userlist = new ArrayList<>();
		try {
			if (sess != null) {
				userlist = service.getAppcodeR((String) sess.getAttribute("username"));
			}
			return userlist;
		} catch (Exception e) {
			logger.info("Exception Data for list of application not found " + e.getMessage());
			return userlist;
		}

	}



	@RequestMapping(value = "/applicationwisedata", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@PostMapping
	public List<Count> acwiseTotaltransR(@RequestBody String[] appcodedata) {
		List<Count> countData = new ArrayList<>();
		try {
			countData = service.acwiseTotaltransR(appcodedata);
			return countData;
		} catch (Exception e) {
			logger.info("Exception Data for opr wise chart not found " + e.getMessage());
			return countData;
		}
	}


	// ---------------------------------final bill for
	// department--------------------------------------------------------------

	@RequestMapping(value = "/billDeptCategpdf", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@PostMapping
	public ResponseEntity<byte[]> getBillDeptLevelCategorypdf(@RequestBody String[] datedata) {
		try {
			String username = "";
			if (sess != null)
				username = (String) sess.getAttribute("username");

			service.getSummaryForJasperIgnite(datedata, username);
			return service.getBillingDataForPdf(datedata, username);
		} catch (Exception e) {
			logger.info("Failed to fetch billing data " + e.getMessage());
			return new ResponseEntity<byte[]>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

//	----------------------------------report summary for department--------------------------------

	@RequestMapping(value = "/summaryreport", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@PostMapping
	public ResponseEntity<byte[]> monthlyReportpdf(@RequestBody String[] datedata) {
		try {
			String username = "";
			if (sess != null)
			{
				username = (String) sess.getAttribute("username");
			}
			return service.getSummaryForJasperIgnite(datedata, username);
		} catch (Exception e) {
			logger.info(e.getMessage());
			return new ResponseEntity<byte[]>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

//	----------------------------------report summary for application--------------------------------
	@RequestMapping(value = "/summaryreportappwise", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@PostMapping
	public ResponseEntity<byte[]> monthlyReportpdfApp(@RequestBody String[] datedata) {
		try {
		
			String username = "";
			if (sess != null)
				username = (String) sess.getAttribute("username");

			return service.getSummaryForJasperIgniteapp(datedata, username);
		} catch (Exception e) {

			logger.info("monthly report failed to get data" + e.getMessage());
			return new ResponseEntity<byte[]>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}



	// ---------------------------final bill for
	// application-------------------------------------
	@RequestMapping(value = "/billAppCategpdf", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@PostMapping
	public ResponseEntity<byte[]> getBillAppLevelCategorypdf(@RequestBody String[] datedata) {
		try {
			String username="";
			if (sess != null)
				username = (String) sess.getAttribute("username");

			service.getSummaryForJasperIgniteapp(datedata, username);
			return service.getBillingDataForPdfapp(datedata, username);
		} catch (Exception e) {
			logger.info("Failed to fetch billing data " + e.getMessage());
			return new ResponseEntity<byte[]>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	
	
	
	

	
	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@RequestMapping(path = "/getusername")
	@GetMapping
	public String getusername() {
		try {
			String username = "";
			if (sess != null)
				if ((String) sess.getAttribute("username") != null) {
					try {
						username = (String) sess.getAttribute("username");
					} catch (Exception e) {
						sess = null;
					}
					return username;
				} else {
					username = "f";
					return "f";
				}
			return "f";
		} catch (Exception e) {
			logger.info("Problem in fetching username " + e.getMessage());
			return "f";
		}
	}




	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@RequestMapping("/deptlist")
	@GetMapping
	public List<DeptList> deptlistprint() {
		List<DeptList> deptList = service.getDeptListR();
		if (deptList != null) {
			return deptList;
		}
		return null;
	}

	@RequestMapping(value = "/getDeptDetails", method = RequestMethod.GET)
	public Map<String, DeptDetails> departmentDetail(@RequestParam String deptName, @RequestParam String deptCode,
			ModelMap map1) {
		Map<String, DeptDetails> deptmap = (Map<String, DeptDetails>) service.getDeptServiceDetailsR(deptCode);
		if (!deptmap.isEmpty()) {
			map1.addAttribute("DeptandService", deptmap);
			map1.addAttribute("deptname", deptName);
			map1.addAttribute("deptcode", deptCode);
			return deptmap;
		}
		map1.addAttribute("deptname", deptName);
		DeptDetails d = new DeptDetails();
		d.setApp_name("Not Available");

		deptmap.put(deptName, d);
		map1.addAttribute("DeptandService", deptmap);
		return deptmap;

	}

	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@RequestMapping(value = "/applist/{deptcode}", method = RequestMethod.GET)
	public List<AppList> applistprint(@PathVariable(name = "deptcode", required = false) String deptcode) {
		List<AppList> appList = service.getAppListR(deptcode);

		if (appList != null) {
			return appList;
		}
		return null;
	}

	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@RequestMapping(value = "/appdetail/{appcode}", method = RequestMethod.GET)
	public AppDetail appdetailprint(@PathVariable(name = "appcode", required = false) String appcode) {
		AppDetail appdetail = service.getAppDetailR(appcode);
		if (appdetail != null) {
			return appdetail;
		}
		return null;
	}

	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@RequestMapping(value = "/applk/{appcode}", method = RequestMethod.GET)
	public AppLk applkprint(@PathVariable(name = "appcode", required = false) String appcode) {
		AppLk applk = service.getAppLkR(appcode);
		if (applk != null) {
			return applk;
		}
		return null;
	}

	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@RequestMapping(value = "/adminapplk/{appcode}", method = RequestMethod.GET)
	public AppLk adminapplkprint(@PathVariable(name = "appcode", required = false) String appcode) {
		AppLk applk = service.getAdminAppLkR(appcode);
		if (applk != null) {
			return applk;
		}
		return null;
	}

	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@RequestMapping(value = "/opr/{appcode}", method = RequestMethod.GET)
	public AllowedOpr oprprint(@PathVariable(name = "appcode", required = false) String appcode) {
		AllowedOpr opr = service.getOprR(appcode);
		if (opr != null) {
			return opr;
		}
		return null;
	}

	// ---------------------------------------------------------------------------------------------------------
	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@RequestMapping(value = "/appupdate/{appcode}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@PostMapping
	public String getAppUpdateR(@Valid @RequestBody AppDetail appdetail,
			@PathVariable(name = "appcode", required = false) String appcode) {

		String adu = service.getAppUpdateR(appdetail, appcode);

		return adu;

	}

	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@RequestMapping(value = "/emailupdate/{appcode}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@PostMapping
	public String getEmailUpdateR(@Valid @RequestBody AppDetail appdetail,
			@PathVariable(name = "appcode", required = false) String appcode) {
		String adu = service.getEmailUpdateR(appdetail, appcode);

		return adu;

	}

	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@RequestMapping(value = "/appnameupdate/{appcode}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@PostMapping
	public String getAppnameUpdateR(@Valid @RequestBody AppDetail appdetail,
			@PathVariable(name = "appcode", required = false) String appcode) {
		String adu = service.getAppnameUpdateR(appdetail, appcode);

		return adu;

	}

	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@RequestMapping(value = "/oprupdate/{appcode}")
	public String getOprUpdateR(@Valid @RequestBody AllowedOpr opr,
			@PathVariable(name = "appcode", required = false) String appcode) {
		String opru = service.getOprUpdateR(opr, appcode);

		return opru;

	}

	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@RequestMapping(value = "/struid/{appcode}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@PostMapping
	public String getstruidR(@Valid @RequestBody AllowedOpr opr,
			@PathVariable(name = "appcode", required = false) String appcode) {
		String opru = service.getstruidR(opr, appcode);

		return opru;

	}

	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@RequestMapping(value = "/refnum/{appcode}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@PostMapping
	public String getrefnumR(@Valid @RequestBody AllowedOpr opr,
			@PathVariable(name = "appcode", required = false) String appcode) {
		String opru = service.getrefnumR(opr, appcode);

		return opru;

	}

	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@RequestMapping(value = "/uid/{appcode}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@PostMapping
	public String getuidR(@Valid @RequestBody AllowedOpr opr,
			@PathVariable(name = "appcode", required = false) String appcode) {
		String opru = service.getuidR(opr, appcode);

		return opru;

	}

	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@RequestMapping(value = "/act/{appcode}")
	@PostMapping
	public String getactivateR(@Valid @RequestBody AllowedOpr opr,
			@PathVariable(name = "appcode", required = false) String appcode) {
		String opru = service.getactivateR(opr, appcode);
		return opru;

	}

	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@RequestMapping(value = "/deact/{appcode}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@PostMapping
	public String getdeactivateR(@Valid @RequestBody AllowedOpr opr,
			@PathVariable(name = "appcode", required = false) String appcode) {
		String opru = service.getdeactivateR(opr, appcode);
		return opru;

	}

	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@RequestMapping(value = "/dupcheck/{appcode}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@PostMapping
	public String getdupcheckR(@Valid @RequestBody AllowedOpr opr,
			@PathVariable(name = "appcode", required = false) String appcode) {
		String opru = service.getdupcheckR(opr, appcode);

		return opru;

	}

	@CrossOrigin(origins = "http://locademohost:3000")
	@RequestMapping(value = "/lkexpiryupdate/{appcode}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@PostMapping
	public String getlkexpiryupdateR(@Valid @RequestBody AppLk applkex,
			@PathVariable(name = "appcode", required = false) String appcode) {
		String applkexpiry = service.getlkexpiryupdateR(applkex, appcode);
		return applkexpiry;

	}

	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@RequestMapping(value = "/generatelk/{appcode}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@PostMapping
	public String generatelkR(@Valid @RequestBody GenerateAppLK genlk,
			@PathVariable(name = "appcode", required = false) String appcode) {
		String lk = service.generatelkR(genlk, appcode);
		return lk;

	}

	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@GetMapping("/getDeptcodeandName/{username}")
	@ResponseBody
	public DeptList getDeptcodeFromUsername(@PathVariable String username) {
		try {
			return service.getDeptcodeFromUsername(username);
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Problem to fetch deptList " + e);
			return null;
		}

	}

	/// for application creation

	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@RequestMapping(value = "/appcreate/{deptcode}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@PostMapping
	public String appCreateR(@Valid @RequestBody AppDetail appcreate,
			@PathVariable(name = "deptcode", required = false) String deptcode) {
		String appcreation = service.appCreateR(appcreate, deptcode);

		return appcreation;

	}

	// for department registration

	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@RequestMapping(value = "/deptregistration", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@PostMapping
	public String deptRegistrationR(@Valid @RequestBody DeptDetails deptdetails) {
		String deptregis = service.deptRegistrationR(deptdetails);
		return deptregis;

	}



	@GetMapping("/oprlist")
	public List<OprList> getOprList() {
		List<OprList> oprList = service.getOprList();
		if (oprList != null) {
			return oprList;
		}
		return null;
	}

	@GetMapping("/algoid")
	public List<Algo_Info> getAlgoIdList() {
		List<Algo_Info> algoidList = service.getAlgoIdList();
		if (algoidList != null) {
			return algoidList;
		}
		return null;
	}

	@GetMapping("/slot")
	public List<Slot> getSlotList() {
		List<Slot> slot = service.getSlotList();
		if (slot != null) {
			return slot;
		}
		return null;
	}

	@GetMapping("/keyid")
	public List<KeyInfo> getKeyId() {
		List<KeyInfo> keyid = service.getKeyId();
		if (keyid != null) {
			return keyid;
		}
		return null;
	}

	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@RequestMapping(value = "/keyinfodetails/{key_info_id}", method = RequestMethod.GET)
	public KeyInfo getKeyinfo(@PathVariable(name = "key_info_id", required = false) int key_info_id) {
		KeyInfo key = service.getKeyinfo(key_info_id);
		if (key != null) {
			return key;
		}
		return null;
	}

	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@RequestMapping(value = "/deptname/{deptcode}", method = RequestMethod.GET)

	public DeptList getDeptnamewithDeptcode(@PathVariable(name = "deptcode", required = false) String deptcode) {
		DeptList dptname = service.getDeptnamewithDeptcode(deptcode);
		if (dptname != null) {
			return dptname;
		}
		return null;
	}

	// for key mapping insert

	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@RequestMapping(value = "/keymappinginsert", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@PostMapping
	public String keyMappingInsert(@Valid @RequestBody KeyMapping keymap) {
		String keymapping = service.keyMappingInsert(keymap);

		return keymapping;

	}

	// key info insertion

	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@RequestMapping(value = "/keyinfoinsert/{deptcode}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@PostMapping
	public String keyInfoInsert(@Valid @RequestBody KeyInfo keyinfo,
			@PathVariable(name = "deptcode", required = false) String deptcode) {
		String keyinfoinsert = service.keyInfoInsert(keyinfo, deptcode);

		return keyinfoinsert;

	}

	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@RequestMapping(value = "/keyinfoinsertforsoft/{deptcode}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@PostMapping
	public String keyinfoinsertforsoft(@Valid @RequestBody KeyInfo keyinfo,
			@PathVariable(name = "deptcode", required = false) String deptcode) {
		String keyinfoinsert = service.keyinfoinsertforsoft(keyinfo, deptcode);

		return keyinfoinsert;

	}

//for chart

//	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
//	@GetMapping("/chartfordays")
//	public ChartData getAjaxDemo1(Model model) {
//		ChartData chartData = new ChartData();
//		String label[] = new String[7];
//		try {
//			long[] arr = new long[7];
//			chartData.setData(arr);
//			chartData.setLabels(label);
//			LocalDate date = LocalDate.now(ZoneId.of("Europe/Paris"));
//			label[6] = date.toString();
//			if (sess != null)
//				arr[6] = service.getDataForChart(date.toString(), (String) sess.getAttribute("username"));
//
//			date = LocalDate.now(ZoneId.of("Europe/Paris")).minusDays(1);
//			label[5] = date.toString();
//			if (sess != null)
//				arr[5] = service.getDataForChart(date.toString(), (String) sess.getAttribute("username"));
//
//			date = LocalDate.now(ZoneId.of("Europe/Paris")).minusDays(2);
//			label[4] = date.toString();
//			if (sess != null)
//				arr[4] = service.getDataForChart(date.toString(), (String) sess.getAttribute("username"));
//
//			date = LocalDate.now(ZoneId.of("Europe/Paris")).minusDays(3);
//			label[3] = date.toString();
//			if (sess != null)
//				arr[3] = service.getDataForChart(date.toString(), (String) sess.getAttribute("username"));
//
//			date = LocalDate.now(ZoneId.of("Europe/Paris")).minusDays(4);
//			label[2] = date.toString();
//			if (sess != null)
//				arr[2] = service.getDataForChart(date.toString(), (String) sess.getAttribute("username"));
//
//			date = LocalDate.now(ZoneId.of("Europe/Paris")).minusDays(5);
//			label[1] = date.toString();
//			if (sess != null)
//				arr[1] = service.getDataForChart(date.toString(), (String) sess.getAttribute("username"));
//
//			date = LocalDate.now(ZoneId.of("Europe/Paris")).minusDays(6);
//			label[0] = date.toString();
//			if (sess != null)
//				arr[0] = service.getDataForChart(date.toString(), (String) sess.getAttribute("username"));
//			chartData.setData(arr);
//			return chartData;
//		} catch (Exception e) {
//			logger.info("Exception chart data not found " + e.getMessage());
//			return null;
//		}
//
//	}

	// for user management--------------------------------
	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@RequestMapping(value = "/activity", method = RequestMethod.GET)
	public List<Activities> getActivity() {

		List<Activities> activity = service.getActivity();
//			 sort(stateList);
		if (activity != null) {
			return activity;
		}
		return null;
	}

	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@RequestMapping(value = "/userroleinsert", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@PostMapping
	public String getuserroleinsertR(@Valid @RequestBody UserRolesforUserManagement userrole) {
		String adu = service.getuserroleinsertR(userrole);
		return adu;

	}

	@CrossOrigin(origins = PortalConstant.BASEURL+PortalConstant.PORT)
	@RequestMapping(value = "/roleactivityinsert", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@PostMapping
	public String getroleactivityinsertR(@Valid @RequestBody RoleActivity roleact) {
		String adu = service.getroleactivityinsertR(roleact);
		return adu;

	}

	

}
