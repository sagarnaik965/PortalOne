package in.cdac.portal.modal;

public class Slot {
	
	public String slot;
	public String passwd;
	public String getSlot() {
		return slot;
	}
	public void setSlot(String slot) {
		this.slot = slot;
	}
	public String getPasswd() {
		return passwd;
	}
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	@Override
	public String toString() {
		return "Slot [slot=" + slot + ", passwd=" + passwd + "]";
	}
	

}
