package in.cdac.portal.modal;

import java.sql.Timestamp;
import java.util.Date;

//import java.sql.String;

//import java.sql.String;
//import java.util.String;

import com.fasterxml.jackson.annotation.JsonFormat;

public class KeyInfo {

	public int key_info_id;
	public String opr;
	public String opr_type;
	
	
	public String getOpr_type() {
		return opr_type;
	}

	public void setOpr_type(String opr_type) {
		this.opr_type = opr_type;
	}

	public int algo_id;
	public String algo;

	public String getAlgo() {
		return algo;
	}

	public void setAlgo(String algo) {
		this.algo = algo;
	}

//	public String getKey_expiry_date() {
//		return key_expiry_date;
//	}

//	public void setKey_expiry_date(String key_expiry_date) {
//		this.key_expiry_date = key_expiry_date;
//	}

	public String hash_key_id;
	public String slot;
	public String key_label;
	public String key;

//	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", timezone="Europe/Berlin")
//	@JsonFormat( pattern = "yyyy-MM-dd HH:mm:ss")
//	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", locale = "zh", timezone = "GMT+8")
//	@JsonFormat(pattern ="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	public String key_expiry_date;

	public Date key_expiry_date_display;

	public Date getKey_expiry_date_display() {
		return key_expiry_date_display;
	}

	public void setKey_expiry_date_display(Date key_expiry_date_display) {
		this.key_expiry_date_display = key_expiry_date_display;
	}

	public boolean key_is_active;
	public boolean is_default;
	public String tkn_type;
	public String dept_code;

	public int getKey_info_id() {
		return key_info_id;
	}

	public void setKey_info_id(int key_info_id) {
		this.key_info_id = key_info_id;
	}

	public String getOpr() {
		return opr;
	}

	public void setOpr(String opr) {
		this.opr = opr;
	}

	public int getAlgo_id() {
		return algo_id;
	}

	public void setAlgo_id(int algo_id) {
		this.algo_id = algo_id;
	}

	public String getHash_key_id() {
		return hash_key_id;
	}

	public void setHash_key_id(String hash_key_id) {
		this.hash_key_id = hash_key_id;
	}

	public String getSlot() {
		return slot;
	}

	public void setSlot(String slot) {
		this.slot = slot;
	}

	public String getKey_label() {
		return key_label;
	}

	public void setKey_label(String key_label) {
		this.key_label = key_label;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getkey_expiry_date() {
		return key_expiry_date;
	}

	public void setkey_expiry_date(String key_expiry_date) {
		this.key_expiry_date = key_expiry_date;
	}

	public boolean isKey_is_active() {
		return key_is_active;
	}

	public void setKey_is_active(boolean key_is_active) {
		this.key_is_active = key_is_active;
	}

	public boolean isIs_default() {
		return is_default;
	}

	public void setIs_default(boolean is_default) {
		this.is_default = is_default;
	}

	public String getTkn_type() {
		return tkn_type;
	}

	public void setTkn_type(String tkn_type) {
		this.tkn_type = tkn_type;
	}

	public String getDept_code() {
		return dept_code;
	}

	public void setDept_code(String dept_code) {
		this.dept_code = dept_code;
	}

	@Override
	public String toString() {
		return "KeyInfo [key_info_id=" + key_info_id + ", opr=" + opr + ", opr_type=" + opr_type + ", algo_id="
				+ algo_id + ", algo=" + algo + ", hash_key_id=" + hash_key_id + ", slot=" + slot + ", key_label="
				+ key_label + ", key=" + key + ", key_expiry_date=" + key_expiry_date + ", key_expiry_date_display="
				+ key_expiry_date_display + ", key_is_active=" + key_is_active + ", is_default=" + is_default
				+ ", tkn_type=" + tkn_type + ", dept_code=" + dept_code + "]";
	}

	

}
