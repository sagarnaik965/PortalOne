package in.cdac.portal.modal;

public class OSTicket {

	private String fullname;
	
	private String email;
	
	public OSTicket() {
		
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	
}
