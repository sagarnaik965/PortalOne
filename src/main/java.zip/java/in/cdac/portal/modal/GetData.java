package in.cdac.portal.modal;

public class GetData {
//
//	public static void getConsolidatedCountCategoryWise(String dept) {
//
//		ArrayList<Map<String, String>> mapOfCountsAndCategory = new ArrayList<Map<String, String>>();
//		Map<String, String> map = new HashMap<String, String>();
//		int PSUCount = 0;
//		int privateCount = 0;
//		int govCount = 0;
//
//		ArrayList<String> ApkListPSU = new ArrayList<String>();
//		ArrayList<String> ApkListGov = new ArrayList<String>();
//		ArrayList<String> ApkListPriv = new ArrayList<String>();
//
//		int count = 0;
//		ArrayList<String> list = GetDBData.getAllApkCode(dept);
//
//		for (String apk : list) {
//
//			// count = count + getTransCount(apk);
//			if (GetFileData.getCategory(apk).contains("PSU")) {
//				System.out.println("psu --" + apk);
//				ApkListPSU.add(apk);
//			} else if (GetFileData.getCategory(apk).contains("Private")) {
//				System.out.println("Private --" + apk);
//
//				ApkListGov.add(apk);
//			} else if (GetFileData.getCategory(apk).contains("Govt")) {
//				ApkListPriv.add(apk);
//				System.out.println("Govt --" + apk);
//
//			} else {
//
//			}
//
//		}
//
//		System.out.println(ApkListPSU.size() + " : ApkListPSU \\n " + ApkListGov.size() + " : ApkListGov \\n "
//				+ ApkListPriv.size() + " : ApkListPrivate  ");
//	}

}
