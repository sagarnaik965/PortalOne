package in.cdac.portal.modal;

public class Count1 {
	public int y;
	public String name;
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Count1 [y=" + y + ", name=" + name + "]";
	}
	public Count1(int y, String name) {
		super();
		this.y = y;
		this.name = name;
	}
	public Count1() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
