package in.cdac.portal.modal;

public class AdminDeptCount {

	private String appName;
	//private int deptId;
	private String errorCode;
	//private int count;
	private int struid;
	private int getuid;
	private int getrefnum;
	private int activate;
	private int deactivate;
	private int total;
	private String timePeriod;
	
	
	
	public AdminDeptCount() {
		struid=0;
		getuid=0;
		getrefnum=0;
		activate=0;
		deactivate=0;
	}



	public String getAppName() {
		return appName;
	}



	public void setAppName(String appName) {
		this.appName = appName;
	}



	public String getErrorCode() {
		return errorCode;
	}



	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}



	public int getStruid() {
		return struid;
	}



	public void setStruid(int struid) {
		this.struid = struid;
	}



	public int getGetuid() {
		return getuid;
	}



	public void setGetuid(int getuid) {
		this.getuid = getuid;
	}



	public int getGetrefnum() {
		return getrefnum;
	}



	public void setGetrefnum(int getrefnum) {
		this.getrefnum = getrefnum;
	}



	public int getActivate() {
		return activate;
	}



	public void setActivate(int activate) {
		this.activate = activate;
	}



	public int getDeactivate() {
		return deactivate;
	}



	public void setDeactivate(int deactivate) {
		this.deactivate = deactivate;
	}



	public String getTimePeriod() {
		return timePeriod;
	}



	public void setTimePeriod(String timePeriod) {
		this.timePeriod = timePeriod;
	}



	public int getTotal() {
		return total;
	}



	public void setTotal(int total) {
		this.total = total;
	}
	
	
	
	
	

		
	
}
