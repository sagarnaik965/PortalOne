package in.cdac.portal.modal;

public class OprList {

	public int opr_id;
	public String opr_code;
	public String opr_type;
	public int getOpr_id() {
		return opr_id;
	}
	public void setOpr_id(int opr_id) {
		this.opr_id = opr_id;
	}
	public String getOpr_code() {
		return opr_code;
	}
	public void setOpr_code(String opr_code) {
		this.opr_code = opr_code;
	}
	public String getOpr_type() {
		return opr_type;
	}
	public void setOpr_type(String opr_type) {
		this.opr_type = opr_type;
	}
	@Override
	public String toString() {
		return "OprList [opr_id=" + opr_id + ", opr_code=" + opr_code + ", opr_type=" + opr_type + "]";
	}
	
	
}
