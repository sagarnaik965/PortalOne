package in.cdac.portal.modal;

public class PortalConstant {
 
	public static final String PORT = "3000";
	public static final String BASEURL = "http://localhost:";
	public static final String REACTHOME = "/adv";
	public static final String LOGOUT ="http://localhost:8080/login?logout";

}
