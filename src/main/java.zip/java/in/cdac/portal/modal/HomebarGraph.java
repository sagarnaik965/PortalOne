package in.cdac.portal.modal;

public class HomebarGraph {
	
	private String yearMonth;
	private int auth;
	private int otp;
	private int ekyc;
	public String getYearMonth() {
		return yearMonth;
	}
	public void setYearMonth(String yearMonth) {
		this.yearMonth = yearMonth;
	}
	public int getAuth() {
		return auth;
	}
	public void setAuth(int auth) {
		this.auth = auth;
	}
	public int getOtp() {
		return otp;
	}
	public void setOtp(int otp) {
		this.otp = otp;
	}
	public int getEkyc() {
		return ekyc;
	}
	public void setEkyc(int ekyc) {
		this.ekyc = ekyc;
	}
	

}
