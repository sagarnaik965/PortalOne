package in.cdac.portal.modal;

public class AboutToExpireCertificate {
	private String certIdentifier;
	private String validTill;
	private String certificateType;
	private String ac;
	private String emailId;
	private String deptName;
	private String environment;
	
	public String getCertIdentifier() {
		return certIdentifier;
	}
	public void setCertIdentifier(String certIdentifier) {
		this.certIdentifier = certIdentifier;
	}
	public String getValidTill() {
		return validTill;
	}
	public void setValidTill(String validTill) {
		this.validTill = validTill;
	}
	public String getCertificateType() {
		return certificateType;
	}
	public void setCertificateType(String certificateType) {
		this.certificateType = certificateType;
	}
	public String getAc() {
		return ac;
	}
	public void setAc(String ac) {
		this.ac = ac;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getEnvironment() {
		return environment;
	}
	public void setEnvironment(String environment) {
		this.environment = environment;
	} 
	
	

}
