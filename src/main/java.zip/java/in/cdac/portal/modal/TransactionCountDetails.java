package in.cdac.portal.modal;

public class TransactionCountDetails {

	private String type;
		
	private Integer count;
	
	public TransactionCountDetails() {
		
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}
	
	
	
}
