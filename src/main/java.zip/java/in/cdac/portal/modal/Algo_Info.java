package in.cdac.portal.modal;

public class Algo_Info {
	
	public int algo_id;
	public String algo;
	public int getAlgo_id() {
		return algo_id;
	}
	public void setAlgo_id(int algo_id) {
		this.algo_id = algo_id;
	}
	public String getAlgo() {
		return algo;
	}
	public void setAlgo(String algo) {
		this.algo = algo;
	}
	@Override
	public String toString() {
		return "Algo_Info [algo_id=" + algo_id + ", algo=" + algo + "]";
	}

	

}
