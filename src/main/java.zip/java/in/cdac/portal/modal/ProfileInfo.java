package in.cdac.portal.modal;

public class ProfileInfo {
	
	private String cd_mobile;

	public String getCd_mobile() {
		return cd_mobile;
	}

	public void setCd_mobile(String cd_mobile) {
		this.cd_mobile = cd_mobile;
	}

}
