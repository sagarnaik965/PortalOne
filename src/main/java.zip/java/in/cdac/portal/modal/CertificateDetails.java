package in.cdac.portal.modal;

public class CertificateDetails {
	
	private String certificateIdentifier;
	private String validTill;
	private String type;
	public String getCertificateIdentifier() {
		return certificateIdentifier;
	}
	public void setCertificateIdentifier(String certificateIdentifier) {
		this.certificateIdentifier = certificateIdentifier;
	}
	public String getValidTill() {
		return validTill;
	}
	public void setValidTill(String validTill) {
		this.validTill = validTill;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	

}
