package in.cdac.portal.util;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import in.cdac.portal.service.UserService;

@Service
@Configuration
@PropertySources(value = {@PropertySource("classpath:email_config.properties")})
public class EmailService {
	static String username = "";
	static String password = "";

	@Autowired
	UserService userService;

	@Autowired
	Environment env;
	private static String enviroment;


	private final static Logger logger = Logger.getLogger(EmailService.class);

	public void sendMail(String fromName, String to, String subject, String body, boolean bcc) {
		Properties props = new Properties();
		Session session = null;
		enviroment = userService.getDeploymentEnviroment();
		String host;
		String from = null;
		try {

			if (enviroment.equals("localtesting")) {
				username = env.getProperty("mail.username");
				password = env.getProperty("mail.password");
				host = env.getProperty("mail.smtp.host");
				from = env.getProperty("mail.username");
				
				props.put("mail.smtp.host", env.getProperty("mail.smtp.host"));
				props.put("mail.smtp.port", env.getProperty("mail.smtp.port"));
				props.setProperty("mail.smtp.auth", env.getProperty("mail.smtp.auth"));
				props.setProperty("mail.smtp.starttls.enable", env.getProperty("mail.smtp.starttls.enable"));
				props.put("mail.smtp.ssl.enable", env.getProperty("mail.smtp.ssl"));
				props.put("mail.debug", env.getProperty("mail.debug"));
			} else {

				username = env.getProperty("mail.username");
				password = env.getProperty("mail.password");
				host = env.getProperty("mail.smtp.host");
				from = env.getProperty("mail.username");
				
				props.put("mail.smtp.host", env.getProperty("mail.smtp.host"));
				props.put("mail.smtp.port", env.getProperty("mail.smtp.port"));
				props.setProperty("mail.smtp.auth", env.getProperty("mail.smtp.auth"));
				props.setProperty("mail.smtp.starttls.enable", env.getProperty("mail.smtp.starttls.enable"));
				props.put("mail.smtp.ssl.enable", env.getProperty("mail.smtp.ssl"));
				props.put("mail.debug", env.getProperty("mail.debug"));

			}
			session = Session.getInstance(props, new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(username, password);
				}
			});
		} catch (Exception e) {
			logger.info(e);
		}
		try {
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(from));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
			if (bcc) {
				logger.info("setting bcc feild");
				String bccId = userService.getBccEmailId();
				message.setRecipients(Message.RecipientType.BCC, InternetAddress.parse(bccId));
			}
			String ccId = userService.getCcEmailId(to);
			logger.info("CC id and BCC ID to be chekc ed here : " + to + ccId);
			if (ccId != null) {
				if (ccId.length() >= 1) {
					message.setRecipients(Message.RecipientType.CC, InternetAddress.parse(ccId));
				}
			}
			message.setSubject(subject);
			message.setContent(body, "text/html; charset=utf-8");
			logger.info(body);
			Transport.send(message);
			logger.info("Email send");
		} catch (MessagingException e) {
			logger.info(e);
			logger.info("Email send caught exception", e);
		} catch (Exception e) {
			logger.info(e);
		}

	}
}
